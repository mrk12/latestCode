# DLI_BDD_Automation
Automation repository for UI Automation 

Prerequisite:
  - Download the .m2 folder from box folder (https://ge.ent.box.com/folder/87974284075)
    - stored it in home directory
    
To setup the code- Download the master from this reporsitory
- Import as a MAVEN project and download all sources 
- Do a Maven clean build and make sure there are no errors

To setup db connection - Download postgre JDBC jar file from https://jdbc.postgresql.org/download.html link
 - postgresql-9.2-1002.jdbc4.jar and configure it with the project
 
 
Running a Test Feature
- Go to src/test/java > RunnerTestNG.java file
- Under @cucumberoptions make sure feature is mentioned that needs to be run or its pointing to "src//test//resources//Features" folder where it will pick up all features one by one
- Run RunnerTestNG as TestNG test
- Once test is completed, reports can be accessed from src/target/cucumber-reports/report.html
