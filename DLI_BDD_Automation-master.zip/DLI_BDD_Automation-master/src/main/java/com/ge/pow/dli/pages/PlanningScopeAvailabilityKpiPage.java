package com.ge.pow.dli.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.ge.pow.dli.objrepo.PlanningScopeAvailabilityKpiProperties;
import com.ge.pow.dli.util.Setup;
import com.ge.pow.dli.util.WebDriverUtils;
import com.google.common.base.Verify;

public class PlanningScopeAvailabilityKpiPage extends WebDriverUtils implements PlanningScopeAvailabilityKpiProperties{

	static WebDriver driver; // Instance

	public PlanningScopeAvailabilityKpiPage(WebDriver driver) {
		super(driver);
		PlanningScopeAvailabilityKpiPage.driver = driver;
	}
	
	public static void expandbigX(String bigx) {
		WebElement BigX = driver.findElement(By.xpath("//span[contains(text(),'"+bigx+"')]/../../../div/button"));
		if(BigX.isDisplayed()){
			staticWait(2);
			BigX.click();
		Reporter.addStepLog(bigx +" is expanded");	
		}
	}
	
	public static void expandOutage() {
		if(isElementPresent(expandFirstOutage)){
			staticWait(2);
		click(expandFirstOutage);
		Reporter.addStepLog("first outage is expanded");	
		}
	}
	
	public static void clickViewOutage() {
		isElementPresent(viewOutagebutton);
		click(viewOutagebutton);
		if(isElementPresent(ODpageheader)){
		Reporter.addStepLog("outage details page is displayed");	
		}
	}
		
	public static void validatecommentnumberbefore() {
		int commentsnumberbefore = 0;
		String before = getText(commentsnumber);
		commentsnumberbefore = Integer.parseInt(before);
		System.out.println(commentsnumberbefore);
		Reporter.addStepLog("before creating comment " +commentsnumberbefore);
	}
	
	public static void validateactionnumberbefore() {
		staticWait(2);
		int actionsnumberbefore = 0;
		String before = getText(actionsnumber);
		actionsnumberbefore = Integer.parseInt(before);
		System.out.println(actionsnumberbefore);
		Reporter.addStepLog("before creating action " +actionsnumberbefore);
	}
	
	public static void clickcomment() {
		if(isElementPresent(commentbutton)){
			staticWait(2);
			click(commentbutton);
			Reporter.addStepLog("comment button is clicked");	
		}
	}
	
	public static void clickaction() {
		if(isElementPresent(actionbutton)){
			staticWait(2);
			click(actionbutton);
			Reporter.addStepLog("action button is clicked");	
		}
	}
	
	public static void validatecommentnumberafter() {
		staticWait(5);
		String after = getText(commentsnumber);
		int commentsnumberafter = Integer.parseInt(after);
		System.out.println(commentsnumberafter);
		Reporter.addStepLog("after creating comment " +commentsnumberafter);				
	}
	
	public static void validateactionnumberafter() {
		staticWait(5);
		String after = getText(actionsnumber);
		int actionsnumberafter = Integer.parseInt(after);
		System.out.println(actionsnumberafter);
		Reporter.addStepLog("after creating action " +actionsnumberafter);	
	}
	
	public static void addcomment() {
		if(isElementPresent(addcommentsbutton)){
			staticWait(2);
		click(addcommentsbutton);
		Reporter.addStepLog("Add comment button is clicked from pop up");	
		}
	}
	
	public static void addaction() {
		if(isElementPresent(addactionsbutton)){
			staticWait(2);
		click(addactionsbutton);
		Reporter.addStepLog("Add action button is clicked from pop up");	
		}
	}
	
	public static void actionitem() {
		if(isElementPresent(actionitemtext)){
			staticWait(2);
		enterText(actionitemtext,"testing");
		Reporter.addStepLog("action item text is passed in textbox");	
		}
	}
	
	 public static void actionowner() {
	        if(isElementPresent(actionowner)){
	            staticWait(2);
	            clickUsingJavaScript(actionowner);
	            enterText(actionowner,"502809461");   
	            staticWait(5);
	            //driver.findElement(actionowner).sendKeys(Keys.ARROW_DOWN);
	            driver.findElement(actionowner).sendKeys(Keys.ENTER);
	            Reporter.addStepLog("action owner is passed");   
	        }
	    }
	
	public static void actiondate() {
		if(isElementPresent(actiondate)){
			staticWait(2);
			SimpleDateFormat formDate = new SimpleDateFormat("MM/dd/yyyy");
			 Calendar cal = Calendar.getInstance();  
			 cal.add(Calendar.DAY_OF_MONTH,1);
			 String newDate = formDate.format(cal.getTime());   
		enterText(actiondate, newDate);
		Reporter.addStepLog("action item text is passed in textbox");	
		}
	}
	
	public static void selectimpact() {
		if(isElementPresent(impactdropdown)){
			Select s = new Select(driver.findElement(impactdropdown));
			s.selectByVisibleText("Low");
			Reporter.addStepLog("impact is selected from dropdown");	
		}
	}
	
	public static void save() {
		if(isElementPresent(savebutton)){
		click(savebutton);
		staticWait(2);
		Reporter.addStepLog("saved");	
		click(closepopup);
		staticWait(2);
		}
	}
	
	public static void entercomment() {
		if(isElementPresent(commenttextarea)){
			staticWait(2);
			enterText(commenttextarea,"testing");
			Reporter.addStepLog("comments is added in textarea");	
		}
	}
	
	public static String lineStatusSD() {
		String statusSD ="";
		if(isElementPresent(linestatus)){
		statusSD = getText(linestatus);
		//Reporter.addStepLog("Status of line item " +statusSD);
		}
		return statusSD;
	}
	
	public static void lineStatusOD() {		
		String statusSD = lineStatusSD();
		String statusOD = getText(linestatus);
		if(statusSD.equals(statusOD)) {
		Reporter.addStepLog("Status of line item " +statusOD);	
		}
		else{
			Assert.fail();
		}
	}

	public static void clickKpi(String kpi) {
		WebElement Kpi = driver.findElement(By.xpath("//span[contains(text(),'"+kpi+"')]"));
		if(Kpi.isDisplayed()){
			Kpi.click();
			checkPageIsReady();
			Reporter.addStepLog(kpi +" is clicked and SD view is displayed");	
		}
	}
	
	public static void validateHeadings(String header) {
		WebElement heading = driver.findElement(By.xpath("//span/b[contains(text(),'"+header+"')]"));
		if(heading.isDisplayed()){
		Reporter.addStepLog(header +" is present");	
		}
	}
	
	
	public static void exportLineItems() {
		if(isElementPresent(Export)){
			staticWait(2);
			clickUsingJavaScript(Export);
		  	staticWait(10);
		}
		}

	
	@SuppressWarnings("resource")
	public static void validateLogicFromExcel() throws IOException {
		Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
		String filename = PlanningOutageHeatmapPage.getLatestFilefromDir();
		String FilePath = path + "/" + filename;
		FileInputStream fs = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fs);
	    XSSFSheet sheet = workbook.getSheetAt(0);
		int totalNoOfRows = sheet.getLastRowNum();
		Reporter.addStepLog("total outages "+totalNoOfRows);	
		for(int i=5;i<=totalNoOfRows;i++) {
			double outageID = sheet.getRow(i).getCell(8).getNumericCellValue();
			String riskValue= sheet.getRow(i).getCell(4).getStringCellValue();
			String ActivityStatus = sheet.getRow(i).getCell(25).getStringCellValue();
			if(ActivityStatus.equals("Not Available") || ActivityStatus.equals("Not Applicable")
					|| ActivityStatus.equals("Completed") || ActivityStatus.equals("Completed Late")) {
				riskValue.equals("Low/No Risk");
				//Reporter.addStepLog("Outage " +outageID+ " "+riskValue);
			}
			else if(ActivityStatus.equals("Overdue")) {
				riskValue.equals("High Risk");
				//Reporter.addStepLog("Outage " +outageID+ " "+riskValue);
			}
			else if(ActivityStatus.equals("Not Due")) {
				riskValue.equals("Not Due");
				//Reporter.addStepLog("Outage " +outageID+ " "+riskValue);
			}
			else {
				Reporter.addStepLog("Outage id " +outageID+ " is showing error");
				Verify.verify(true, "Outage id " +outageID);
				  }
		}
	}
}
	