package com.ge.pow.dli.pages;

import org.openqa.selenium.WebDriver;

import com.ge.pow.dli.objrepo.LoginPageProperties;
import com.ge.pow.dli.util.WebDriverUtils;

public class LoginPage extends WebDriverUtils implements LoginPageProperties{

	WebDriver driver; // Instance

	public LoginPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	public static void ssoUserName(String username) {
		enterText(SIGNIN_USERNAME, username);
	}

	public static void ssoPwd(String pwd) {
		enterText(SIGNIN_PASSWORD, pwd);
	}

	public static void loginSubmitBtn() {
		click(SIGNIN_SUBMITBUTTON);
		System.out.println("User able to navigate into Home page");
	}
}
