package com.ge.pow.dli.steps;

import java.io.IOException;

import com.cucumber.listener.Reporter;
import com.ge.pow.dli.pages.PlanningOutageHeatmapPage;
import com.ge.pow.dli.pages.PlanningScopeAvailabilityKpiPage;
import com.ge.pow.dli.util.TestBase;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PlanningScopeAvailabilityKpiStep{
	
	@Then("^I can able to expand \"([^\"]*)\" big X$")
	public void expandButton(String bigX) {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.expandbigX(bigX);
	}
	
	@Then("^I can able to click on \"([^\"]*)\" kpi$")
	public void clickScopeAvailbility(String kpi) {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.clickKpi(kpi);
	}
	
	@When("^I click on export line items of scope availability$")
	public void exportlineitems() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.exportLineItems();
	}
	
	@Then("^I can validate risk status of all outages$")
	public void validateStatus() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.validateLogicFromExcel();
	}
	
	@Then("^I can validate \"([^\"]*)\" heading in SD page$")
	public void headings(String heading) throws InterruptedException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.validateHeadings(heading);		
	}
	
	@Then("^I expand first outage and validate the status in SD page$")
	public void expandFirstOutage() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.expandOutage();
		PlanningScopeAvailabilityKpiPage.lineStatusSD();
	}

	@When("^I can able to click on view outage button$")
	public void clickViewOutage() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.clickViewOutage();
	}

	@Then("^I can able to check the status from OD page$")
	public void lineStatusODpage() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.lineStatusOD();
	}
	
	@When("^I can get the number of comments already created$")
	public void validatecommentnumber() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.validatecommentnumberbefore();
	}

	@Then("^I can validate the number of comments$")
	public void validatecomments() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.validatecommentnumberafter();
	}	
	
	@Then("^I can validate the number of actions$")
	public void validateactions() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.validateactionnumberafter();
	}
	
	@When("^I can get the number of actions already created$")
	public void validateactionnumber() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.validateactionnumberbefore();
	}
	
	@When("^I can able to click on comments button near outage$")
	public void commentsbutton() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.clickcomment();
	}
	
	@When("^I can able to click on actions button near outage$")
	public void actionsbutton() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.clickaction();
	}
	
	@Then("^I can able to click on add comments button$")
	public void addcomment() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.addcomment();
	}
	
	@Then("^I can able to click on add actions button$")
	public void addaction() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.addaction();
	}
	
	@Then("^I can pass the comment text$")
	public void entercomment() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.entercomment();
	}
	
	@Then("^I can able to fill necessary items$")
	public void enteractionfields() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.actionitem();
		PlanningScopeAvailabilityKpiPage.actiondate();
		PlanningScopeAvailabilityKpiPage.actionowner();
		PlanningScopeAvailabilityKpiPage.selectimpact();
	}
	
	@Then("^I can able to save$")
	public void saveButton() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.save();
	}
	
	 
}
