package com.ge.pow.dli.pages;

import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.cucumber.listener.Reporter;
import com.ge.pow.dli.objrepo.EventMProperties;
import com.ge.pow.dli.util.WebDriverUtils;

public class EventMPage extends WebDriverUtils implements EventMProperties {
	
	static WebDriver driver; // Instance
	
	public EventMPage(WebDriver driver) {
		super(driver);
		EventMPage.driver = driver;
	}
	
	public static void eventM() {
		isElementPresent(eventMContainer);
		Reporter.addStepLog("Event Management is present with all 6 sections");		
	}
	
	public static void allEvent(String strArg1) {
		By ne;
		switch(strArg1){
			case "OFS_PGS":
				 ne = EventMProperties.OFS_PGS;
			case "FSP_Events_not_accepted":
				 ne = EventMProperties.FSP_Events_not_accepted;
			case "Outages_missing_actual_start_date":
				 ne = EventMProperties.Outages_missing_actual_start_date;
			case "Outages_missing_actual_end_date":
				 ne = EventMProperties.Outages_missing_actual_end_date;
			case "Outages_missing_ERP":
				 ne = EventMProperties.Outages_missing_ERP;
			case "Outages_inactive":
				 ne = EventMProperties.Outages_inactive;	
		isElementPresent(ne);
		Reporter.addStepLog(strArg1 + " is Present");
		}
	}
	
	public static void clickEvent(String strArg1) {
		By ne;
		switch(strArg1){
			case "OFS(PGS)":
				 ne = EventMProperties.OFS_PGS;
				 clickUsingJavaScript(ne);
				 staticWait(2);
				 click(Close);
				 
			case "FSP_Events_not_accepted":
				 ne = EventMProperties.FSP_Events_not_accepted;
				 clickUsingJavaScript(ne);
				 staticWait(2);
				 click(Close);
				 
			case "Outages_missing_actual_start_date":
				 ne = EventMProperties.Outages_missing_actual_start_date;
				 clickUsingJavaScript(ne);
				 staticWait(2);
				 click(Close);
				 
				
			case "Outages_missing_actual_end_date":
				 ne = EventMProperties.Outages_missing_actual_end_date;
				 clickUsingJavaScript(ne);
				 staticWait(2);
				 click(Close);
				 
			case "Outages_missing_ERP":
				 ne = EventMProperties.Outages_missing_ERP;
				 clickUsingJavaScript(ne);
				 staticWait(2);
				 click(Close);
				 
			case "Outages_inactive":
				 ne = EventMProperties.Outages_inactive;
				 clickUsingJavaScript(ne);
				 staticWait(2);
				 click(Close);
	    }
	}
	
	public static void newModal(String strArg1) {
		By ne;
		switch(strArg1){
			case "OFS(PGS)":
				 ne = EventMProperties.OFS_PGS_modal;
			case "FSP_Events_not_accepted":
				 ne = EventMProperties.FSP_Events_not_accepted;
			case "Outages_missing_actual_start_date":
				 ne = EventMProperties.Outages_missing_actual_start_date;
			case "Outages_missing_actual_end_date":
				 ne = EventMProperties.Outages_missing_actual_end_date;
			case "Outages_missing_ERP":
				 ne = EventMProperties.Outages_missing_ERP;
			case "Outages_inactive":
				 ne = EventMProperties.Outages_inactive;
		isElementPresent(ne);
		Reporter.addStepLog(strArg1 + " Is opened");
	   }
	}
	
	public static void verifyOFSColumn() {
		click(OFS_PGS);
		staticWait(1);
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		  list.add("Actions / Comments");    
		  list.add("Customer");
		  list.add("Site");
		  list.add("Outage Type");
		  list.add("Status");
		  list.add("IBAT Contract Type");
		  list.add("Estimated Start date");
		  list.add("Estimated End date");
		  list.add("Event Owner(CPM/CSL)");
		  list.add("Service Director");
		  list.add("Event Description");
		  list.add("Equipment Serial Number(ESN)");
		  list.add("Equipment Sys ID");
		  list.add("OFS Event ID");
		  list.add("FSP Event ID");
		  list.add("Business");
		  list.add("FC Service Manager");
		  list.add("Creation Date");
		  list.add("Sub Region");
		  list.add("Country");
		  int successcount = 0;
		  for(int i=1;i<list.size();i++)  {
			  String columnName = driver.findElement(By.xpath("(//div[@role='document']//table/thead/tr[1]/th/div/div/div/span/span)["+i+"]")).getText().trim();
			  String columnList = list.get(i-1);
			  if(columnList.equalsIgnoreCase(columnName)){
				  successcount++;
			  }
			  if(successcount==list.size()){
				  Reporter.addStepLog("all column names are validated");
			  }
		  }	 
	}	
	
	public static void export(String strArg1) {
		WebElement exportX = driver.findElement(By.xpath("//span[@title='"+strArg1+"']"));
        if(exportX.isDisplayed()){
        	exportX.click();
        	staticWait(5);
        Reporter.addStepLog(strArg1 +" is Clicked");   
        }
	}
	
	public static void close() {
		isElementPresent(Close);
		click(Close);
		staticWait(5);
	}
	
	public static void verifyFSPEventColumn() {
		click(FSP_Events_not_accepted);
		staticWait(1);
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		  list.add("Actions / Comments");    
		  list.add("Customer");
		  list.add("Site");
		  list.add("FSP Outage ID");
		  list.add("Outage Type");
		  list.add("Probability");
		  list.add("FSP Contract Type");
		  list.add("Planned Start date");
		  list.add("Planned End date");
		  list.add("Event Owner(CPM/CSL)");
		  list.add("Service Director");
		  list.add("Event Description");
		  list.add("Equipment Serial Number(ESN)");
		  list.add("Equipment Sys ID");
		  list.add("FSP Event ID");
		  list.add("FSP Project #");
		  list.add("OFS Outage # / SFDC UE / Ferman #");
		  list.add("ERP Project #");
		  list.add("Business");
		  list.add("OTR Involvement");
		  list.add("FC Service Manager");
		  list.add("Creation Date");
		  list.add("Sub Region");
		  list.add("Country");
		  int successcount = 0;
		  for(int i=1;i<list.size();i++)  {
			  String columnName = driver.findElement(By.xpath("(//div[@role='document']//table/thead/tr[1]/th/div/div/div/span/span)["+i+"]")).getText().trim();
			  String columnList = list.get(i-1);
			  if(columnList.equalsIgnoreCase(columnName)){
				  successcount++;
			  }
			  if(successcount==list.size()){
				  Reporter.addStepLog("all column names are validated");
			  }
		  }	 
	}
	
	public static void pastDueDateColumn() {
		click(Outages_missing_actual_start_date);
		staticWait(1);
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		  list.add("Actions / Comments");    
		  list.add("Customer");
		  list.add("Site");
		  list.add("FSP Outage ID");
		  list.add("Outage Type");
		  list.add("Probability");
		  list.add("IBAT Contract Type");
		  list.add("Planned Start date");
		  list.add("Planned End date");
		  list.add("Event Owner(CPM/CSL)");
		  list.add("Service Director");
		  list.add("Event Description");
		  list.add("Equipment Serial Number(ESN)");
		  list.add("Equipment Sys ID");
		  list.add("FSP Event ID");
		  list.add("FSP Project #");
		  list.add("OFS Outage # / SFDC UE / Ferman #");
		  list.add("Actual Start Date");
		  list.add("Actual End Date");
		  list.add("ERP Project #");
		  list.add("Business");
		  list.add("OTR Involvement");
		  list.add("FC Service Manager");
		  list.add("Creation Date");
		  list.add("Sub Region");
		  list.add("Country");
		  int successcount = 0;
		  for(int i=1;i<list.size();i++)  {
			  String columnName = driver.findElement(By.xpath("(//div[@role='document']//table/thead/tr[1]/th/div/div/div/span/span)["+i+"]")).getText().trim();
			  String columnList = list.get(i-1);
			  if(columnList.equalsIgnoreCase(columnName)){
				  successcount++;
			  }
			  if(successcount==list.size()){
				  Reporter.addStepLog("all column names are validated");
			  }
		  }	 
	}
	
	public static void pastDueEndColumn() {
		click(Outages_missing_actual_end_date);
		staticWait(1);
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		  list.add("Actions / Comments");    
		  list.add("Customer");
		  list.add("Site");
		  list.add("FSP Outage ID");
		  list.add("Outage Type");
		  list.add("Probability");
		  list.add("IBAT Contract Type");
		  list.add("Planned Start date");
		  list.add("Planned End date");
		  list.add("Event Owner(CPM/CSL)");
		  list.add("Service Director");
		  list.add("Event Description");
		  list.add("Equipment Serial Number(ESN)");
		  list.add("Equipment Sys ID");
		  list.add("FSP Event ID");
		  list.add("FSP Project #");
		  list.add("OFS Outage # / SFDC UE / Ferman #");
		  list.add("Actual Start Date");
		  list.add("Actual End Date");
		  list.add("ERP Project #");
		  list.add("Business");
		  list.add("OTR Involvement");
		  list.add("FC Service Manager");
		  list.add("Creation Date");
		  list.add("Sub Region");
		  list.add("Country");
		  int successcount = 0;
		  for(int i=1;i<list.size();i++)  {
			  String columnName = driver.findElement(By.xpath("(//div[@role='document']//table/thead/tr[1]/th/div/div/div/span/span)["+i+"]")).getText().trim();
			  String columnList = list.get(i-1);
			  if(columnList.equalsIgnoreCase(columnName)){
				  successcount++;
			  }
			  if(successcount==list.size()){
				  Reporter.addStepLog("all column names are validated");
			  }
		  }	 
	}
	
	public static void missingERPColumn() {
		click(Outages_missing_ERP);
		staticWait(1);
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		  list.add("Actions / Comments");    
		  list.add("Customer");
		  list.add("Site");
		  list.add("FSP Outage ID");
		  list.add("Outage Type");
		  list.add("Probability");
		  list.add("IBAT Contract Type");
		  list.add("Equipment Origin");
		  list.add("Planned Start date");
		  list.add("Planned End date");
		  list.add("Event Owner(CPM/CSL)");
		  list.add("Service Director");
		  list.add("Event Description");
		  list.add("Equipment Serial Number(ESN)");
		  list.add("Equipment Sys ID");
		  list.add("FSP Event ID");
		  list.add("FSP Project #");
		  list.add("OFS Outage # / SFDC UE / Ferman #");
		  list.add("ERP Project #");
		  list.add("Business");
		  list.add("OTR Involvement");
		  list.add("FC Service Manager");
		  list.add("Creation Date");
		  list.add("Sub Region");
		  list.add("Country");
		  int successcount = 0;
		  for(int i=1;i<list.size();i++)  {
			  String columnName = driver.findElement(By.xpath("(//div[@role='document']//table/thead/tr[1]/th/div/div/div/span/span)["+i+"]")).getText().trim();
			  String columnList = list.get(i-1);
			  if(columnList.equalsIgnoreCase(columnName)){
				  successcount++;
			  }
			  if(successcount==list.size()){
				  Reporter.addStepLog("all column names are validated");
			  }
		  }	 
	}
	
	public static void fvColumn() {
		click(Outages_inactive);
		staticWait(1);
		ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		  list.add("Actions / Comments");    
		  list.add("Customer");
		  list.add("Site");
		  list.add("FSP Outage ID");
		  list.add("Outage Type");
		  list.add("Probability");
		  list.add("IBAT Contract Type");
		  list.add("Equipment Origin");
		  list.add("Planned Start date");
		  list.add("Planned End date");
		  list.add("Event Owner(CPM/CSL)");
		  list.add("Service Director");
		  list.add("Event Description");
		  list.add("Equipment Serial Number(ESN)");
		  list.add("Equipment Sys ID");
		  list.add("FSP Event ID");
		  list.add("FSP Project #");
		  list.add("OFS Outage # / SFDC UE / Ferman #");
		  list.add("ERP Project #");
		  list.add("Business");
		  list.add("OTR Involvement");
		  list.add("FC Service Manager");
		  list.add("Creation Date");
		  list.add("Sub Region");
		  list.add("Country");
		  int successcount = 0;
		  for(int i=1;i<list.size();i++)  {
			  String columnName = driver.findElement(By.xpath("(//div[@role='document']//table/thead/tr[1]/th/div/div/div/span/span)["+i+"]")).getText().trim();
			  String columnList = list.get(i-1);
			  if(columnList.equalsIgnoreCase(columnName)){
				  successcount++;
			  }
			  if(successcount==list.size()){
				  Reporter.addStepLog("all column names are validated");
			  }
		  }	 
	}
	
	public static int getCountFromUI() {
		isElementPresent(OFS_PGS);
		String outages = getText(OFS_PGS);
		int uicount = Integer.parseInt(outages);
		Reporter.addStepLog("outages " +uicount);
		return uicount;
	}
	
}
