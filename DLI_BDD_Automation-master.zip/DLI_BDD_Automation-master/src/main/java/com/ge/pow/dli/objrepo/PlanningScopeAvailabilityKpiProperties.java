package com.ge.pow.dli.objrepo;

import org.openqa.selenium.By;

public interface PlanningScopeAvailabilityKpiProperties {
	
	By Export=By.xpath("//span[contains(text(),'Export')]");	
	By expandFirstOutage = By.xpath("(//button[@title='View line items for this outage'])[1]");
	By linestatus = By.xpath("//table[@aria-label='EV Scoping']/tbody/tr[2]/td[1]");
	By viewOutagebutton = By.xpath("(//*[@title='View Outage'])[1]");
	By ODpageheader = By.xpath("//h3[text()='Outage Details']");
	By commentbutton = By.xpath("(//button[contains(@title,'comment')])[1]");
	By actionbutton = By.xpath("(//button[contains(@title,'action')])[1]");
	By commentsnumber = By.xpath("(//button[contains(@title,'comment')]/span/span/span)[1]");
	By actionsnumber = By.xpath("(//button[contains(@title,'action')]/span/span/span)[1]");
	By addcommentsbutton = By.xpath("//span[contains(text(),'Add Comments')]");
	By addactionsbutton = By.xpath("//span[contains(text(),'Add Action')]");
	By impactdropdown = By.xpath("//select[@id='impact']");
	By actionitemtext = By.name("actionItem");
	By actionowner = By.xpath("//input[@id='react-select-owner-input']");
	By actiondate = By.name("dueDate");
	By commenttextarea = By.xpath("//textarea[@name='commentInput']");
	By savebutton = By.xpath("//span[contains(text(),'Save')]");
	By closepopup = By.xpath("//div[@role='document']//div/div[2]/button");		
}
