package com.ge.pow.dli.steps;

import java.io.IOException;
import com.cucumber.listener.Reporter;
import com.ge.pow.dli.pages.LoginPage;
import com.ge.pow.dli.pages.GlobalandOutagefilterPage;
import com.ge.pow.dli.util.Setup;
import com.ge.pow.dli.util.TestBase;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GlobalandOutagefilterStep{
	
	@Then("^I can see Region filter is pre populated with default region for user$")
	public void i_can_see_filter_is_pre_populated_with_default_region_for_user() throws Throwable {
		TestBase.GlobalandOutagefilter();
		GlobalandOutagefilterPage.getting_prepopulatedregion();
	}
	
	@When("^I Select Region Dropdown value from Global filters$")
	public void i_Select_Dropdown_value_from_Global_filters() throws Throwable {
		TestBase.GlobalandOutagefilter();
		GlobalandOutagefilterPage.clickRegion();    
	}

	@Then("^I select \"([^\"]*)\" as region$")
	public void i_select_as_region(String arg1) throws Throwable {
		TestBase.GlobalandOutagefilter();
		GlobalandOutagefilterPage.selectinganyRegion(arg1); 	  
	}

	@Then("^I can see pop-up \"([^\"]*)\"$")
	public void i_can_see_pop_up(String arg1) throws Throwable {
		TestBase.GlobalandOutagefilter();
		GlobalandOutagefilterPage.checkingpopup(arg1); 
	}

	@When("^I select \"([^\"]*)\"$")
	public void i_select(String arg1) throws Throwable {
		TestBase.GlobalandOutagefilter();
		GlobalandOutagefilterPage.clickbutton(arg1);   
	}

	@Then("^my default region should change to \"([^\"]*)\"$")
	public void my_default_region_should_change_to(String arg1) throws Throwable {
		TestBase.GlobalandOutagefilter();
		GlobalandOutagefilterPage.getting_changedregion(arg1); 
	}
	
	@Then("^I should see sub-region as \"([^\"]*)\", \"([^\"]*)\" and \"([^\"]*)\"$")
	public void i_should_see_sub_region_as_and(String arg1, String arg2, String arg3) throws Throwable {
		TestBase.GlobalandOutagefilter();
		GlobalandOutagefilterPage.checkingsubregions(arg1,arg2,arg3);
	}

	@When("^I select sub-region as \"([^\"]*)\"$")
	public void i_select_sub_region_as(String arg1) throws Throwable {

	}
}
