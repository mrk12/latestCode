package com.ge.pow.dli.util;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import com.ge.pow.dli.pages.LoginPage;
import com.ge.pow.dli.pages.PlanningOutageHeatmapPage;
import com.ge.pow.dli.pages.PlanningScopeAvailabilityKpiPage;
import com.ge.pow.dli.pages.EventMPage;
import com.ge.pow.dli.pages.GlobalandOutagefilterPage;

public class TestBase implements Setup {

	private static WebDriver driver=null;
	
	public static WebDriver initilizeDriver(String url) {
		 ChromeOptions ops = new ChromeOptions();
        ops.addArguments("--disable-notifications");
		 System.setProperty(CHROME_KEY, CHROME_PATH);
		 driver=new ChromeDriver(ops);
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		 driver.get(url);
		 return driver;
	}
	
	 public static WebDriver getDriver() {
		 if(driver == null) {
			initilizeDriver(Setup.AUTOMATION_URL);
		 }
		 return driver;
	}
	
	public static LoginPage loginpage() {
		driver = getDriver();
		return new LoginPage(driver);
	}	
	
	public static PlanningOutageHeatmapPage outageheatmap() {
		driver = getDriver();
        return new PlanningOutageHeatmapPage(driver);
    }
	
	public static PlanningScopeAvailabilityKpiPage scopeavailbility() {
		driver = getDriver();
        return new PlanningScopeAvailabilityKpiPage(driver);
    }
	
	public static void closebrowser() {
		driver.quit();
		System.out.println("closing browser");
	}
	
	public static EventMPage eventM() {
		driver = getDriver();
		return new EventMPage(driver);
	}

	public static GlobalandOutagefilterPage GlobalandOutagefilter() {
		driver = getDriver();
		return new GlobalandOutagefilterPage(driver);
	}
	
	System properties = null;
	public String getReportConfigPath(){
		 
		String reportConfigPath = System.getProperty("../../../../AutomationUseCase/extent-config.xml");
		 if(reportConfigPath!= null) return reportConfigPath;
		 else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath"); 
		}
}
