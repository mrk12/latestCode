package com.ge.pow.dli.util;

public interface Setup {

	
	String CHROME_KEY="webdriver.chrome.driver";
	//String CHROME_PATH="/usr/local/bin/chromedriver";
	String CHROME_PATH="src\\test\\resources\\Config\\chromedriver.exe";
	String AUTOMATION_URL="https://qa-dli.power.ge.com/";
	String username ="502809461";
	String pwd ="dli_2020A";
	
}