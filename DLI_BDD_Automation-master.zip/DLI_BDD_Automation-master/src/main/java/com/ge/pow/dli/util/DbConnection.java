package com.ge.pow.dli.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Set;

import org.testng.Assert;

import com.ge.pow.dli.pages.EventMPage;
import com.ge.pow.dli.pages.PlanningOutageHeatmapPage;

public class DbConnection {
	static int queryOutage=0;
	static Connection con =null;
	public static void connection() throws ClassNotFoundException, IOException, SQLException {
		 Class.forName("org.postgresql.Driver");
		 String user = GetQueries.getcredentials()[0];
		 String pswd = GetQueries.getcredentials()[1];
		 con = DriverManager.getConnection("jdbc:postgresql://localhost:15436/digital_operations",user, pswd);
	}
	
	public static int executeHeatmapquery(String region) throws IOException, SQLException {
        String Query = GetQueries.HeatmapQuery(region)[1];
        PreparedStatement stmt = con.prepareStatement(Query);        
        Date futureDate = GetQueries.futureDate();
        Date today = new Date();
        java.sql.Date sqlDate = new java.sql.Date(today.getTime());
        stmt.setDate(1, sqlDate);
        java.sql.Date fDate = new java.sql.Date(futureDate.getTime());
        stmt.setDate(2, fDate);
        ResultSet st = stmt.executeQuery();
        while (st.next()) {
        queryOutage = st.getInt(1);
        System.out.println("Query result is " + queryOutage + "");
        }
        return queryOutage;
        }  
	
	public static int executEventMquery() throws IOException, SQLException {
		String Query = GetQueries.QueryEventM()[1];
		PreparedStatement stmt = con.prepareStatement(Query);
		Date futureDate = GetQueries.future2YearDate();
		Date today1 = GetQueries.past6MonthsDate();
		java.sql.Date sqlDate = new java.sql.Date(today1.getTime());
		stmt.setDate(1, sqlDate);
		java.sql.Date fDate = new java.sql.Date(futureDate.getTime());
		stmt.setDate(2, fDate);
		ResultSet st = stmt.executeQuery();
		while (st.next()) {
		queryOutage = st.getInt(1);
		System.out.println("Query result is " + queryOutage + "");

		}
		return queryOutage;
		} 
	
	public static int executeshortcyclequery(String region) throws IOException, SQLException {
        String Query = GetQueries.ShortCycleQuery(region)[1];
        PreparedStatement stmt = con.prepareStatement(Query);        
        Date futureDate = GetQueries.futureDate();
        Date today = new Date();
        java.sql.Date sqlDate = new java.sql.Date(today.getTime());
        stmt.setDate(1, sqlDate);
        java.sql.Date fDate = new java.sql.Date(futureDate.getTime());
        stmt.setDate(2, fDate);
        ResultSet st = stmt.executeQuery();
        while (st.next()) {
        queryOutage = st.getInt(1);
        System.out.println("Query result is " + queryOutage + "");

 

        }
        return queryOutage;
        }
    
    public static void compare_Heatmapoutages() {
        int UI = PlanningOutageHeatmapPage.outagecountfromUI();
        Assert.assertEquals(queryOutage, UI);
    }
	
	
	public static void compare_outages() {
		int UI = PlanningOutageHeatmapPage.outagecountfromUI();
		Assert.assertEquals(queryOutage, UI);
	}
	
	public static void compare_EventMoutages() {
		int UI = EventMPage.getCountFromUI();
		Assert.assertEquals(queryOutage, UI);
	}
}
		
