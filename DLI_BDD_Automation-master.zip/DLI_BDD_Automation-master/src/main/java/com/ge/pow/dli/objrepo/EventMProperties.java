package com.ge.pow.dli.objrepo;

import org.openqa.selenium.By;

public interface EventMProperties {

	By OFS_PGS = By.xpath("//div/h4[contains(text(),'OFS (PGS)')]/../../div[2]/h2");
	By FSP_Events_not_accepted = By.xpath("//div/h4[contains(text(),'FSP')]/../../div[2]/h2");
	By Outages_missing_actual_start_date= By.xpath("(//span[contains(text(),'Outages Missing')][1]/../../h2)[1]");
	By Outages_missing_actual_end_date = By.xpath("(//span[contains(text(),'Outages Missing')][1]/../../h2)[2]");
	By Outages_missing_ERP = By.xpath("//span[contains(text(),'Outages missing')][1]/../../h2");
	By Outages_inactive = By.xpath("//div/h4[contains(text(),'FV')]/../../div[2]/h2");
	By eventMContainer = By.xpath("//h3[text()='Event Management Defects']");
	By OFS_PGS_modal = By.xpath("//h6[text()='Outages where OFS event is not ready']");
	By Close = By.xpath("//span[contains(text(),'Close')]");
}
