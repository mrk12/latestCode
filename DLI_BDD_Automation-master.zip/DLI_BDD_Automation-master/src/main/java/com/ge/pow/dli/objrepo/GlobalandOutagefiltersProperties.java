package com.ge.pow.dli.objrepo;

import org.openqa.selenium.By;

public interface GlobalandOutagefiltersProperties {

	By region = By.xpath("//div[@id='region']/input");
	By regionDropdownbutton = By.xpath("//div[@id='region']/div/div[2]");
	By regionpopup = By.xpath("//div[@class='react-select__menu css-iitz8q-menu']");
	By popupheading = By.xpath("//div[@class='MuiDialogTitle-root']/h2");
	By subregion = By.xpath("//input[@name='subRegion']/../div");
}
