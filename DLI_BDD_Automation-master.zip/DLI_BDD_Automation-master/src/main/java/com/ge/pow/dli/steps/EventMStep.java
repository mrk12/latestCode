package com.ge.pow.dli.steps;

import java.io.IOException;
import java.sql.SQLException;

import com.ge.pow.dli.pages.EventMPage;
import com.ge.pow.dli.pages.PlanningOutageHeatmapPage;
import com.ge.pow.dli.util.TestBase;
import com.ge.pow.dli.util.DbConnection;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;


public class EventMStep {
	
    @Given("^I can see Event Management Defects$")
    public void i_can_see_event_management_defects() throws InterruptedException {
        TestBase.eventM();
        EventMPage.eventM();
    }	
        
    @Then("^I should be able to see \"([^\"]*)\" Outages$")
    public void i_should_be_able_to_see(String arg1) throws InterruptedException {
    	  TestBase.eventM();
    	  EventMPage.allEvent(arg1);
    }
    
    @When("^I click on \"([^\"]*)\" under event management defects$")
    public void i_click_on_something_under_event_management_defects(String strArg1) throws InterruptedException {
    	TestBase.eventM();
    	EventMPage.clickEvent(strArg1);
    }
    
    @Then("^new modal \"([^\"]*)\" should open up$")
    public void new_modal_something_should_open_up(String strArg1) throws InterruptedException {
    	TestBase.eventM();
    	EventMPage.newModal(strArg1);
    }
    
    @Then("^I should see all OFS PGS column names in order$")
    public void i_should_see_all_column_names_in_order() throws InterruptedException {
    	TestBase.eventM();
    	EventMPage.verifyOFSColumn();
    }
    
    @And("^I should see and click on \"([^\"]*)\" Export icon$")
    public void i_should_see_and_click_on_something_export_icon(String strArg1) throws InterruptedException {
    	TestBase.eventM();
    	EventMPage.export(strArg1);
    }
    
    @Then("^I should be able to see exported sheet in an excel$")
    public void i_should_be_able_to_see_exported_sheet_in_an_excel() throws InterruptedException {
    	TestBase.eventM();
    	PlanningOutageHeatmapPage.getLatestFilefromDir();	
    }
    
    @When("^I click on Close button$")
    public void i_click_on_close_button() throws InterruptedException {
    	TestBase.eventM();
    	EventMPage.close();
    }
    
    @Then("^I should see all FSP Events column names in order$")
    public void i_should_see_all_fsp_events_column_names_in_order() throws InterruptedException {
    	TestBase.eventM();
    	EventMPage.verifyFSPEventColumn();
    }
    
    
    @Then("^I should see all column names in order$")
    public void i_should_see_all_past_due_outages_column_names_in_order() throws InterruptedException {
    	TestBase.eventM();
    	EventMPage.pastDueDateColumn();
    }
        
    @Then("^I should see all Missing ERP column names in order$")
    public void i_should_see_all_missing_erp_column_names_in_order() throws InterruptedException {
    	TestBase.eventM();
    	EventMPage.missingERPColumn();
    }
      
    @Then("^I should see all Outages Inactive column names in order$")
    public void i_should_see_all_outages_inactive_column_names_in_order() throws InterruptedException {
       TestBase.eventM();
       EventMPage.fvColumn();
    }

    
    @Then("^I should see all Missing Actual End Date column names in order$")
    public void i_should_see_all_missing_actual_end_date_column_names_in_order() throws InterruptedException {
    	TestBase.eventM();
        EventMPage.pastDueEndColumn();
    }
    
    @Then("^I validate the count of outages from DLI UI$")
    public void i_validate_the_count_of_outages_from_dli_ui_to_backend() throws InterruptedException {
        TestBase.eventM();
        EventMPage.getCountFromUI();
    }
    
    @Then("^Get total number of outages from backend for EventM$")
    public void i_can_get_total_number_of_outages_from_backend_for_eventm() throws InterruptedException, IOException, SQLException {
    	TestBase.eventM();
    	DbConnection.executEventMquery();
    }
    
    @And("^I compare both the counts$")
    public void i_compare_both_the_counts() throws InterruptedException {
    	TestBase.eventM();
    	DbConnection.compare_EventMoutages();
    }
	  
}
