package com.ge.pow.dli.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.ge.pow.dli.objrepo.GlobalandOutagefiltersProperties;
import com.ge.pow.dli.objrepo.PlanningOutageHeatmapProperties;
import com.ge.pow.dli.util.WebDriverUtils;

public class GlobalandOutagefilterPage extends WebDriverUtils implements GlobalandOutagefiltersProperties,PlanningOutageHeatmapProperties{

	private static final List<WebElement> WebElement = null;
	static WebDriver driver; // Instance

	public GlobalandOutagefilterPage(WebDriver driver) {
		super(driver);
		GlobalandOutagefilterPage.driver = driver;		
	}

	public static void getting_prepopulatedregion() {
			staticWait(2);
			String prepopulateRegion = driver.findElement(region).getAttribute("value");
			Reporter.addStepLog("Region is present and prepopulated with "+prepopulateRegion);
	}
	
	public static void getting_changedregion(String changeregion) {
		staticWait(2);
		String changedRegion = driver.findElement(region).getAttribute("value");
		if(changedRegion.equals(changeregion)) {
			Reporter.addStepLog("Region is changed to  "+changedRegion);
		}
		else {
			Assert.fail("region change failed");
		}
	}
	
	public static void clickRegion() {
		click(regionDropdownbutton);
		Reporter.addStepLog("Region filter is selected");
		boolean popup = driver.findElement(regionpopup).isDisplayed();
		if(popup) {
			Reporter.addStepLog("regions are present");
		}
		else {
			Assert.fail("region popup dint dispalyed");
		}
	}
	
	public static void selectinganyRegion(String region) {
		staticWait(5);
		String reg = driver.findElement(selectedRegion).getAttribute("value");
		if(!reg.equals(region)) {
			isElementPresent(regionFilter);
			enterText(regionFilter,region);
			Actions action = new Actions(driver); 
			action.sendKeys(Keys.ENTER).build().perform();
		}	
	}
	
	public static void checkingpopup(String popuptext) {
		String text = getText(popupheading);
		if(popuptext.equals(text)) {
			Reporter.addStepLog(text +" popup is displayed");
		}
		else {
			Assert.fail("popup didnt displayed");
		}
	}
	
	public static void clickbutton(String button) {
		WebElement clickbutton = driver.findElement(By.xpath("//div[@role='dialog']//span[contains(text(),'"+button+"')]"));
		clickbutton.click();
		staticWait(2);
		Reporter.addStepLog(button +" is clicked");
	}
	
	public static void checkingsubregions(String subregion1,String subregion2,String subregion3) {
		clickUsingJavaScript(subregion);
		List <WebElement> subregions = driver.findElements(By.xpath("(//input[@name='subRegion']/../..//nav//input/..)"));
		int number = subregions.size();
	}
	
}
