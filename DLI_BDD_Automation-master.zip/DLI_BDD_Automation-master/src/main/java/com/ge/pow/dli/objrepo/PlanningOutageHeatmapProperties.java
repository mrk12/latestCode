package com.ge.pow.dli.objrepo;
import org.openqa.selenium.By;

public interface PlanningOutageHeatmapProperties {
    
    //outage heatmap
    By heatmapcontainer = By.id("outage-heatmap-container");
    By totaloutages_heatmap = By.xpath("//table/thead/tr[2]/th/p");
    By highrisk = By.xpath("//button[@title='Filter by High']");
    By mediumrisk = By.xpath("//button[@title='Filter by Medium']");
    By lowrisk = By.xpath("//button[@title='Filter by Low/No']");
    By heatmaptable = By.xpath("(//table/tbody)[1]/tr");
    By modalwindow=By.xpath("//div[@role='document']//table/tbody/tr");
    By popup_close=By.xpath("//div[@role='document']//div[@class='MuiGrid-root MuiGrid-container']/div[2]/button"); 
    By forwardarrow=By.xpath("(//button[contains(@title,'See next few months')])[1]");
    By backarrow=By.xpath("(//button[contains(@title,'See previous months')])[1]");
    By heatmapExport=By.xpath("//span[@title='Export outage heatmap data to Excel']");
    By nextpagearrow=By.xpath("//button[@aria-label='Next']");
    By shortCycle_checkbox = By.xpath("//input[@type='checkbox' and @value='Short-Cycled']");
    By criticalkpi_checkbox = By.xpath("//p[contains(text(),'High risk for critical KPI')]/../../span/span/input");
    By score_from_outagedetails=By.xpath("//span[contains(text(),'Planning & Fulfilment Score')]/../div[2]/span");
    By back_button=By.xpath("//span[contains(text(),'Back')]");
    By reset_button=By.xpath("//button[@title='Reset filters']");
    By region_yes=By.xpath("//div[@role='dialog']/div/button/span[contains(text(),'Yes')]");
    By subregion_rows = By.xpath("//div[@id='outage-heatmap-container']//table/tbody/tr");
    By selectedRegion = By.xpath("//input[@name='region']");
    By regionFilter = By.xpath("//input[@id='react-select-region-input']");
    By outagescopefilter = By.xpath("(//input[@name='outageScope']/../div//*[name()='svg' and @role='presentation'])[2]");
    By selectalloutagescope = By.xpath("//input[@value='outageScope']/..");
    By applyOutagescope = By.xpath("(//input[@value='outageScope']/following::div/button/span[contains(text(),'Apply')])[1]");
    By firstsubregion = By.xpath("//div[@id='outage-heatmap-container']//table/tbody/tr[1]/td/div/div/button");
    By firstcountry = By.xpath("//div[@id='outage-heatmap-container']//table/tbody/tr[2]/td/div/div/button");
    By firstcustomer = By.xpath("//div[@id='outage-heatmap-container']//table/tbody/tr[3]/td/div/div/button");
}