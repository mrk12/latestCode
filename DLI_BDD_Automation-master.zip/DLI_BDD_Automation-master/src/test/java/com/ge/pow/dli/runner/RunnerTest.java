package com.ge.pow.dli.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src\\test\\resources\\Features",glue={"com.steps", "src/test/resources/Features"})

public class RunnerTest {


}
