//var currentPage = 'taskMgmtPage'; 
var currentPage = 'userStory';


module.exports = function() {

      /*this.Given(/^I login to (.*)$/, function (env, callback) {
		env = browser.params.login.url;

		taskMgmtPage.getLogin(env).then(function (completed) {
			browser.ignoreSynchronization = true;
			assert.isTrue(completed, 'Not login page');
			callback();
		});

	});

	this.When(/^I authenticate with valid (.*) and (.*)$/, function (userName, password, callback) {
		userName = browser.params.login.username;
		password = browser.params.login.password;
		taskMgmtPage.setName(userName).then(function () {
			taskMgmtPage.setPassword(password).then(function () {
				taskMgmtPage.clickLogin().then(function () {
					callback();
				});
			});
		});
	});*/

	this.Then(/^I can able to select No estimation required from 2.5 Generatal contract TCs$/, function(callback) {
		userStory.validateQ2_5and5_0(callback);
	});

	this.Then(/^I verify No Variable billings Radio button tooltip text$/, function(callback) {
		userStory.noVariableBillingRadioBtnTooltip().then(function (tooltipInfo) {
		console.log("5.1Tooltip Text:"+ tooltipInfo);
		assert.equal(tooltipInfo, 'In Article 2.5,you selected No Estimation,hence you cannot add variable billing.Please revisit if need be.');
		callback();
		});
	});
	
	this.Then(/^I verify No Variable billings Radio button is in disable state$/, function(callback) {
		userStory.noVariableBillingRadioBtn().then(function () {
		callback();
		});
	});
	this.Then(/^User is able to navigate into Homepage$/, function(callback) {
		userStory.refreshPage().then(function () {
		callback();
		});
	});
	
	this.Then(/^Verify that amount option of Art 2.13.1 should be disabled upon selecting yes for Art 2.13$/, function(callback) {
		userStory.validateTrueupForActualHoursQ2_13(callback);
	});

	this.Then(/^I verify True up invoice date based Amount Radio button tooltip text$/, function(callback) {
		userStory.trueUpInvoiceDateAmountRadioBtnTooltip().then(function (tooltipInfo) {
		console.log("Amount btn Tooltip Text:"+ tooltipInfo);
		assert.equal(tooltipInfo, 'Log a support ticket if this option is required');
		callback();
		});
	});
	this.Then(/^I can able to commit the General terms and conditions for Q2.5$/, function(callback) {
		userStory.generalTCscommitBtn().then(function () {
		callback();
		});
	});
	
	this.Then(/^I verify True up invoice date based Amount Radio button is in disable state$/, function(callback) {
		userStory.noVariableBillingRadioBtn().then(function () {
		callback();
		});
	});

	this.Then(/^I can able to commit the General terms and conditions$/, function(callback) {
		userStory.generalTCscommitBtn().then(function () {
		callback();
		});
	});
	
	
// 9th Jan 2020

this.Then(/^I can click on Parameters tab for aero contracts$/, function (callback) {
	userStory.clickOnParametersTab().then(function(){callback()})
  });

this.Then(/^I can click on Gas Fuel type edit parameter option$/, function (callback) {
	userStory.clickOnFuelTypeEditBtn().then(function(){callback()})
  });


  this.Then(/^I can choose and update Natural gas option from parameter value dropdown$/, function (callback) {
	userStory.selectNaturalGas().then(function(){callback()})
  });


  this.Then(/^I can validate Fuel dropdown in hours popup editor restricted to Natural gas only or not$/, function (callback) {
	userStory.validateNaturalgasRestriction().then(function(){callback()})
  });


  this.Then(/^I can change parameter value to refinery gas$/, function (callback) {
	userStory.changeRefineryGasType().then(function(){callback()})
  });


  this.Then(/^I can validate Fuel dropdown in hours popup editor restricted to refinery gas only or not$/, function (callback) {
	userStory.validateRefinerygasRestriction().then(function(){callback()})
  });


  this.Then(/^I can change parameter value to Low BTU Gas$/, function (callback) {
	userStory.changeLowBTUGasType().then(function(){callback()})
  });

  this.Then(/^I can validate Fuel dropdown in hours popup editor restricted to Low BTU Gas only or not$/, function (callback) {
	userStory.validateLowBTUGasgasRestriction().then(function(){callback()})
  });

  this.When(/^I can able to click on General Terms and Condition$/, function (callback) {
	taskMgmtPage.generalcontractTandCs().then(function () {
		callback();
		  });
  });

  this.Then(/^I can able to select General terms and conditions and CCL project Id$/, function(callback) {
	userStory.generalTCsForCCL150TxtValidation(callback);
});

this.When(/^I can able to validate maximum characters in Inline fields under Billing period$/, function (callback) {
	userStory.billingPeriodEditBtn().then(function () {
		callback();
		  });
  });

  this.When(/^User able to create unshedule Manual invoice for CCL contract$/, function (callback) {
	userStory.unscheduleManualInvoiceCreation().then(function () {
		callback();
		  });
  });

  this.When(/^I can able to create unshedule Credit invoice for CCL contract$/, function (callback) {
	userStory.unscheduleCreditInvoiceCreation().then(function () {
		callback();
		  });
  });

  this.When(/^I can able to create unshedule Debit invoice for CCL contract$/, function (callback) {
	userStory.unscheduleDebitInvoiceCreation().then(function () {
		callback();
		  });
  });

  this.When(/^I can able to validate maximum characters in Inline fields CCL Credit invoice$/, function (callback) {
	userStory.unscheduleCreditInvoiceValidation().then(function () {
		callback();
		  });
  });

  this.When(/^I can able to validate maximum characters in Inline fields CCL Manual invoice$/, function (callback) {
	userStory.unscheduleInvoiceValidation().then(function () {
		callback();
		  });
  });

//US37493
  this.Then(/^I can able to select General terms and conditions and Mutiple project Ids$/, function(callback) {
	userStory.validationProjectCurrencyTable(callback);
});

this.Then(/^I can Validate project ID label from currency table$/, function (callback) {
	userStory.currencyTableProjectId().then(function(){callback()})
  });
  this.Then(/^I can Validate Contract Currency label from currency table$/, function (callback) {
	userStory.currencyTableContractCurrency().then(function(){callback()})
  });
  this.Then(/^I can Validate Invoice Primary Currency label from currency table$/, function (callback) {
	userStory.currencyTableInvoiceCurrency().then(function(){callback()})
  });

  this.Then(/^I can Validate Invoice Alternative Currency label from currency table$/, function (callback) {
	userStory.currencyTableInvoiceAlternativeCurrency().then(function(){callback()})
  });

  this.Then(/^I can Validate all the projectIDs from the Currency Table$/, function (callback) {
	userStory.projectIdCount(callback);
  });

  this.Then(/^I can validate Invoice Alternate Currency for all the projectIDs$/, function (callback) {
	//taskMgmtPage.selectCurrencytype().then(function () {
		userStory.ValidateCurrencytypeNA().then(function () {
			callback();
		});
  });
  this.Then(/^I can provide fixed Amount (.*)$/, function (fixedAmount, callback) {
	userStory.enterFixedAmountPart(fixedAmount).then(function () {
		callback();
		  });
  });

  this.Then(/^I can provide variable Amount (.*)$/, function (variableAmount, callback) {
	userStory.enterVariableAmountPart(variableAmount).then(function () {
		callback();
		  });
  });

  this.When(/^I can able to create unshedule Manual invoice (.*)$/, function (contract, callback) {
	userStory.creationOfUnscheduleManualInvoice(contract).then(function () {
		callback();
		  });
  });
  this.Then(/^I can provide Invoice Alternate Currency type (.*)$/, function (currencyType,callback) {
	userStory.selectInvoiceAlternativeCurrencytype(currencyType).then(function () {
			callback();
		});
  });

  this.Then(/^I can Validate invoice Currency Radio button$/, function (callback) {
	userStory.validateInvoiceCurrencyRadioBtn(callback);
  });
  
  this.When(/^I can able to Approve unshedule Manual invoice$/, function (callback) {
	userStory.manualInvoiceApproveBtn().then(function () {
		callback();
		  });
  });

  this.When(/^I can able to Validate Non USD invoice currency type for Alpha Processing$/, function (callback) {
	userStory.validationConversiondetailsForAlphaProcessing().then(function () {
		callback();
		  });
  });

  this.Then(/^I can Validate Disable mode of invoice Currency Radio button$/, function (callback) {
	userStory.validateDisabledInvoiceCurrencyRadioBtn(callback);
  });

  this.When(/^I can able to Unapprove unshedule Manual invoice$/, function (callback) {
	userStory.manualInvoiceUnapproveBtn().then(function () {
		callback();
		  });
  });

  this.Then(/^I can able to select General terms and conditions and project Id$/, function(callback) {
	userStory.validationProjectCurrencyTableCCL(callback);
});

this.Then(/^I can able to select General terms and conditions and Within Prior to end of billing period$/, function(callback) {
	userStory.generalTCsForCombineAllEscalationValidation(callback);
});


this.Then(/^Search for the aero contract (.*) in Billing schedule section$/, function (contractId, callback) {
	userStory.searchforContractInBillingSchedule(contractId).then(function () {
		callback();
	});
  });

  this.Then(/^Click on review button$/, function (callback) {
	userStory.clickOnBillingScheduleReview().then(function () {
		callback();
	});
  });

  this.Then(/^Select invoice date as todays date and entitlement date as tommorrows date$/, function (callback) {
	userStory.selectEntitlement_InvoiceDate().then(function () {
		callback();
	});
  });

  this.Then(/^Click on approve and validate the warning message$/, function (callback) {
	userStory.validateFoxtrotWarningMsg().then(function () {
		callback();
	});
  });

  this.Then(/^I can able to select General terms and conditions for Aero Contract$/, function(callback) {
	userStory.validationProjectCurrencyTableAero(callback);
});

this.Then(/^I can able to click on Escalation Rate Tab and Select Different rates per period$/, function (callback) {
	userStory.escalationRateTab().then(function () {
		callback();
	});
  });

  this.Then(/^I verify Combine all escalation into one Line Radio button is in disable state$/, function(callback) {
	userStory.combineAllEscalationIntoOneLineRadioBtn().then(function () {
	callback();
	});
});

  this.Then(/^I verify Combine all escalation into one Line Radio button tooltip text$/, function(callback) {
	userStory.combineAllEscalationIntoOneLineRadioBtnTooltip().then(function () {	
	callback();
	});
}); 

this.Then(/^I can able to read the data from excel sheet$/, function(callback) {
	userStory.excelReaderFunction().then(function () {	
	callback();
	});
}); 




  



 //last line
};
