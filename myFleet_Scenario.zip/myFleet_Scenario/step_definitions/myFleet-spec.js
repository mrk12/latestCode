var currentPage = 'taskMgmtPage';

var billingHomePage = require("..//PageObjects//Billing_po.js");
var ContractTandCsPage = require("..//PageObjects//ContractT&CsPage.js");
var CreateUnschInvPage = require("..//PageObjects//createunscheduleInvoices_po.js");

module.exports = function () {

	this.Given(/^I login to (.*)$/, function (env, callback) {
  	env = browser.params.login.url;
		taskMgmtPage.getLogin(env).then(function () {
			browser.ignoreSynchronization = true;
			//assert.isTrue(completed, 'Not login page');
			callback();
		});

	});

	this.When(/^I authenticate with Invalid (.*) and (.*)$/, function (userName, password, callback) {
		userName = browser.params.login.username2;
		password = browser.params.login.password2;
		taskMgmtPage.setName(userName).then(function () {
			taskMgmtPage.setPassword(password).then(function () {
				taskMgmtPage.clickLogin().then(function () {
					callback();
				});
			});
		});
	});



	this.Then(/^I can able to see (.*)$/, function (invSignInErrMsg, callback) {
		invSignInErrMsg = browser.params.login.errMsg;
		console.log(invSignInErrMsg);
		//expect(myFleetPage.validateErrmsg()).toEqual(invSignInErrMsg).then(function(){
		taskMgmtPage.validateErrmsg().then(function () {

			callback();
		});
	});

	this.When(/^I authenticate with valid (.*) and (.*)$/, function (userName, password, callback) {
		userName = browser.params.login.username;
		password = browser.params.login.password;
		taskMgmtPage.setName(userName).then(function () {
			taskMgmtPage.setPassword(password).then(function () {
				taskMgmtPage.clickLogin().then(function () {
					callback();
				});
			});
		});
	});

	this.When(/^I can able to navigate into MyFleet application (.*)$/, function (userName, callback) {
		userName = browser.params.login.username;
		//password = browser.params.login.password;
		taskMgmtPage.setName1(userName).then(function () {
			//taskMgmtPage.setPassword(password).then(function () {
			taskMgmtPage.clickLogin1().then(function () {
				callback();
			});
			//});
		});
	});

	this.Given(/^I can able to Launch the MyFleet application$/, function (callback) {
		taskMgmtPage.getLoginIndex().then(function () {
			callback();
		});
	});

	/*this.Then(/^I can able to Launch the MyFleet application$/, function(callback) {
        taskMgmtPage.getLogin1().then(function () {
                         callback();
		});
	});*/

	this.Given(/^I can able to enter SSO$/, function (callback) {
		taskMgmtPage.enterSSO().then(function () {
			callback();
		});
	});


	this.Then(/^I can able to click on Login button$/, function (callback) {
		taskMgmtPage.loginButton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to see Myfleet Assets Management Tab$/, function (callback) {
		taskMgmtPage.waitForAssetsTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Assets Management Tab$/, function (callback) {
		taskMgmtPage.assetsTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Cases Management Tab$/, function (callback) {
		taskMgmtPage.casesTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate cases header$/, function (callback) {
		taskMgmtPage.casesHeaderTxt().then(function (value) {
			assert.equal(value, 'M&D Cases');
			console.log("Cases Header Text: " + value);
			callback();
		});
	});

	this.Then(/^I can able to handle Local host Popup$/, function (callback) {
		taskMgmtPage.localHostPopup().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Billing Management Tab$/, function (callback) {
		taskMgmtPage.billingTab().then(function () {

			callback();
		});
	});

	this.When(/^I can able to wait for Billing Management Tab$/, function (callback) {
		taskMgmtPage.waitForBillingTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Billing header$/, function (callback) {
		taskMgmtPage.billingHeaderTxt().then(function (value) {
			assert.equal(value, 'CSA Billing');
			console.log("Billing Header Text: " + value);
			callback();
		});
	});

	this.Then(/^I can able to click on UserName$/, function (callback) {
		taskMgmtPage.userNameTxt().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to search with Contract ID$/, function (callback) {
		taskMgmtPage.myContactsSearchFld().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Setting and Mysetting tabs$/, function (callback) {
		taskMgmtPage.mySetting().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to search with Site name$/, function (callback) {
		taskMgmtPage.mySitesSearchKey().then(function () {
			callback();
		});
	});

	this.Given(/^I can able to select the Site$/, function (callback) {
		taskMgmtPage.siteModuleSel(callback);
	});

	this.Then(/^I can able to click on Site Apply button$/, function (callback) {
		taskMgmtPage.mySitesApplyBtn().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to validate added site message$/, function (callback) {
		taskMgmtPage.mySitesAddConformationMsg().then(function (value) {
			assert.equal(value, 'My Sites updated successfully.');
			console.log("Text: " + value);
			callback();
		});
	});
	this.Then(/^I can able to click on Terms and Condition or Edit button$/, function (callback) {
		taskMgmtPage.tccViewandEditBtn().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to validate Terms and Condition page header Text$/, function (callback) {
		taskMgmtPage.termsAndCondtionpageHeader().then(function (value) {
			assert.equal(value, 'Contract Terms and Conditions');
			console.log("Terms&Condition page headerText: " + value);
			callback();
		});
	});
	this.Then(/^I can able to click on Create new version button$/, function (callback) {
		taskMgmtPage.createNewVersionBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to enter Create new version description$/, function (callback) {
		taskMgmtPage.createVersionDesc().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Create new version commit button$/, function (callback) {
		taskMgmtPage.validateNoRecord(callback);
	});
	this.Then(/^I can able to click on Create new version commit button$/, function (callback) {
		taskMgmtPage.createNewVersionCommitBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Billing committ button$/, function (callback) {
		taskMgmtPage.billingCommitBtn().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to validate Billing conformation commit Text$/, function (callback) {
		taskMgmtPage.billingConformationCommitTxt().then(function (value) {
			//assert.equal(value, 'My Sites updated successfully.');
			console.log("Billing conformation commitText: " + value);
			callback();
		});
	});
	this.Then(/^I can able to click on billing conformation commit button$/, function (callback) {
		taskMgmtPage.billingConformationCommitBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Data committed success message$/, function (callback) {
		taskMgmtPage.billingConformationCommitMessage().then(function (value) {
			assert.equal(value, 'Data Committed Successfully');
			console.log("Success message: " + value);
			callback();
		});
	});
	this.Then(/^I can able to wait Data committed success message$/, function (callback) {
		taskMgmtPage.waitForbillingConformationCommitMessage().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Data Saved success message$/, function (callback) {
		taskMgmtPage.billingConformationCommitMessage().then(function (value) {
			assert.equal(value, 'Data Saved Successfully');
			console.log("Success message: " + value);
			callback();
		});
	});

	this.Then(/^I can enter variable Amount (.*)$/, function (variableAmount, callback) {
		taskMgmtPage.variableAmountPart(variableAmount).then(function () {
			callback();
			  });
	  });

	  this.Then(/^I can able to select Invoice Payment date$/, function ( callback) {
		taskMgmtPage.invoicePaymentDateCalGrid().then(function () {
			callback();
			  });
	  });

	this.Then(/^I can able to click on billing back button$/, function (callback) {
		taskMgmtPage.clickBackToBilling().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on back to forecast$/, function (callback) {
		taskMgmtPage.clickBackToForecast().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on Billing dashboard$/, function (callback) {
		taskMgmtPage.clickBillingDasboard().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Billing schedule Header Text$/, function (callback) {
		taskMgmtPage.billingScheduleHeaderTxt().then(function (value) {
			assert.equal(value, 'Billing Schedule');
			console.log("Billing schedule Header Text: " + value);
			callback();
		});
	});

	this.Then(/^I can able to select from date in Billing schedule Filter with contractId (.*)$/, function (contractId, callback) {
		taskMgmtPage.billingScheduleFromDateCalenarIcon(contractId).then(function () {
			callback();
		});
	});



	this.Then(/^I can able to select To date in Billing schedule Filter$/, function (callback) {
		taskMgmtPage.billingScheduleToDateCalenarIcon().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search Fixed and Variable contract in Billing schedule Filter with (.*)$/, function (contractId, callback) {
		taskMgmtPage.billingScheduleFromDateCalenarIconForFixed(contractId).then(function () {
			callback();
		});
	});
	this.Then(/^I can able to select specific date range in Billing schedule section$/, function (callback) {
		taskMgmtPage.billingScheduleFromDateCalenar().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search Milestone contract in Billing schedule Filter with (.*)$/, function (callback) {
		taskMgmtPage.billingScheduleFromDateCalenarIconForMilestone().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select from date for Multi Project Id in Billing schedule Filter$/, function (callback) {
		taskMgmtPage.billingScheduleFromDateCalenarIconForMultiProjectID().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to reset from date in Billing schedule Filter$/, function (callback) {
		taskMgmtPage.billingScheduleDateCalenarSet().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Billing schedule filter Apply button$/, function (callback) {
		taskMgmtPage.billingScheduleFilterApplyBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Billing schedule filter records count$/, function (callback) {
		taskMgmtPage.billingScheduleRecordsCount(callback);
		//callback();
		//});
	});

	this.Then(/^I can able to validate Billing schedule Period and Event Text$/, function (callback) {
		taskMgmtPage.billingSchedulePeriodEventTxt().then(function (value) {
			//assert.equal(value, 'Billing Schedule');
			console.log("Billing schedule Period/Event Text: " + value);
			callback();
		});
	});

	this.Then(/^I can able to select Contract Level and Other Required fields$/, function (callback) {
		taskMgmtPage.validateContractLevel(callback);
	});

	this.Then(/^I can able to search Billing schedule records of the contractor$/, function (callback) {
		taskMgmtPage.billingScheduleFilterSearchFld().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to click on billing schedule Calculate button$/, function (callback) {
		taskMgmtPage.billingScheduleCalculateBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate billing schedule Columns$/, function (callback) {
		taskMgmtPage.verifyInvoiceFldValidation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on billing schedule Contractor check box$/, function (callback) {
		taskMgmtPage.billingScheduleCalculateConfChkBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on billing schedule Calculate yes button$/, function (callback) {
		taskMgmtPage.billingScheduleCalculateConfOkBtn().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to validate Billing schedule Calculate unit SN header Text$/, function (callback) {
		taskMgmtPage.billingScheduleCalculateUnitSnTxt().then(function (value) {
			assert.equal(value, 'UNIT SN');
			console.log("Billing schedule UNIT SN header Text: " + value);
			callback();
		});
	});
	this.Then(/^I can able to validate Billing schedule calculate Unit SN Value for Contract Level$/, function (callback) {
		taskMgmtPage.billingScheduleCalculateUnitSnValue().then(function (value) {
			assert.equal(value, 'All');
			console.log("Billing schedule UNIT SN Value: " + value);
			callback();
		});
	});

	this.Then(/^I can able to click on billing schedule Calculate Back button$/, function (callback) {
		taskMgmtPage.billingScheduleCalculateBackBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Invoice Back button$/, function (callback) {
		taskMgmtPage.variableManualInvoiceBackBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Individual equipment level and Other Required Fields$/, function (callback) {
		taskMgmtPage.validateIndividualRecords(callback);
	});

	this.Then(/^I can able to validate Billing schedule calculate Unit SN Value for Individual equipment$/, function (callback) {
		taskMgmtPage.billingScheduleCalculateUnitSnValue().then(function (value) {
			//assert.equal(value, 'All');
			console.log("Billing schedule UNIT SN Value: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Invoice frequency, when user selects any Fee applicable frequency$/, function (callback) {
		taskMgmtPage.validateInvoiceFrequency(callback);
	});

	this.Then(/^I can able to select fee application frequency is Monthly and Invoice Frequency is Monthly$/, function (callback) {
		taskMgmtPage.validateMonthlyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency and Invoice Frequency Text$/, function (callback) {
		taskMgmtPage.billingScheduleEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate application frequency and Invoice Frequency is Monthly$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyCurrentDate().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Monthly and Invoice Frequency is Quarterly$/, function (callback) {
		taskMgmtPage.validateQuarterlyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Monthly and Invoice Frequency is Quarterly$/, function (callback) {
		taskMgmtPage.billingScheduleQuarterlyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Monthly and Invoice Frequency is Semi-Annually$/, function (callback) {
		taskMgmtPage.validateSemiannuallyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Monthly and Invoice Frequency is Semi-Annually$/, function (callback) {
		taskMgmtPage.billingScheduleSemiannuallyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Monthly and Invoice Frequency is Annually$/, function (callback) {
		taskMgmtPage.validateAnnuallyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Monthly and Invoice Frequency is Annually$/, function (callback) {
		taskMgmtPage.billingScheduleAnnuallyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Quarterly and Invoice Frequency is Quarterly$/, function (callback) {
		taskMgmtPage.validateQuarterlyQuarterlyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Quarterly and Invoice Frequency is Quarterly$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyCurrentDate12().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Quarterly and Invoice Frequency is Semi Annually$/, function (callback) {
		taskMgmtPage.validateQuarterlySemiAnnuallyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Quarterly and Invoice Frequency is Semi Annually$/, function (callback) {
		taskMgmtPage.billingScheduleQuarterlySemiAnnuallyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Quarterly and Invoice Frequency is Annually$/, function (callback) {
		taskMgmtPage.validateQuarterlyAnnuallyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Quarterly and Invoice Frequency is Annually$/, function (callback) {
		taskMgmtPage.billingScheduleQuarterlyAnnuallyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Semi Annually and Invoice Frequency is Semi Annually$/, function (callback) {
		taskMgmtPage.validateSemiAnnuallySemiAnnuallyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Semi Annually and Invoice Frequency is Semi Annually$/, function (callback) {
		taskMgmtPage.billingScheduleSemiAnnuallySemiAnnuallyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Semi Annually and Invoice Frequency is Annually$/, function (callback) {
		taskMgmtPage.validateSemiAnnuallyAnnuallyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Semi Annually and Invoice Frequency is Annually$/, function (callback) {
		taskMgmtPage.billingScheduleSemiAnnuallyAnnuallyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select fee application frequency is Annually and Invoice Frequency is Annually$/, function (callback) {
		taskMgmtPage.validateAnnuallyAnnuallyInvoiceFrequency(callback);
	});

	this.Then(/^I can validate application frequency Annually and Invoice Frequency is Annually$/, function (callback) {
		taskMgmtPage.billingScheduleAnnuallyAnnuallyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify how invoice Date is getting generated when Invoicing Frequency is selected Monthly$/, function (callback) {
		taskMgmtPage.validateMonthlyActualDate30InvoiceFrequency(callback);
	});

	this.Then(/^I can validate Invoice Date$/, function (callback) {
		taskMgmtPage.billingScheduleInvoiceTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate Invoice Date and Entitlement Date and Invoice Frequency is Monthly$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyEntitlementDate().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate Invoice Month and Entitlement Month and Invoice Frequency is Monthly-Month post billing period close$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyEntitlementMonth1().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate Invoice Month and Entitlement Month and Invoice Frequency is Monthly$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyEntitlementMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Monthly and 2nd Month post billing period close$/, function (callback) {
		taskMgmtPage.validateMonthlyActualDate31InvoiceFrequency(callback);
	});

	this.Then(/^I can validate Invoice Month and Entitlement Month and Invoice Frequency is Monthly-Current billing month$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyEntitlementCurrentMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Monthly and Current billing month$/, function (callback) {
		taskMgmtPage.validateMonthlyInvoiceFrequencyCurrentWithinBilling(callback);
	});
	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Monthly and Within No estimation required$/, function (callback) {
		taskMgmtPage.validateMonthlyInvoiceFrequencyNoEstimationRequired(callback);
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Quarterly and After billing period$/, function (callback) {
		taskMgmtPage.validateQuarterlyInvoiceFrequencyAfterBilling(callback);
	});

	this.Then(/^I can validate application and Invoice frequency Quarterly and After billing period$/, function (callback) {
		taskMgmtPage.billingScheduleSemiAnnuallySemiAnnuallyEventPeriodTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Quarterly and 2nd Month- After billing period$/, function (callback) {
		taskMgmtPage.validateQuarterlyInvoiceFrequencyAfterBilling2ndMonth(callback);
	});

	this.Then(/^I can validate application and Invoice frequency Quarterly, Entitlement and Event Month$/, function (callback) {
		taskMgmtPage.verifyQuarterlyFrequencyEntitlementMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Quarterly and 1st Month, Deviation-1, Within Estimation required$/, function (callback) {
		taskMgmtPage.validateQuarterlyInvoiceFrequencyWithinBilling1stMonth(callback);
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Quarterly and 2nd Month, Deviation-1, Within-without Estimation$/, function (callback) {
		taskMgmtPage.validateQuarterlyInvoiceFrequencyWithinBilling2ndtMonth(callback);
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Semi Annually and Month post billing period, After end of billing period$/, function (callback) {
		taskMgmtPage.validateSemiAnnuallyInvoiceFrequencyWithinBilling(callback);
	});

	this.Then(/^I can validate application and Invoice frequency Semi Annually and After billing period$/, function (callback) {
		taskMgmtPage.verifyAnnuallyFrequencyEntitlementMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate application and Invoice frequency Semi Annually 2nd Month and After billing period$/, function (callback) {
		taskMgmtPage.verifyAnnuallyFrequencyEntitlement2ndMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Semi Annually and 2nd Month post billing period, After end of billing period$/, function (callback) {
		taskMgmtPage.validateSemiAnnuallyInvoiceFrequencyWithinBilling2ndMonth(callback);
	});

	this.Then(/^I can validate application and Invoice frequency Annually and After billing period$/, function (callback) {
		taskMgmtPage.verifyAnnuallyFrequencyEntitlementMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Annually and Month post billing period, After end of billing period$/, function (callback) {
		taskMgmtPage.validateAnnuallyInvoiceFrequencyAfterBilling(callback);
	});

	this.Then(/^I can validate application and Invoice frequency Annually 2nd Month and After billing period$/, function (callback) {
		taskMgmtPage.verifyAnnuallyFrequencyEntitlement2ndMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Annually and 2ndMonth post billing period, After end of billing period$/, function (callback) {
		taskMgmtPage.validateAnnuallyInvoiceFrequencyAfterBilling2ndMonth(callback);
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Semi Annually, Month post billing and Actual day 30th$/, function (callback) {
		taskMgmtPage.validateSemiAnnuallyInvoiceFrequencyDeviation0After(callback);
	});

	this.Then(/^I can validate application and Invoice frequency Semi Annually, Actual day 30th and After billing period$/, function (callback) {
		taskMgmtPage.verifyAnnuallyFrequencyEntitlementMonth30th().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Semi Annually, 2nd Month post billing and Actual day 30th$/, function (callback) {
		taskMgmtPage.validateSemiAnnuallyInvoiceFrequencyWithinBilling2ndMonth30th(callback);
	});

	this.Then(/^I can validate application and Invoice frequency Semi Annually, Actual day 30th, Deviation-1, and After billing period$/, function (callback) {
		taskMgmtPage.verifyQuarterlyFrequencyEntitlementMonthDeviation1().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate application and Invoice frequency Annually, Actual day 30th and After billing period$/, function (callback) {
		taskMgmtPage.verifyAnnuallyFrequencyEntitlementMonth30th().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify invoice Date when Invoicing Frequency is Annually, 1st Month post billing and Actual day 30th$/, function (callback) {
		taskMgmtPage.validateAnnuallyInvoiceFrequency30thAfterBilling(callback);
	});

	this.Then(/^I can verify the My Contracts title is (.*)$/, function (myContractsHeader, callback) {
		taskMgmtPage.verifyMyContractsTitle().then(function (value) {
			TestHelper.assertEqual(value, myContractsHeader, callback);
			callback();
		});

	});
	this.Then(/^I can verify the Billing Schedule Title is (.*)$/, function (billingSchedule, callback) {
		taskMgmtPage.verifyBillingScheduleTitle().then(function (value) {
			TestHelper.assertEqual(value, billingSchedule, callback);
			callback();
		});

	});
	this.Then(/^I can verify the Outage Schedule Title is (.*)$/, function (outageSchedule, callback) {
		taskMgmtPage.verifyOutageScheduleTitle().then(function (value) {
			TestHelper.assertEqual(value, outageSchedule, callback);
			callback();
		});

	});
	this.Then(/^I can verify the MyContracts Customers Title is (.*)$/, function (myContractsCustomers, callback) {
		taskMgmtPage.verifyMyContractsCustomersTitle().then(function (value) {
			TestHelper.assertEqual(value, myContractsCustomers, callback);
			callback();
		});

	});
	this.Then(/^I can verify the MyContracts Contract Title is (.*)$/, function (myContractsContract, callback) {
		taskMgmtPage.verifyMyContractsContractTitle().then(function (value) {
			TestHelper.assertEqual(value, myContractsContract, callback);
			callback();
		});

	});
	this.Then(/^I can verify the MyContracts ModuleID Title is (.*)$/, function (myContractsModuleID, callback) {
		taskMgmtPage.verifyMyContractsModelIDTitle().then(function (value) {
			TestHelper.assertEqual(value, myContractsModuleID, callback);
			callback();
		});

	});

	this.Then(/^I can verify the MyContracts Site Title is (.*)$/, function (myContractsSite, callback) {
		taskMgmtPage.verifyMyContractsSiteTitle().then(function (value) {
			TestHelper.assertEqual(value, myContractsSite, callback);
			callback();
		});

	});

	this.Then(/^I can verify the Summary Customer name Title is (.*)$/, function (custNameTitle, callback) {
		taskMgmtPage.verifySummaryCustNameHeader().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the MyContracts Status Title is (.*)$/, function (myContractsStatus, callback) {
		taskMgmtPage.verifyMyContractsStatusTitle().then(function (value) {
			TestHelper.assertEqual(value, myContractsStatus, callback);
			callback();
		});

	});
	this.Then(/^I can verify the MyContracts OpData Title is (.*)$/, function (myContractsOpData, callback) {
		taskMgmtPage.verifyMyContractsOpDataTitle().then(function (value) {
			TestHelper.assertEqual(value, myContractsOpData, callback);
			callback();
		});

	});
	this.Then(/^I can verify the MyContracts TandCs Title is (.*)$/, function (myContractsTandCs, callback) {
		taskMgmtPage.verifyMyContractsTandCsTitle().then(function (value) {
			TestHelper.assertEqual(value, myContractsTandCs, callback);
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation, same rate and other terms and conditions$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationForSameRate(callback);
	});

	this.Then(/^I can verify the Billing calculation with Escalation and Same Escalation rate applied for all billing types$/, function (callback) {
		taskMgmtPage.verifyQuarterlyFrequencyEscalationForSame().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify the Total Amount of Billing calculation with Escalation$/, function (callback) {
		taskMgmtPage.verifyTotalBillableAmount().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate the Total Amount of Billing calculation with Escalation$/, function (callback) {
		taskMgmtPage.billingScheduleInvoiceAmountTxt().then(function () {
			callback();
		});
	});
	this.Then(/^I can wait for the Total Amount of Billing calculation with Escalation$/, function (callback) {
		taskMgmtPage.waitForbillingScheduleInvoiceAmountTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate the Total Amount of Billing calculation with Escalation for different period$/, function (callback) {
		taskMgmtPage.quarterBillingScheduleInvoiceAmountTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate the Total Amount of Billing calculation$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyTotalAmountTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation, Different and other terms and conditions$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationForDifferentRate(callback);
	});
	this.Then(/^I can verify the Billing calculation with Escalation and Different Escalation rate applied for all billing types$/, function (callback) {
		taskMgmtPage.verifyQuarterlyFrequencyEscalationForDifferent().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify the Billing calculation with Different Escalation rate applied for all Monthly Variable billing types$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyEscalationForDifferent().then(function () {
			callback();
		});
	});
	this.Then(/^I can verify the Billing calculation with Different Escalation rate applied for all Monthly billing types$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyEscalationForDifferent1().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Ops Data view edit button$/, function (callback) {
		taskMgmtPage.billingOpsDataViewBtn().then(function () {
			callback();
		});
	});

	/*this.Then(/^I can able to select the from and To date range$/, function (callback) {
		taskMgmtPage.billingOpsDataFromCalendarIcon().then(function(){
				callback();
		});
	});*/

	this.Then(/^I can able to Approve the 1st Month Ops data hours$/, function (callback) {
		taskMgmtPage.approve1stRecords().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Approve the 1st Month Ops data hours$/, function (callback) {
		taskMgmtPage.approve1stRecords(callback);
	});

	this.Then(/^I can able to click on Ops data Billing back button$/, function (callback) {
		taskMgmtPage.billingOpsBackToBillingBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Approve the 1st Month Ops data hours$/, function (callback) {
		taskMgmtPage.approve1stRecords(callback);
	});
	this.Then(/^I can able to validate the Quarter and click on Calculate button$/, function (callback) {
		taskMgmtPage.quarterRequestAccess().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation, with same rate for all billing types for different period$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationForSameRateDifferentPeriod(callback);
	});
	this.Then(/^I can able to select Billing calculation with Escalation, same rate for all billing types for different Monthly period$/, function (callback) {
		taskMgmtPage.validateMonthlyBillingEscalationForSameRateDifferentPeriod(callback);
	});


	this.Then(/^I can verify the Invoice when Escalation be applied & displayed as separate line of calculation with Escalation rate$/, function (callback) {
		taskMgmtPage.verifyQuarterlyFrequencyEscalationSeparateLine().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation, 100FFH with 25 escalation will show as 125FFH$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationFor125(callback);
	});
	this.Then(/^I can able to click on Variable billing schedule Calculate button$/, function (callback) {
		taskMgmtPage.quarterVariableCalculateButton().then(function () {
			callback();
		});
	});


	this.Then(/^I can verify the Invoice when Escalation be applied to the billing rates FFH$/, function (callback) {
		taskMgmtPage.verifyQuarterlyFrequencyFFHEscalation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation and Show escalation by unit by billing type$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationlowestLevelOfDetail(callback);
	});

	this.Then(/^I can able to select Billing calculation with Escalation and Show escalation by unit by billing type for Individual$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationlowestLevelOfIndividualDetail(callback);
	});

	this.Then(/^I can verify the Invoice when Escalation by unit by billing type for Individual$/, function (callback) {
		taskMgmtPage.verifyQuarterlyFrequencyFFHEscalation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Verify the Unit id data$/, function (callback) {
		taskMgmtPage.billingScheduleOpsDataUnitIdTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Validate the Unit id in Escation description$/, function (callback) {
		taskMgmtPage.verifyQuarterlyEscalationUnitIDTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Validate Contract level the Unit id in Escation description$/, function (callback) {
		taskMgmtPage.escalationBillingVariableTypeTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search with Variable and Contract ID$/, function (callback) {
		taskMgmtPage.billingScheduleSearchFld().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Variable description text$/, function (callback) {
		taskMgmtPage.escalationBillingVariableType().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation and Combine all escalation into one line$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationCombineDetail(callback);
	});

	this.Then(/^I can able to Validate the Escation description count$/, function (callback) {
		taskMgmtPage.escalationBillingTypeCount().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search with Multi Project Contract ID$/, function (callback) {
		taskMgmtPage.myMultiProjectContactSearchFld().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation and multiple Project IDs billing split by Site$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationSplitbySite(callback);
	});

	this.Then(/^I can able to verify Equipment and Project IDs$/, function (callback) {
		taskMgmtPage.validationOfEquipmentAndProjectId().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to verify Project IDs$/, function (callback) {
		taskMgmtPage.validationOfEquipmentAndProject().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Validate the Multi Equipment and Project ids count$/, function (callback) {
		taskMgmtPage.validationProjectAndEquipmentIdTxt1().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Validate the Multi Equipment and Project ids percentage$/, function (callback) {
		taskMgmtPage.validationProjectAndEquipmentId().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Escalation and multiple Project IDs billing split by Site Percentage$/, function (callback) {
		taskMgmtPage.validateQuarterlyBillingEscalationSplitbySitePercentage(callback);
	});

	this.Then(/^I can able to select Billing calculation with new description template for Fixed Billing$/, function (callback) {
		taskMgmtPage.validateQuarterlyFixedBillingDescriptionTmplate(callback);
	});

	this.Then(/^I can able to Validate the new description template for Fixed and Variable Billing$/, function (callback) {
		taskMgmtPage.fixedVariableBillingDescriptionTemplate().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Validate the new description template for Milestone Billing$/, function (callback) {
		taskMgmtPage.milestoneBillingDescriptionTemplate().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Fixed billing amount for the entire contract$/, function (callback) {
		taskMgmtPage.validateFixedBillingAmountForEntireContract(callback);
	});

	this.Then(/^I can able to validate the fixed billing amount for the entire contract$/, function (callback) {
		taskMgmtPage.validateInvoiceFixedBillingAmountForEntireContract().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to select Billing calculation with Fixed billing amount for different date ranges$/, function (callback) {
		taskMgmtPage.validateFixedBillingAmountForDifferentDateRanges(callback);
	});

	this.Then(/^I can able to validate the fixed billing amount for different date ranges$/, function (callback) {
		taskMgmtPage.validateInvoiceFixedBillingAmountForEntireContract().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search with Quarter and Contract id (.*)$/, function (actionTitle, callback) {
		taskMgmtPage.createActionTitle(actionTitle).then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search with Monthly and Contract id (.*)$/, function (actionTitle, callback) {
		taskMgmtPage.createActionTitle(actionTitle).then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search with Monthly Contract id (.*)$/, function (actionTitle1, callback) {
		taskMgmtPage.createActionTitle1(actionTitle1).then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search with Non Monetized Contract id (.*)$/, function (actionTitle1, callback) {
		taskMgmtPage.createActionTitle1(actionTitle1).then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search with Fixed Non Monetized Contract id (.*)$/, function (actionTitle2, callback) {
		taskMgmtPage.createActionTitle2(actionTitle2).then(function () {
			callback();
		});
	});

	this.Then(/^I can able to search with Fixed Monetized Contract id (.*)$/, function (actionTitle3, callback) {
		taskMgmtPage.createActionTitle3(actionTitle3).then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with No Fixed billing$/, function (callback) {
		taskMgmtPage.validateNoFixedBilling1(callback);
	});

	this.Then(/^I can able to clear the search data from Billing schedule search field$/, function (callback) {
		taskMgmtPage.billingScheduleSearchFldClear(callback);
	});

	this.Then(/^I can able to validate the No fixed billing amount$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with One rate across the entire contract timeline in Variable billing$/, function (callback) {
		taskMgmtPage.validateNoFixedBilling1(callback);
	});

	this.Then(/^I can able to validate the One rate across the entire contract timeline in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate the Different rates for different fuel type for Quarterly in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling1().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate the Different rates for different fuel type for Monthly in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Different rates across different time period in Variable billing$/, function (callback) {
		taskMgmtPage.validateVariableDifferentRatesAcrossDifferentTimePeriods(callback);
	});

	this.Then(/^I can able to validate the Different rates across different time period in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Billing calculation with Different rates across different range of operations in Variable billing$/, function (callback) {
		taskMgmtPage.validateVariableDifferentRatesAcrossDifferentRangeofOperations(callback);
	});

	this.Then(/^I can able to select Monthly Billing calculation with Different rates for different fuel type in Variable billing$/, function (callback) {
		taskMgmtPage.validateVariableMonthlyDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to select Quartely Billing calculation with Different rates for different fuel type in Variable billing$/, function (callback) {
		taskMgmtPage.validateVariableQuartelyDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to delete created rows in Variable billing$/, function (callback) {
		taskMgmtPage.validateVariableBillingWidgetDelectRows(callback);
	});

	this.Then(/^I can able to delete created rows in Terms and Conditions billing$/, function (callback) {
		taskMgmtPage.validateTermsAndConditionsBillingWidgetDelectRows(callback);
	});

	this.Then(/^I can able to select Anually Billing calculation with Different rates for different fuel type in Variable billing$/, function (callback) {
		taskMgmtPage.validateVariableAnuallyYesDifferentRatesForDifferentFuelType(callback);
	});
	this.Then(/^I can able to validate the Different rates for different fuel type for Anually in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBilling1().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Anually Billing calculation with Different rates for different fuel type and No rate based on ops range in Variable billing$/, function (callback) {
		taskMgmtPage.validateVariableAnuallyNoDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to validate the No Different rates for different fuel type for Anually in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBillingNo().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to select Quarterly Billing calculation with Different rates for different fuel type and No rate based on ops range$/, function (callback) {
		taskMgmtPage.validateVariableQuarterlyNoDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to validate the No Different rates for different fuel type for Quarterly in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBillingNo().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Monthly Billing calculation with Different rates for different fuel type and No rate based on ops range$/, function (callback) {
		taskMgmtPage.validateVariableMonthlyNoDifferentRatesForDifferentFuelType(callback);
	});

	this.Then(/^I can able to validate the No Different rates for different fuel type for Monthly in Variable billing$/, function (callback) {
		taskMgmtPage.verifyQuarterlyNoFixedBillingNo().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate the Milestone type in invoice$/, function (callback) {
		taskMgmtPage.verifyDateBasedMilestoneBilling().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Date Based Milestone in Milestone billing$/, function (callback) {
		taskMgmtPage.validateDateBasedMilestone(callback);
	});

	this.Then(/^I can able to delete created rows in Milestone billing$/, function (callback) {
		taskMgmtPage.validateMilestoneBillingWidgetDelectRow(callback);
	});

	this.Then(/^I can able to click on Forcast tab$/, function (callback) {
		taskMgmtPage.forcastTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to get Cumilative FFH text in Forcast tab$/, function (callback) {
		taskMgmtPage.forcastFFHAmountTxt().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Terms and conditions and Operations based Milestone billings in Milestone billing$/, function (callback) {
		taskMgmtPage.validateOpsBasedMilestone(callback);
	});

	this.Then(/^I can able to validate the Ops data Milestone type invoice$/, function (callback) {
		taskMgmtPage.verifyOpsBasedMilestoneBilling().then(function () {
			callback();
		});
	});

	//Monetization Module 

	this.Then(/^I can able to search with Contract id in My Contacts section (.*)$/, function (contractId, callback) {
		myFleetPage.myContactsSearchOptn(contractId).then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Validate Monetized Fixed Billing adding of rows through Add Rows modal dialog$/, function (callback) {
		myFleetPage.validateAddrowFixedBilling(callback);
	});

	this.Then(/^I can able to Validate Monetized Fixed Billing Delete button$/, function (callback) {
		myFleetPage.validateFixedDeleteBtn(callback);
	});

	this.Then(/^I can able to Validate Monetized Fixed Billing Edit button$/, function (callback) {
		myFleetPage.validateFixedEditBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Commit Contract Terms and Conditions button$/, function (callback) {
		myFleetPage.myContactsCommitBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Validate Monetized Variable Billing adding of rows through Add Rows modal dialog$/, function (callback) {
		myFleetPage.validateAddrowVariableMonetizationBilling(callback);
	});

	this.Then(/^I can able to Validate Monetized Data based Milestone Billing adding of rows through Add Rows modal dialog$/, function (callback) {
		myFleetPage.validateAddrowMilestoneMonetizationBilling(callback);
	});

	this.Then(/^I can able to click on Monetization Tab$/, function (callback) {
		myFleetPage.monetizationTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to wait for Monetization Tab$/, function (callback) {
		myFleetPage.waitFormonetizationTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization ContractId Label$/, function (callback) {
		myFleetPage.monetizationContractIDLbl().then(function (value) {
			//assert.equal(value, 'Contract ID:  ');
			console.log("Contract ID Label: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization ContractId$/, function (callback) {
		myFleetPage.monetizationContractID().then(function (value) {
			//assert.equal(value, 'Contract ID:  ');
			console.log("Contract ID: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization ModelId Label$/, function (callback) {
		myFleetPage.monetizationModelIDLbl().then(function (value) {
			console.log("Model ID Label: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization ModelId$/, function (callback) {
		myFleetPage.monetizationModelID().then(function (value) {
			console.log("Model ID: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization Customer Name Label$/, function (callback) {
		myFleetPage.monetizationCustomerNameLbl().then(function (value) {
			console.log("Customer Name Label: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization Customer Name$/, function (callback) {
		myFleetPage.monetizationCustName().then(function (value) {
			console.log("Customer Name: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization Site Name Label$/, function (callback) {
		myFleetPage.monetizationSiteNameLbl().then(function (value) {
			console.log("Site Name Label: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization Site Name$/, function (callback) {
		myFleetPage.monetizationSiteName().then(function (value) {
			console.log("Site Name: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization Billing Type option Label$/, function (callback) {
		myFleetPage.monetizationBillingTypeOption().then(function (value) {
			assert.equal(value, 'Billing Type');
			console.log("Billing Type Option Label: " + value);
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization Project Id option Label$/, function (callback) {
		myFleetPage.monetizationPeriodEventOption().then(function (value) {
			assert.equal(value, 'Period/Event');
			console.log("Period/Event Option Label: " + value);
			callback();
		});
	});
	this.Then(/^I can able to validate Monetization Invoice Date option Label$/, function (callback) {
		myFleetPage.monetizationInvoiceDateOption().then(function (value) {
			assert.equal(value, 'Invoice Date');
			console.log("Invoice Date Option Label: " + value);
			callback();
		});
	});

	this.Then(/^I can validate Billing calculation Details of Non-monetized components for Fixed billing$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyCurrentDate12().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate Billing calculation Details of Non-monetized components for Variable billing$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyCurrentDate12().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate Billing calculation Details of Non-monetized components for Milestone billing$/, function (callback) {
		taskMgmtPage.verifyMonthlyFrequencyCurrentDate12().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate Billing Monetized MANL number for Fixed billing$/, function (callback) {
		myFleetPage.monetizationMANLNumber().then(function () {
			callback();
		});
	});
	this.Then(/^I can validate Billing Monetized MANL number for Variable billing$/, function (callback) {
		myFleetPage.monetizationMANLNumber().then(function () {
			callback();
		});
	});
	this.Then(/^I can validate Billing Monetized MANL number for Milestone billing$/, function (callback) {
		myFleetPage.monetizationMANLNumber().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Monetization Monetized Amount option Label$/, function (callback) {
		myFleetPage.monetizationMonetizedAmountOption().then(function (value) {
			assert.equal(value, 'Monetized Amount');
			console.log("Monetized Amount Option Label: " + value);
			callback();
		});
	});
	this.Then(/^I can able to validate Monetization Payment Terms option Label$/, function (callback) {
		myFleetPage.monetizationPaymentTermsOption().then(function (value) {
			assert.equal(value, 'Payment Terms');
			console.log("Payment Terms Option Label: " + value);
			callback();
		});
	});
	this.Then(/^I can able to validate Monetization Alpha Provisional Invoice option Label$/, function (callback) {
		myFleetPage.monetizationAlphaProvisionalInvoiceOption().then(function (value) {
			assert.equal(value, 'Alpha Provisional Invoice#');
			console.log("Alpha Provisional Invoice Option Label: " + value);
			callback();
		});
	});
	this.Then(/^I can able to validate Monetization Billing Status option Label$/, function (callback) {
		myFleetPage.monetizationBillingStatusOption().then(function (value) {
			assert.equal(value, 'Billing Status');
			console.log("Billing Status Option Label: " + value);
			callback();
		});
	});

	this.Then(/^I can able to Validate Monetization Dashboard data$/, function (callback) {
		myFleetPage.monetizationDataValidation(callback);
	});

	this.Then(/^I can able to Click on Back to Billing button$/, function (callback) {
		myFleetPage.monetizationBillingBackBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Validate Monetized Fixed and Variable Billing adding of rows through Add Rows modal dialog$/, function (callback) {
		myFleetPage.validateAddrowFixedAndVariableMonetizationBilling(callback);
	});

	// naina
	this.Then(/^I can verify the Summary contractId$/, function (callback) {
		taskMgmtPage.verifySummaryContractIDHeader().then(function () {
			callback();
		});

	});

	this.Then(/^I can able to check the values present$/, function (callback) {
		taskMgmtPage.validateYesbuttonselected().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to check System generated default description$/, function (callback) {
		taskMgmtPage.verifysystemgeneratedquestion().then(function () {
			callback();
		});
	});
	this.Then(/^I can verify the Summary modelId$/, function (callback) {
		taskMgmtPage.verifySummaryModelIDHeader().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary site name$/, function (callback) {
		taskMgmtPage.verifySummarySiteHeader().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary contract start date$/, function (callback) {
		taskMgmtPage.verifySummaryContractstartdate().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary performance date$/, function (callback) {
		taskMgmtPage.verifySummaryPerformancestartdate().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary contract end date$/, function (callback) {
		taskMgmtPage.verifySummaryContractenddate().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary contract currency$/, function (callback) {
		taskMgmtPage.verifySummaryContractcurrency().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary version for Billing$/, function (callback) {
		taskMgmtPage.verifySummaryVersionforbilling().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary version name$/, function (callback) {
		taskMgmtPage.verifySummaryVersionname().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary version date$/, function (callback) {
		taskMgmtPage.verifySummaryVersiondate().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary version description$/, function (callback) {
		taskMgmtPage.verifySummaryVersiondescription().then(function () {
			callback();
		});

	});

	this.Then(/^I can verify the Summary invoice currency$/, function (callback) {
		taskMgmtPage.verifySummaryInvoicingcurrency().then(function () {
			callback();
		});

	});

	this.Then(/^I can able to click on General Terms and Condition dropdown$/, function (callback) {
		taskMgmtPage.generalcontractTandCs().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on fixed billing Terms and Condition tab$/, function (callback) {
		taskMgmtPage.fixedbillingTandCs().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on variable billing Terms and Condition tab$/, function (callback) {
		taskMgmtPage.variablebillingTandCs().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on milestone billing Terms and Condition tab$/, function (callback) {
		taskMgmtPage.milestonebillingTandCs().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on lease billing Terms and Condition dropdown$/, function (callback) {
		taskMgmtPage.leasedbillingTandCs().then(function () {
			callback();
		});
	});

	//Aero Leased Test cases

	this.Then(/^I can able to select Separate Fixed membership fee yes for Aero Leased Unit$/, function (callback) {

		myFleetAero.validateSeparateFixedMembershipFeeYes(callback);
	});

	this.Then(/^I can able to validate options should get changed according to the options selected for Fee Frequency for Aero Leased Unit$/, function (callback) {
		myFleetAero.validateOptionsChangedAccordingtoOptionsSelected(callback);
	});

	// By Suresh

	this.Then(/^I can click on annual seperate and annualComibined radio btns$/, function (callback) {
		taskMgmtPage.verifyAnnulSeprt_AnnualCombinRdiobtns().then(function () {
			callback();
		});
	});


	this.Then(/^I can enter and apply membership fee amount (.*)$/, function (amount, callback) {
		taskMgmtPage.verifyTextbox(amount).then(function () {
			callback();
		});
	});

	this.Then(/^I can choose Proration with yes or no options$/, function (callback) {
		taskMgmtPage.verifyProrationDropdowns().then(function () {
			callback();
		});
	});

	this.Then(/^I can choose Weekly Usage Fee launguage with yes or no options$/, function (callback) {
		taskMgmtPage.verifyWeeklyUsageFeeLanguageDropdowns().then(function () {
			callback();
		});
	});

	this.Then(/^I can add (.*) and (.*) and (.*) and (.*) and (.*) under Equipment Weekly Usage Rates when Weekly Usage Fee Language applicable$/, function (technology, eqipType, fromWeek, toweek, price, callback) {
		taskMgmtPage.addEquipmentWeeklyUsageRates(technology, eqipType, fromWeek, toweek, price, callback);

	});

	this.Then(/^I can verify Does Daily Proration Apply$/, function (callback) {
		myFleetAero.ValidateQuestion().then(function (value) {
			assert.equal(value, '7.2.3.Does Daily Proration Apply?', "Not Equal");
			console.log("Text: " + value);
			callback();
		});
	});

	this.Then(/^I can able to find Variable Operating Hourly Rates apply$/, function (callback) {
		taskMgmtPage.verifyvariableratesquestion(callback);
	});

	this.Then(/^I can able to find Variable Rates$/, function (callback) {
		taskMgmtPage.validateYesButton(callback);
	});

	this.Then(/^I can able to verify Variable Rates$/, function (callback) {
		taskMgmtPage.VariableRatesdropdown().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to enabled or diasbled$/, function (callback) {
		taskMgmtPage.verifyEditable(callback);
	});

	//TC09_AerononLeased

	this.When(/^I confirmed billing calculations I can click on save button$/, function (callback) {
		taskMgmtPage.clickOnSaveButton().then(function () {
			callback();
		});
	});

	this.Then(/^I can download calculation details in csv file$/, function (callback) {
		taskMgmtPage.downloadFileInCSV().then(function () {
			callback();
		});
	});

	this.Then(/^I can download calculation details in Pdf file format$/, function (callback) {

		taskMgmtPage.downloadFileInPDF().then(function () {
			callback();
		});
	});

	this.Then(/^I can download calculation details in Excel file$/, function (callback) {
		taskMgmtPage.downloadFileInExcel().then(function () {
			callback();
		});
	});

	//TC10_AerononLease

	this.Then(/^I can able to click on Approve$/, function (callback) {
		// Write code here that turns the phrase above into concrete actions
		callback(null, 'pending');
	});

	this.Then(/^I can able to click on SendToFoxtrot$/, function (callback) {
		// Write code here that turns the phrase above into concrete actions
		callback(null, 'pending');
	});

	this.Then(/^I can find newly generated MANL number$/, function (callback) {
		// Write code here that turns the phrase above into concrete actions
		callback(null, 'pending');
	});


	//Aeroforecast_TC01

	this.Then(/^I can navigate to Forecast billing page for (.*)$/, function (contractId, callback) {
		taskMgmtPage.naviagateToForecastbillingpage(contractId).then(function () {
			callback();
		});
	});

	this.Then(/^I can verify fields on the Summary section$/, function (callback) {
		taskMgmtPage.VerifySummarysection().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify fields on Ops Data options section$/, function (callback) {
		taskMgmtPage.VerifyOpsdatasection().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify fields on Escalation Configuration section$/, function (callback) {
		taskMgmtPage.VerifyEscaltionsection().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify available units with Cumulative Op Data summary and summary Grid$/, function (callback) {
		taskMgmtPage.VerifyUnitscumulativeDataSummary().then(function () {
			callback();
		});
	});

	this.Then(/^I can view the forecast summary for Fixed$/, function (callback) {
		myFleetAero.forecastSummary(callback);
	});

	this.Then(/^I can opt for manually adjust Ops data$/, function (callback) {
		taskMgmtPage.choosemanualAdjustOpData().then(function () {
			callback();
		});
	});


	this.Then(/^I can verify data calculation for next (\d+) months populated correctly or not$/, function (arg1, callback) {
		taskMgmtPage.VerifyOpDataCalculation().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data calculationn for next (\d+) months populated correctly or not$/, function (arg1, callback) {
		taskMgmtPage.VerifyOpDataCalculationOnManualOpdataSelection().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data logic column for previous years monthly ops data radio btn selection$/, function (callback) {
		taskMgmtPage.verifyDataLogicForPrevYear().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data logic column when user choosed Use average monthly data radio btn$/, function (callback) {
		taskMgmtPage.verifyDataLogicForMonthlyAvg().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data logic column when user choosed Manually Adjust Ops data radio btn$/, function (callback) {
		taskMgmtPage.verifyDataLogicForManvlAdj().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify month column whether contious or not$/, function (callback) {
		taskMgmtPage.verifyMonthSequence().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify AH is editable or not$/, function (callback) {
		taskMgmtPage.verifyAHmanualAdjustment().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify whether Op data table having AH column or not$/, function (callback) {
		taskMgmtPage.verifyAHColumn().then(function () {
			callback();
		});
	});


	// TC_06_AeroForecast

	this.Then(/^I can create new version$/, function (callback) {
		taskMgmtPage.createVersion().then(function () {
			callback();
		});
	});
	this.Then(/^I can select billing types where escalation applied$/, function (callback) {
		taskMgmtPage.seelectBillingtypes().then(function () {
			callback();
		});
	});


	this.Then(/^I can provide escalation rate$/, function (callback) {
		taskMgmtPage.enterEscalationRates().then(function () {
			callback();
		});
	});
	this.Then(/^I can commit terms and conditions$/, function (callback) {
		taskMgmtPage.commitChanges().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on back To billing$/, function (callback) {
		taskMgmtPage.clickBackToBilling().then(function () {
			callback();
		});
	});

	// TC08 
	this.Then(/^I can choose invoice date as (.*) and payment date as (.*)$/, function (invoiceDate, paymentDate, callback) {
		taskMgmtPage.chooseInvoiceDate_paymentdate().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify fixed amount (.*) from forecast table$/, function (fixedAmount, callback) {
		taskMgmtPage.verifyFixedAmount(fixedAmount).then(function () {
			callback();
		});
	});

	this.Then(/^I can verify variable amount (.*)from forecast table$/, function (variableAmount, callback) {

	});

	this.Then(/^I can verify milestone amount (.*)from forecast table$/, function (milestoneAmount, callback) {
		taskMgmtPage.verifyMilestoneAmount(milestoneAmount).then(function () {
			callback();
		});
	});

	this.Then(/^I can check whether the user navigate to Billing Calculation Details page$/, function (callback) {
		myFleetAero.checkBillingCalculation(callback);
	});
	this.Then(/^I can able to verify the Billing Calculation Details Aero NonLeased$/, function (callback) {
		myFleetAero.VerifyBillingCalculationDetailsNonLeased(callback);
	});

	this.Then(/^I can able to check whether the Billing for Period table get displayed Aero NonLeased$/, function (callback) {
		myFleetAero.CheckBillingPeriodTableNonLeased(callback);
	});

	this.Then(/^I can click Adjustment Template link$/, function (callback) {
		myFleetAero.adjustmentTemplate().then(function () {
			callback();
		});
	});

	this.Then(/^I can upload CSV file in Attachments section$/, function (callback) {
		taskMgmtPage.openFileSelector1().then(function () {
			callback();
		});
	});
	// TC_14_

	this.Then(/^I can lock the any fixed amount invoice for the period (.*) and contractId (.*)$/, function (period, contractId, callback) {
		taskMgmtPage.lockFixedAmount(period, contractId).then(function () {
			callback();
		});
	});

	this.Then(/^I can search for same invoice for the period (.*) and (.*) from summary table$/, function (period, contractId, callback) {
		taskMgmtPage.searchForInvoice(period, contractId).then(function () {
			callback();
		});
	});

	this.Then(/^I can search for unlocked invoice for the period (.*) and (.*) from summary table$/, function (unlockInvoicePeriod, contractId, callback) {
		taskMgmtPage.searchForInvoice(unlockInvoicePeriod, contractId).then(function () {
			callback();
		});
	});

	this.Then(/^I conclude that fixed amount (.*) for locked invoice is same even user commited new amount (.*) in TsCs$/, function (oldFixedAmount, fixedAmount, callback) {
		taskMgmtPage.verifyFixedAmountForInvoice(oldFixedAmount).then(function () {
			callback();
		});
	});

	this.Then(/^I can conclude that unlocked invoice forecast fixed amount (.*) affected by new changes from TsCs$/, function (fixedAmount, callback) {
		taskMgmtPage.verifyFixedAmountForInvoice(fixedAmount).then(function () {
			callback();
		});
	});

	//addAdjustment
	this.Then(/^I can click on add adjustment button$/, function (callback) {
		myFleetAero.addAdjustment().then(function (value) {
			console.log("msg: " + value);
			callback();
		});
	});
	//lockForecast
	this.Then(/^I can click on lock forecast button$/, function (callback) {
		myFleetAero.lockForecast(callback);
	});
	//unlockForecast
	this.Then(/^I can verify the presence of Unlock Forecast button$/, function (callback) {
		myFleetAero.unlockForecast(callback);
	});
	this.Then(/^I can verify the presence of ADD Adjustment button$/, function (callback) {
		myFleetAero.addAdjustmentPresence(callback);
	});
	//topMsgForLocked
	this.Then(/^I can verify the message on the top$/, function (callback) {
		myFleetAero.topMsgForLocked().then(function (value) {
			console.log("msg: " + value);
			callback();
		});
	});
	this.Then(/^I can view the forecastlocked summary$/, function (callback) {
		taskMgmtPage.forecastLockedSummary(callback);

	});

	this.Then(/^I can click on Unclock button$/, function (callback) {
		myFleetAero.UnlockForecast(callback);

	});

	//addAdjustmentPresence
	this.Then(/^I can click Manually Adjust OPS data for forecast$/, function (callback) {
		taskMgmtPage.OPSDataOption3(callback);
	});

	//backButton
	this.Then(/^I can click on back button$/, function (callback) {
		myFleetAero.backButton(callback);
	});

	//period
	this.Then(/^I can verify the summary status of the same invoice$/, function (callback) {
		myFleetAero.period(callback);
	});

	this.Then(/^I can view the forecast summary$/, function (callback) {
		taskMgmtPage.forecastSummary(callback);
	});

	this.Then(/^I can click Manually Adjust OPS data for forecast$/, function (callback) {
		taskMgmtPage.OPSDataOption3(callback);
	});

	this.Then(/^I can click Save and Refresh button$/, function (callback) {
		taskMgmtPage.SaveandRefresh(callback);
	});

	//backButton
	this.Then(/^I can click on back button$/, function (callback) {
		myFleetAero.backButton(callback);
	});


	//Chile 

	this.When(/^I created new version I can able to click on General Terms and Condition dropdown$/, function (callback) {
		taskMgmtPage.generalcontractTandCs().then(function () {
			callback();
		});
	});

	this.Then(/^I can add CCL projectId to General terms and conditions$/, function (callback) {
		taskMgmtPage.addCCLProjctID().then(function () {
			callback();
		});
	});

	this.Then(/^I can provide fixed price (.*)$/, function (fixedAmount, callback) {
		taskMgmtPage.enterFixedAmount(fixedAmount).then(function () {
			callback();
		});
	});

	this.Then(/^I can provide variable price (.*)$/, function (variableAmount, callback) {
		taskMgmtPage.enterVariableAmount(variableAmount).then(function () {
			callback();
		});
	});

	this.Then(/^I can provide milestone amount (.*)$/, function (milestoneAmount, callback) {
		taskMgmtPage.enterDateBasedMilestoneAmount(milestoneAmount).then(function () {
			callback();
		});
	});


	this.Then(/^I can navigate to billing calculation details page from CSA billing page using contractId (.*) and monthName (.*)$/, function (contractId, month, callback) {
		taskMgmtPage.navigateToBillingCalulation(contractId, month).then(function () {
			callback();
		});
	});

	this.Then(/^I can validate customer details customer name (.*) and siteName (.*) and contractId (.*) and modelID (.*) and projectID (.*)$/, function
		(customer, siteName, contractId, modelId, projectId, callback) {
		taskMgmtPage.validateCustomerDetails(customer, siteName, contractId, modelId, projectId).then(function () {
			callback();
		});
	});

	this.Then(/^I can validate error message when I forget to fill customer po$/, function (callback) {
		taskMgmtPage.validateCustomerPoErrorMessage().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate error message when I forget to choose Payment Term$/, function (callback) {
		taskMgmtPage.validatePaymentTermErrorMessage().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate error message when I forget to choose Transaction Type$/, function (callback) {
		taskMgmtPage.validateTransactionTypeErrorMessage().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate error message when I forget to choose Bill To from dropdown$/, function (callback) {
		taskMgmtPage.validateBillToErrorMessage().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate error message when I forget to choose Ship To from dropdown$/, function (callback) {
		taskMgmtPage.validateShipToErrorMessage().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate error message when I forget to mention description$/, function (callback) {
		taskMgmtPage.validateDescriptionFieldErrorMessage().then(function () {
			callback();
		});
	});


	this.When(/^I find excel file read data from it$/, function (callback) {
		taskMgmtPage.ReadDataFromXls().then(function () {
			callback();
		});
	});

	this.When(/^I can test then I can implement$/, function (callback) {
		taskMgmtPage.ReadDataFromXls().then(function () {
			callback();
		});
	});
	this.Then(/^I can add description for all existed lines$/, function (callback) {
		taskMgmtPage.addDescription().then(function () {
			callback();
		});
	});

	this.Then(/^I can enter HES and pick up HES date$/, function (callback) {
		taskMgmtPage.enterHESfields().then(function () {
			callback();
		});
	});

	this.When(/^I filled all mandatory fields I can click on save$/, function (callback) {
		taskMgmtPage.saveInvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify whether invoice saved successfully or not$/, function (callback) {
		taskMgmtPage.verifySuccessMessage().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate HES and HES date in downloaded csv file$/, function (callback) {
		taskMgmtPage.validateCsvFileData().then(function () {
			callback();
		});
	});


	//22/10/2019


	this.Then(/^I can download forecast summary in Excel file$/, function (callback) {
		taskMgmtPage.downloadForecastFornonAero().then(function () {
			callback();
		});
	});

	this.Then(/^I can download forecast summaryy in Excel file$/, function (callback) {
		taskMgmtPage.downloadForecastForAeroCnct().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate invoice fixed amount from application and from downloaded file both are same or not$/, function (callback) {
		taskMgmtPage.validateDownloadedDataForFixedInvoice().then(function () {
			callback();
		});

	});

	this.Then(/^I can validate invoice Milestone amount from application and from downloaded file both are same or not$/, function (callback) {
		taskMgmtPage.validateDownloadedDataForMileStoneInvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate invoice Variable amount from application and from downloaded file both are same or not$/, function (callback) {
		taskMgmtPage.validateDownloadedDataForVariableInvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate invoice fixed amount from application and from download file both are same or not$/, function (callback) {
		taskMgmtPage.validateDownloadedDataForFixedInvoiceAero().then(function () {
			callback();
		});

	});

	this.Then(/^I can validate invoice Milestone amount from application and from download file both are same or not$/, function (callback) {
		taskMgmtPage.validateDownloadedDataForMileStoneInvoiceAero().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate invoice Variable amount from application and from download file both are same or not$/, function (callback) {
		taskMgmtPage.validateDownloadedDataForVariableInvoiceAero().then(function () {
			callback();
		});
	});

	this.Then(/^I can search for any variable invoice for the period (.*) and (.*) from summary table$/, function (period, contractId, callback) {
		taskMgmtPage.validateDownloadedDataForVariableInvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can search for invoice which is having varible billing$/, function (callback) {
		taskMgmtPage.searchforUpcomingInvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can open and lock the Invoice$/, function (callback) {
		taskMgmtPage.lockInvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can navigate back to forecast page$/, function (callback) {
		taskMgmtPage.navigateBackToForecast().then(function () {
			callback();
		});
	});

	this.Then(/^Set application frequency monthly and invoice frequency monthly$/, function (callback) {
		ContractTandCsPage.setMonthly_monthly().then(function () { callback() })
	});

	this.Then(/^I can open all available units Op Data$/, function (callback) {
		taskMgmtPage.openAllAvailableUnitsOpdata().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify whether Op data highlighted for invoice locked period$/, function (callback) {
		taskMgmtPage.verifyHighlightedOpData().then(function () {
			callback();
		});
	});

	//TC_11			 		   				 

	this.Then(/^I can choose Op data option as Use previous years monthly Ops data and can download invoice forecast Op data$/, function (callback) {
		taskMgmtPage.choosePreviousYearOption_downld().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify that downloaded data logic column is Previous Year or not$/, function (callback) {
		taskMgmtPage.verifyPreviousYearDatalogic().then(function () {
			callback();
		});
	});

	this.Then(/^I can choose Op data option as Use average monthly data from a previous (\d+) months and can download invoice forecast Op data$/, function (arg1, callback) {
		taskMgmtPage.chooseMonthlyAvgOption_downld().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify that downloaded data logic column is Previous Year Monthly Average or not$/, function (callback) {
		taskMgmtPage.verifyPreviousYearMonthlyAverageDatalogic().then(function () {
			callback();
		});
	});

	this.Then(/^I can choose Op data option as Manually adjust Ops data for forecast and can download invoice forecast Op data$/, function (callback) {
		taskMgmtPage.chooseManualAdjustmentOption_downld().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify that downloaded data logic column is Manual Adjustment or not$/, function (callback) {
		taskMgmtPage.verifyManualAdjustmentDatalogic().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify that downloaded cumulative AH is same as in the application$/, function (callback) {
		// Write code here that turns the phrase above into concrete actions
		callback(null, 'pending');
	});
	// PGS Forecast TCs

	this.Then(/^I can verify BackTo Forecast button presence on top left corner of the page$/, function (callback) {

		taskMgmtPage.verifyBackToForecastButtonPresence().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify customer details customerName (.*) and contractNumber (.*) and siteName (.*)$/, function (customerName, contractId, siteName, callback) {
		taskMgmtPage.verfiyForecastSummaryCustomerDetails(customerName, contractId, siteName).then(function () {
			callback();
		});
	});


	this.When(/^I am on home page I can verify page title as MyFleet$/, function (callback) {
		taskMgmtPage.verifyHomePagetitle().then(function () {
			callback();
		});
	});

	//29/10/2019


	this.Then(/^I can choose option to generate single invoice for all billing types$/, function (callback) {
		taskMgmtPage.chooseAllbillingsOption().then(function () {
			callback();
		});
	});

	this.Then(/^Commit terms and condition to validate escalation in forecast$/, function (callback) {
		ContractTandCsPage.commit_Ts_Cs_To_Validate_Escaltion_In_Forecast().then(function () { callback() })
	});

	this.Then(/^I can provide escalation rate (.*)$/, function (escaltion, callback) {
		ContractTandCsPage.provide_Esclation(escaltion).then(function () { callback() })
	});

	this.Then(/^I can choose option as same escalation for all billing types$/, function (callback) {
		taskMgmtPage.chooseSameEscalationForAllBillingTypese().then(function () {
			callback();
		});
	});

	this.Then(/^I can opt for Use previous years monthly Ops data$/, function (callback) {
		taskMgmtPage.choosePreviousYearOption().then(function () {
			callback();
		});
	});

	this.Then(/^Click on back To Forecast button$/, function (callback) {
		ContractTandCsPage.clickOnBackButtonInForecastDetails().then(function () { callback() })
	});

	this.Then(/^I can opt for Use average monthly data from previous year$/, function (callback) {
		taskMgmtPage.chooseMonthlyAvgOption().then(function () {
			callback();
		});
	});

	this.Then(/^I can opt for Manually Adjust Ops data$/, function (callback) {
		taskMgmtPage.chooseManualAdjustmentOption().then(function () {
			callback();
		});
	});


	this.Then(/^I can select Use Current Rate option$/, function (callback) {
		taskMgmtPage.chooseUseCurrentRateOption().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on Save and Refresh$/, function (callback) {
		taskMgmtPage.clickOnSaveAndReferesh().then(function () {
			callback();
		});
	});

	this.Then(/^I can choose op factor as AH$/, function (callback) {
		taskMgmtPage.chooseAHOpeartingFactor().then(function () {
			callback();
		});
	});


	this.Then(/^I can verify Escalation (.*) on invoice whether correctly applied or not$/, function (escaltion, callback) {
		taskMgmtPage.validateAppliedEscalation(escaltion).then(function () {
			callback();
		});
	});

	this.Then(/^I can verify Escalation (.*) on invoice whether correctly applied on (.*) or not$/, function (escaltion, fixedAmount, callback) {
		taskMgmtPage.validateEscaltion(escaltion, fixedAmount).then(function () {
			callback();
		});
	});


	//04/NOv/2019

	this.Then(/^I can enter Escaltion (.*) as Adjustment in escalation configuration section$/, function (escaltion, callback) {
		taskMgmtPage.adjustEscalation(escaltion).then(function () {
			callback();
		});
	});


	this.Then(/^I can select fee frequency as monthly fee$/, function (callback) {
		taskMgmtPage.chooseMonthlyFeeFrequency().then(function () {
			callback();
		});
	});

	this.Then(/^I can select Invoice freqency per month$/, function (callback) {
		taskMgmtPage.chooseMonthlyInvoiceFrequency().then(function () {
			callback();
		});
	});

	this.Then(/^I can select fee mode for One rate across the entire contract timeline$/, function (callback) {
		taskMgmtPage.chooseOneRateAcrossEntireContract().then(function () {
			callback();
		});
	});

	this.Then(/^Fill varibale amount (.*) details under variable billing section$/, function (variable, callback) {
		ContractTandCsPage.fillVariableBillingTermsToCheckvariableAmount(variable).then(function () { callback() })
	});

	this.Then(/^Fill terms and conditions to check variable amount in forecast summary$/, function (callback) {
		ContractTandCsPage.fillMonthly_MonthlyInvoiceConditons_To_Check_FixORVaribaleBilling().then(function () { callback() })
	});

	this.Then(/^Identfy Op data which is not approved on any month and go to Trubine Op Data for (.*) appove on same month with actualhours (.*)$/, function (contractId, actualhours, callback) {
		taskMgmtPage.verifyOpdata_varibleAmountInForecast(contractId, actualhours).then(function () {
			callback();
		});
	});

	// Rahul

	this.Then(/^I can verify data logic column for previous years monthly ops data radio btn selection for non highlighted rows$/, function (callback) {
		taskMgmtPage.verifyNonHighlightedDataLogicForPrevYear().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data logic column for previous years monthly ops data radio btn selection for highlighted rows (.*)$/, function (highlighted_prev, callback) {
		taskMgmtPage.verifyHighlightedDataLogicForPrevYear(highlighted_prev).then(function () {
			callback();
		});
	});


	this.Then(/^I can verify data logic column when user choosed Use average monthly data radio btn for non highlighted rows$/, function (callback) {
		taskMgmtPage.verifyNonHighlightedDataLogicForMonthlyAvg().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data logic column when user choosed Use average monthly data radio btn for highlighted rows (.*)$/, function (highlighted_monthly, callback) {
		taskMgmtPage.verifyHighlightedDataLogicForMonthlyAvg(highlighted_monthly).then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data logic column when user choosed Manually Adjust Ops data radio btn for non highlighted rows$/, function (callback) {
		taskMgmtPage.verifyNonHighlightedDataLogicForManvlAdj().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data logic column when user choosed Manually Adjust Ops data radio btn for highlighted rows (.*)$/, function (highlighted_manually, callback) {
		taskMgmtPage.verifyHighlightedDataLogicForManvlAdj(highlighted_manually).then(function () {
			callback();
		});
	});

	this.Then(/^I can validate updated Op data (.*) along with variable amount (.*) and nunmber of units (.*)$/, function (actualhours, variable, units, callback) {
		taskMgmtPage.validateVariableAmount(actualhours, variable, units).then(function () {
			callback();
		});
	});

	// BY Rahul 15/11/2019


	this.Then(/^I can verify manual data calculation for next one year populated correctly or not$/, function (callback) {
		taskMgmtPage.VerifyManualOpDataCalculation().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify Manual AH is editable or not$/, function (callback) {
		taskMgmtPage.verifyAHManualAdjustment().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify data calculation for next one year populated correctly or not$/, function (callback) {
		taskMgmtPage.VerifyOppDataCalculation().then(function () {
			callback();
		});
	});

	this.Then(/^I can open and lock (.*) invoice in Forcast summary table$/, function (period, callback) {
		taskMgmtPage.openAndLockInvoice(period).then(function () {
			callback();
		});
	});

	this.Then(/^I can wait for Review button (.*) invoice in Forcast summary table$/, function (period, callback) {
		taskMgmtPage.openAndLockInvoice(period).then(function () {
			callback();
		});
	});

	this.Then(/^I can go back to Forcast summary page$/, function (callback) {
		taskMgmtPage.backToforcastSummaryPage().then(function () {
			callback();
		});
	});

	this.Then(/^I can go back to Forcast summary page after unlocked$/, function (callback) {
		taskMgmtPage.backToforcastSummaryPageAfterUnlock().then(function () {
			callback();
		});
	});

	this.Then(/^I can open and unlock (.*) invoice in Forcast summary table$/, function (period, callback) {
		taskMgmtPage.openAndUnLockInvoice(period).then(function () {
			callback();
		});
	});

	this.Then(/^I can open and Lock (.*) invoice in Forcast summary table$/, function (period, callback) {
		taskMgmtPage.openAndLockInvoice1(period).then(function () {
			callback();
		});
	});

	this.Then(/^I can open and unlock invoice in Forcast summary table$/, function (callback) {
		taskMgmtPage.UnLockInvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify whether (.*) invoice is unlocked or not in summary page$/, function (invoice, callback) {
		taskMgmtPage.verifyUnLockedInvoice(invoice).then(function () {
			callback();
		});
	});

	this.Then(/^I can Reopen (.*) invoice and verify that invoice is still unlocked$/, function (invoice, callback) {
		taskMgmtPage.reOpenAndVerifyLockedInvoice(invoice).then(function () {
			callback();
		});
	});

	// Convertion Rate specs

	this.Then(/^I can select more than one proejct Ids$/, function (callback) {
		taskMgmtPage.selectMultipleProjects().then(function () {
			callback();
		});
	});

	this.Then(/^I can Select same currency type on one project and different currency types on other project$/, function (callback) {
		taskMgmtPage.selectCurrencytype().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify that convertion rate is Editable for the project which has different currency type on Contract and Invoice$/, function (callback) {
		taskMgmtPage.verifyConvertionRateAdjustment().then(function () {
			callback();
		});
	});


	this.Then(/^I can test that convertion rate is Not Editable for the project which has same currency type on Contract and Invoice$/, function (callback) {
		taskMgmtPage.verifyDefaultConvertionRate().then(function () {
			callback();
		});
	});

	this.Then(/^I can conclude whether convertion rate is as per MOR rate or not$/, function (callback) {
		taskMgmtPage.verifyMORRate().then(function () {
			callback();
		});
	});

	this.Then(/^I can check exported convertion value and app showing value both are same or not$/, function (callback) {
		taskMgmtPage.verifyMORRate().then(function () {
			callback();
		});
	});

	// 4/12/2019
	this.Then(/^I can click on view or edit button$/, function (callback) {
		taskMgmtPage.clickonTurbineOpdataEditButton().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify whether user navigated to Turbine Op data page or not$/, function (callback) {
		taskMgmtPage.verifyTurbineOpDataPageHeader().then(function () {
			callback();
		});
	});

	this.When(/^I am on Turbine Op data page I can Hours Export Parameters Cumulative fields presence on the page$/, function (callback) {
		taskMgmtPage.verifyTabsAvailabilityOnpage().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify Contract Cumulative Summary Hours M&D and Hours User Corrected sections under Hour tab$/, function (callback) {
		taskMgmtPage.verifySectionsUnderHoursTab().then(function () {
			callback();
		});
	});



	this.Then(/^I can click on Hours M and D section$/, function (callback) {
		taskMgmtPage.clickOnMandDsection().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify table columns$/, function (callback) {
		taskMgmtPage.verifyTableColumnHeader().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on Hours user corrected section$/, function (callback) {
		taskMgmtPage.clickOnHoursUserCorrected().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on any approved month name$/, function (callback) {
		taskMgmtPage.clickOnAnyApprovedMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify that approved op data is not editable$/, function (callback) {
		taskMgmtPage.verifyApprovedOpdataModification().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on close button$/, function (callback) {
		taskMgmtPage.clickOnCloseButton().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on any unapproved month$/, function (callback) {
		taskMgmtPage.clickOnAnyunapprovedMonth().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify displayed table headers$/, function (callback) {
		taskMgmtPage.verifyOpHoursTableColumnHeader().then(function () {
			callback();
		});
	});

	this.Then(/^I can clcik on Addrow button$/, function (callback) {
		taskMgmtPage.clickOnAddRowButton().then(function () {
			callback();
		});

	});

	this.Then(/^I can click on approve button$/, function (callback) {
		taskMgmtPage.clickOnApproveButton().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate error message$/, function (callback) {
		taskMgmtPage.validateOpdataErrorMessage().then(function () {
			callback();
		});
	});

	this.Then(/^I can select Change reason$/, function (callback) {
		taskMgmtPage.changeReasonSelect().then(function () {
			callback();
		});
	});

	this.Then(/^I can save entered hours$/, function (callback) {
		taskMgmtPage.saveEnteredOpData().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify whenther able to reset entered data or not$/, function (callback) {
		taskMgmtPage.verifyResetOpdata().then(function () {
			callback();
		});
	});

	this.Then(/^I can Verify the calculation for shutdown hours is displayed accurately$/, function (callback) {
		taskMgmtPage.validateAddedDetailsInHoursUsercorrectedTable().then(function () {
			callback();
		});
	});




	this.Then(/^I can verify starts availability on the screen$/, function (callback) {
		taskMgmtPage.verifyStartsSectionFields().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on download option$/, function (callback) {
		taskMgmtPage.clickOnDownloadUploadbtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on download unapproved starts$/, function (callback) {
		taskMgmtPage.clickondownloadunapprovedstarts().then(function () {
			callback();
		});
	});

	this.Then(/^I can select date range and can download the file$/, function (callback) {
		taskMgmtPage.downloadUnapprovedData().then(function () {
			callback();
		});
	});



	this.Then(/^I can click on Add Missed Starts button$/, function (callback) {
		taskMgmtPage.clickOnAddmissedStartsbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify Approve pending starts button presence$/, function (callback) {
		taskMgmtPage.verifyApprovePendingStartsbtn().then(function () {
			callback();
		});
	});

	this.Then(/^I validate error messages for mandatory fields$/, function (callback) {
		taskMgmtPage.validateErrormessagesOnAddMissedStarts().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify success message$/, function (callback) {
		taskMgmtPage.verifySuccessMessageOnStartsAddition().then(function () {
			callback();
		});
	});


	this.Then(/^I can click on Export Tab$/, function (callback) {
		taskMgmtPage.ClickOnExportTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify Excel rdio btn default selection$/, function (callback) {
		taskMgmtPage.verifyExcelRadioBtnDefaultselection().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on All check box$/, function (callback) {
		taskMgmtPage.clickOnAllCheckBox().then(function () {
			callback();
		});
	});

	this.Then(/^I can select from date and To date$/, function (callback) {
		taskMgmtPage.selectFromdateANdTodates().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify validation message on Data check boxes$/, function (callback) {
		taskMgmtPage.verifyValidationMessagesOnData().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify validation message on Data type check boxes$/, function (callback) {
		taskMgmtPage.verifyValidationMessagesOnDataType().then(function () {
			callback();
		});
	});

	this.Then(/^Finally I can download OP data for valid inputs$/, function (callback) {
		taskMgmtPage.verifyOpdatafiledownloadViaExportMR().then(function () {
			callback();
		});
	});



	this.Then(/^I can click on Parameters tab$/, function (callback) {
		taskMgmtPage.clickOnParametersTab().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate Unit parameters table headers$/, function (callback) {
		taskMgmtPage.verifyparametersTableHeaders().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify Parameters names on the table$/, function (callback) {
		taskMgmtPage.verifyParameterNames().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate error message when try to add parameters when date ranges are COD and EOT$/, function (callback) {
		taskMgmtPage.verifyErrorMessageonParameterAdd().then(function () {
			callback();
		});
	});

	this.Then(/^I can edit parameters when date ranges are COD and EOT$/, function (callback) {
		taskMgmtPage.editParameters().then(function () {
			callback();
		});
	});

	this.Then(/^I can verify success message once parameter added$/, function (callback) {
		taskMgmtPage.verifyParameterUpdatedSuccessmsg().then(function () {
			callback();
		});
	});

	//TC24

	this.Then(/^I can click on save changes button$/, function (callback) {
		taskMgmtPage.clickSavechangesbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can navigate to billing Adim page for (.*)$/, function (contractId, callback) {
		taskMgmtPage.clickBillingAdmin(contractId).then(function () {
			callback();
		});
	});

	this.Given(/^I can able to select monitization flag$/, function (callback) {
		taskMgmtPage.checkMonitizationflag(callback);
	});

	this.Given(/^I can able to check actual hours be tracked for the contracts$/, function (callback) {
		taskMgmtPage.Trueupforactualhours(callback);
	});

	this.Given(/^I can able to check Trueup values$/, function (callback) {
		taskMgmtPage.VerifyTrueup().then(function () {
			callback();
		});
	});

	this.Given(/^I can able to check default date selection$/, function (callback) {
		taskMgmtPage.Defaultdateselection(callback);
	});

	this.Then(/^I can click on AddRow button$/, function (callback) {
		taskMgmtPage.clickAddRowbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can add values in Monetization true up popup$/, function (callback) {
		taskMgmtPage.AddMonetizationTrueup().then(function () {
			callback();
		});
	});

	this.Given(/^Verify that lock button presence on the page it should not available$/, function (callback) {
		taskMgmtPage.VerifyLockButtonPresence().then(function () {
			callback();
		});
	});




	this.Then(/^Click on back button$/, function (callback) {
		taskMgmtPage.backToforecast().then(function () {
			callback();
		});
	});

	this.Then(/^download forecast summary into excel file$/, function (callback) {
		taskMgmtPage.downloadFileInExcelToCheckMonetised().then(function () {
			callback();
		});
	});

	this.Then(/^Verify that monetised true up inovice available in the list or not$/, function (callback) {
		taskMgmtPage.VerifymonetisedInvoiceInTheDownoloadedFile().then(function () {
			callback();
		});
	});





	this.Given(/^I can able to check edit and delete button present$/, function (callback) {
		taskMgmtPage.VerifyEditandDeletebutton(callback);
	});

	this.Then(/^I can click on monetization confirmation button$/, function (callback) {
		taskMgmtPage.clickConfirm().then(function () {
			callback();
		});
	});

	this.Then(/^I can navigate to the monetozation trueup page of the table$/, function (callback) {
		taskMgmtPage.checkforMonetizationtrueup().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on Review button$/, function (callback) {
		taskMgmtPage.clickReviewButton().then(function () {
			callback();
		});
	});

	this.Given(/^I can check new trueup is present$/, function (callback) {
		taskMgmtPage.VerifyNewTrueup().then(function () {
			callback();
		});
	});

	this.Given(/^I can able to check Lock forecast button is present$/, function (callback) {
		taskMgmtPage.VerifyLockForecastButton().then(function () {
			callback();
		});
	});


	this.Then(/^Add monetization true up details in general TsCs section$/, function (callback) {
		taskMgmtPage.AddMonetizationTrueup().then(function () {
			callback();
		});
	});

	this.Then(/^Verify monetisation true records in forecast summary section$/, function (callback) {
		taskMgmtPage.VerifyNewTrueup().then(function () {
			callback();
		});
	});



	this.Given(/^I can able to check Trueup table values$/, function (callback) {
		taskMgmtPage.VerifyTrueupTablevalues().then(function () {
			callback();
		});
	});

	this.Then(/^I can validate Monetized trueup from application and from downloaded file both are same or not$/, function (callback) {
		taskMgmtPage.validateDownloadedTrueupvalueInvoice().then(function () {
			callback();
		});
	});

	this.Given(/^I can click on save as excel button$/, function (callback) {
		taskMgmtPage.clickSaveasExcelbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on I billed this event out of MyFleet$/, function (callback) {
		taskMgmtPage.clickBilledthiseventlink().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on AR invoice dropdown$/, function (callback) {
		taskMgmtPage.SelectARInvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can check whether Manual is present or not$/, function (callback) {
		taskMgmtPage.Verifymanualpresent().then(function () {
			callback();
		});
	});

	this.Given(/^I can able to check Billing calculation page details$/, function (callback) {
		taskMgmtPage.VerifyBillingCalculationPage().then(function () {
			callback();
		});
	});

	this.Given(/^I can able to check fileds are present or not in the Billing for period table$/, function (callback) {
		taskMgmtPage.VerifyBillingforperiodtable().then(function () {
			callback();
		});
	});

	this.Given(/^I can able to enter the invoice amount$/, function (callback) {
		taskMgmtPage.BilledOutInvoiceAmount().then(function () {
			callback();
		});
	});

	this.Given(/^I can able to select invoice currency$/, function (callback) {
		taskMgmtPage.SelectInvoiceCurr().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to approve Variable Manual invoice$/, function (callback) {
		taskMgmtPage.variableManualInvoiceApproveBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to Unapprove Variable Manual invoice$/, function (callback) {
		taskMgmtPage.variableManualInvoiceUnapproveBtn().then(function () {
			callback();
		});
	});

	this.Given(/^I can able to click on upload button$/, function (callback) {
		taskMgmtPage.clickUploadButton().then(function () {
			callback();
		});
	});

	this.Then(/^I can upload file in Attachments section$/, function (callback) {
		taskMgmtPage.BilledOutUploadButton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select date for invoice$/, function (callback) {
		taskMgmtPage.InvoiceDateSelection().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select payment due date$/, function (callback) {
		taskMgmtPage.PaymentDueDateSelection().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select reason for why did you prefer to billed out$/, function (callback) {
		taskMgmtPage.PrefferedBilledOut().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on i confirm button$/, function (callback) {
		taskMgmtPage.IConfirmbutton().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to click on billing schedule review button$/, function (callback) {
		taskMgmtPage.billingScheduleReviewBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can choose option to generate combined single invoice$/, function (callback) {
		taskMgmtPage.chooseCombineassingleinvoice().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on contract allow billing escalation$/, function (callback) {
		taskMgmtPage.clickAllowbillingescalation().then(function () {
			callback();
		});
	});

	this.Then(/^I can choose option as same escalation rate for all billing types$/, function (callback) {
		taskMgmtPage.chooseSameEscalationrateForAllBillingTypes().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to check the status and click on calculate button$/, function (callback) {
		taskMgmtPage.billingScheduleStatusandCalculate().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to check the Amount and click on calculate button$/, function (callback) {
		taskMgmtPage.billingScheduleAmountandCalculate().then(function () {
			callback();
		});
	});

	this.Then(/^I can select Invoice freqency as monthly$/, function (callback) {
		taskMgmtPage.chooseInvoiceFrequency().then(function () {
			callback();
		});
	});

	this.Then(/^I can select fee frequency as monthly$/, function (callback) {
		taskMgmtPage.chooseFeeFrequencyMonthly().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on Review button of Monetized True-up And verify Details$/, function (callback) {
		taskMgmtPage.MonetizationTrueupPresent().then(function () {
			callback();
		});
	});
	this.Then(/^I can check the billed out status$/, function (callback) {
		taskMgmtPage.BilledOutMessage().then(function () {
			callback();
		});
	});
	this.Then(/^I can click on the download link from uploaded billed out documents section$/, function (callback) {
		taskMgmtPage.ClickDownload().then(function () {
			callback();
		});
	});



	this.When(/^User on home page click on Create Unscheduled Invoices button$/, function (callback) {
		billingHomePage.clickOnCreateUnscheduledInvoices().then(function () { callback(); });
	});

	this.Then(/^Check whether popup title is Create Unscheduled Invoices$/, function (callback) {
		CreateUnschInvPage.verifyPopupTitle().then(function () { callback() })
	});

	this.Then(/^Select any PGS contract Id (.*) from Contract Number dropdown$/, function (contractId, callback) {
		CreateUnschInvPage.selectContractId(contractId).then(function () { callback() })
	});

	this.Then(/^Select model Id from model Id dropdown$/, function (callback) {
		CreateUnschInvPage.selectModelId().then(function () { callback() });
	});

	this.Then(/^Click on Manual Invoice radio button$/, function (callback) {
		CreateUnschInvPage.selectManualInvoiceType().then(function () { callback() })
	});

	this.Then(/^Check the check boxes on avaialble project id$/, function (callback) {
		CreateUnschInvPage.chooseProjectId().then(function () { callback() })
	});

	this.Then(/^Choose Yes option to create manual schedule$/, function (callback) {
		CreateUnschInvPage.clickOnmanualScheduleRdobtn().then(function () { callback() })
	});

	this.Then(/^Enter start and end dates in recurrence range section$/, function (callback) {
		CreateUnschInvPage.selectStart_EndDates().then(function () { callback() })
	});

	this.Then(/^Select billing frequency as monthly$/, function (callback) {
		CreateUnschInvPage.chooseMonthlyBillingFrequency().then(function () { callback() })
	});

	this.Then(/^Click on proceed and Save button$/, function (callback) {
		CreateUnschInvPage.clickOnProceedAndVerifysuccessMessage().then(function () { callback() })
	});

	this.Then(/^Validate created manual invoice on (.*) from Billing schedule when date period choosen$/, function (contractId, callback) {
		CreateUnschInvPage.validateGeneratedInvoiceOnDates(contractId).then(function () { callback() });
	});

	this.Then(/^Validate created manual invoice on (.*) from Billing schedule when no of Occurences choosen$/, function (contractId, callback) {
		CreateUnschInvPage.validateGeneratedInvoiceOnOccurences(contractId).then(function () { callback() });
	});

	this.Then(/^Enter start date and no of Occurences$/, function (callback) {
		CreateUnschInvPage.enterNoOfOccurences().then(function () { callback() });
	});



	this.Then(/^Navigate to created unscheduled invoice on same contract (.*)$/, function (contractId, callback) {
		billingHomePage.openSecondmonthInvoice(contractId).then(function () { callback() })
	});


	this.Then(/^Click on Add adjustments$/, function (callback) {
		billingHomePage.clickOnAddAdjustment().then(function () { callback() })
	});



	this.Then(/^Fill all the required fields from the popup and click on Add$/, function (callback) {
		billingHomePage.fillAdjustmentDetails(5, 6).then(function () { callback() })
	});



	this.Then(/^Validate the same details whether added to billing period table or not$/, function (callback) {
		billingHomePage.validateAddedAdjustmentViaPopup().then(function () { callback() })
	});



	this.Then(/^Download adjustment template by click on adjustment template button$/, function (callback) {
		billingHomePage.downloadAdjustmentTemplate().then(function () { callback() })
	});


	this.Then(/^Open and fill required fields and then upload same file$/, function (callback) {
		billingHomePage.editAdjustmentTemplate().then(function () { callback() })
	});



	this.Then(/^Validate file uploaded values in the billing period table$/, function (callback) {
		billingHomePage.validateAddedAdjustmentViaExcel().then(function () { callback() })
	});


	this.Then(/^Search for same manual invoice in forecast summary and verify the status whether locked or not$/, function (callback) {
		billingHomePage.searchForInvoice_VerifyInvoiceLock().then(function () { callback() })
	});

	this.Then(/^Validate whether user adjusted values in billing reflected in forecast summary or not$/, function (callback) {
		billingHomePage.validateInvoiceInForecastSummaryTable().then(function () { callback() })
	});


	this.Then(/^Go to same manual invoice in forecast summary$/, function (callback) {
		billingHomePage.goToInvoiceFromForecastSummary().then(function () { callback() })
	});

	this.Then(/^Verify adjustment lines and invoice total$/, function (callback) {
		billingHomePage.verifyInvoiceAdjustmentLines().then(function () { callback() })
	});

	this.Then(/^Click on unlock invoice button$/, function (callback) {
		billingHomePage.unlockInvoice().then(function () { callback() })
	});

	this.Then(/^Edit existing record$/, function (callback) {
		billingHomePage.editExistRecord().then(function () { callback() })
	});


	this.Then(/^Update invoice amount and all other fields, click on save$/, function (callback) {
		billingHomePage.updateDetails().then(function () { callback() })
	});

	this.Then(/^Lock same invoice again$/, function (callback) {
		billingHomePage.lockInvoice().then(function () { callback() })
	});

	this.Then(/^Verify same invoice on (.*) in actual billing$/, function (contractId, callback) {
		billingHomePage.validateEditedDetailsInActualBilling_P_A(contractId).then(function () { callback() })
	});

	this.Then(/^Verify same invoice amount on (.*) in actual billing$/, function (contractId, callback) {
		billingHomePage.validateEditedDetailsInActualBilling_CreditMemo(contractId).then(function () { callback() })
	});

	this.Then(/^Open the same manual invoice on contractId (.*) and delete it$/, function (contractId, callback) {
		billingHomePage.deleteInvoiceFromActualBilling(contractId).then(function () { callback() })
	});

	this.Then(/^Validate whether invoice on contractId (.*) deleted from actual billing$/, function (contractId, callback) {
		billingHomePage.validateDeletedInvoiceFromBilling(contractId).then(function () { callback() })
	});

	this.Then(/^Validate same invoice whether deleted from forecast summary$/, function (callback) {
		billingHomePage.validateDeletedInvoiceFromForecast().then(function () { callback() })
	});


	this.Then(/^Click on Credit Memo Invoice radio button and proceed button$/, function (callback) {
		CreateUnschInvPage.selectCreditInvoiceRdobtn().then(function () { callback() })
	});

	this.Then(/^Fill all required fields along with credit memo reason$/, function (callback) {
		billingHomePage.fillAdjustmentDetailsOnCreditMemo().then(function () { callback() })
	});

	this.Then(/^Search created credit memo invoice and verify whether locked or not$/, function (callback) {
		billingHomePage.searchForCreditMemoInvoice_VerifyInvoiceLock().then(function () { callback() })
	});

	this.Then(/^Validate whether user adjusted amount in billing reflected in forecast summary or not$/, function (callback) {
		billingHomePage.validateCreditMemo_InvoiceInForecastSummaryTable().then(function () { callback() })
	});

	this.Then(/^I can able to click on Back button$/, function (callback) {
		billingHomePage.clickOnBackButton().then(function () {
			callback();
		});
	});

	this.Then(/^Click on forecast summary review button$/, function (callback) {
		billingHomePage.clickOnReviewButton().then(function () { callback() })
	});

	this.Then(/^Click on Debit Memo Invoice radio button and proceed button$/, function (callback) {
		CreateUnschInvPage.selectDebitInvoiceRdobtn().then(function () { callback() })
	});

	this.Then(/^Fill all required fields along with Debit memo reason$/, function (callback) {
		billingHomePage.fillAdjustmentDetailsOnDebit1().then(function () { callback() })
	});

	this.Then(/^Search created Debit memo invoice and verify whether locked or not$/, function (callback) {
		billingHomePage.searchForDebitMemoInvoice_VerifyInvoiceLock().then(function () { callback() })
	});

	this.Then(/^Validate whether user adjusted amount in billing reflected in forecast summary or nott$/, function (callback) {
		billingHomePage.validateDebitMemo_InvoiceInForecastSummaryTable().then(function () { callback() })
	});

	this.Then(/^Verify debit memo invoice amount on (.*) in actual billing$/, function (contractId, callback) {
		billingHomePage.validateEditedDetailsInActualBilling_DebitMemo(contractId).then(function () { callback() })
	});

	this.Then(/^Validate Debit memo invoice whether deleted from forecast summary$/, function (callback) {
		billingHomePage.validateDeletedInvoiceFromForecast().then(function () { callback() })
	});

	this.Then(/^I can able to click on billing schedule review button$/, function (callback) {
		taskMgmtPage.billingScheduleReviewBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can check whether Reoccuring field is displayed in Adjustment table$/, function (callback) {
		taskMgmtPage.ReoccuringFee().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to click on Add Adjustments button$/, function (callback) {
		taskMgmtPage.ClickAddAdjustmentbutton().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to check whether the radio button in recoccuring fee are present$/, function (callback) {
		taskMgmtPage.ReoccuringFeeradiobuttons().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to check whether the text is present at the bottom of the alert window$/, function (callback) {
		taskMgmtPage.Alertwindowtext().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to add values in the alert model with reoccuring fee as No selected$/, function (callback) {
		taskMgmtPage.AddAdjustementfieldsdatawithNo().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Add button$/, function (callback) {
		taskMgmtPage.ClickAddutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to check the newly added adjustement reoccuring value$/, function (callback) {
		taskMgmtPage.ChecknewadjuReoccuringfee().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to add values in the alert model with reoccuring fee as yes selected$/, function (callback) {
		taskMgmtPage.AddAdjustementfieldsdatawithYes().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to check the new reoccuring value$/, function (callback) {
		taskMgmtPage.CheckReoccuringvalue().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on the back button$/, function (callback) {
		taskMgmtPage.ClickBackbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select the reason for clicking back button$/, function (callback) {
		taskMgmtPage.SelectReasontoconfirm().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify the reoccuring value added$/, function (callback) {
		taskMgmtPage.Verifyreoccuringvalue().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on the review button and navigate to the forecast screen$/, function (callback) {
		taskMgmtPage.clickreviewforecastbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can navigate to billing page for past invoice (.*)$/, function (ContractID, callback) {
		taskMgmtPage.Reviewpastinvoice(ContractID).then(function () {
			callback();
		});
	});

	this.Then(/^I can select specific date range on billing schedule$/, function (callback) {
		taskMgmtPage.selectDateOnBillingSchedule().then(function () {
			callback();
		});
	});

	this.Then(/^Refresh the page$/, function (callback) {
		billingHomePage.refreshPage().then(function () { callback() })
	});

	this.Then(/^I can able to select the range for the past invoice data$/, function (callback) {
		taskMgmtPage.Pastinvoicedateselection().then(function () {
			callback();
		});
	});

	this.Then(/^I can navigate to billing page for approved invoices (.*)$/, function (ApprvedInvoice, callback) {
		taskMgmtPage.Reviewapprovedinvoice(ApprvedInvoice).then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on view button$/, function (callback) {
		taskMgmtPage.Clickviewbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on edit button in the adjustment table$/, function (callback) {
		taskMgmtPage.ClickEditbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to edit No to Yes radio button in the upadte adjustment popup$/, function (callback) {
		taskMgmtPage.ClickYesradiobutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click update button in the update adjustments popup$/, function (callback) {
		taskMgmtPage.Clickupdatebutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to verify the newly added reoccuring value$/, function (callback) {
		taskMgmtPage.VerifyNewadjustmentrow().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on delete button in the adjustments table$/, function (callback) {
		taskMgmtPage.Clickdeletebutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on create unscheduled invoices button$/, function (callback) {
		taskMgmtPage.ClickCreateUnscheduledInvoices().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select contract number from the dropdown$/, function (callback) {
		taskMgmtPage.Selectcontractnumber().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Model ID from the dropdown$/, function (callback) {
		taskMgmtPage.SelectModelId().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to check the values of the radio buttons present$/, function (callback) {
		taskMgmtPage.VerifyRadioButtons().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Yes for Do you want to create a manual Schedule$/, function (callback) {
		taskMgmtPage.Createmanualinvoiceyesradiobutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select the start date$/, function (callback) {
		taskMgmtPage.SelectStartDate().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select the end date$/, function (callback) {
		taskMgmtPage.SelectEndDate().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select the billing frequency as monthly$/, function (callback) {
		taskMgmtPage.SelectBillingFrequencyMonthly().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on proceed button after entering all the values in create unscheduled invoice popup$/, function (callback) {
		taskMgmtPage.ClickProceedbutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on save button$/, function (callback) {
		taskMgmtPage.Clicksavebutton().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on billing schedule Review button$/, function (callback) {
		taskMgmtPage.billingScheduleReviewBtnn().then(function () {
			callback();
		});
	});

	this.Then(/^Search for the aero contract (.*) in Billing schedule section$/, function (contractId, callback) {
		taskMgmtPage.searchforContractInBillingSchedule(contractId).then(function () {
			callback();
		});
	});

	this.Then(/^Click on review button$/, function (callback) {
		taskMgmtPage.clickOnBillingScheduleReview().then(function () {
			callback();
		});
	});

	this.Then(/^Select invoice date as todays date and entitlement date as tommorrows date$/, function (callback) {
		taskMgmtPage.selectEntitlement_InvoiceDate().then(function () {
			callback();
		});
	});

	this.Then(/^Click on approve and validate the warning message$/, function (callback) {
		taskMgmtPage.validateFoxtrotWarningMsg().then(function () {
			callback();
		});
	});

	this.Then(/^I can click on Debit Memo Back button$/, function (callback) {
		billingHomePage.clickOnDebitMemoBackBtn().then(function () { callback() })
	});

	this.Then(/^Approve the invoice and validate the same reflected in Billing schedule section on contract (.*)$/, function (contractId, callback) {
		billingHomePage.approveAndvalidateManlinv(contractId).then(function () { callback() })
	});

	this.Then(/^Open next invoice on same contract (.*) invoice schedule and check that user able to Edit and Approve\.$/, function (contractId, callback) {
		billingHomePage.OpenNextInvoiceEditAndApprove(contractId).then(function () { callback() })
	});

	this.Then(/^Delete single event and verify that future invoices should not affect on same contract (.*)$/, function (contractId, callback) {
		billingHomePage.verifySingleDeleteOption(contractId).then(function () { callback() })
	});

	this.Then(/^Delete event series and varify that all future invoices should affect on same contract (.*)$/, function (contractId, callback) {
		billingHomePage.verifyDeleteAllOption(contractId).then(function () { callback() })
	});

	this.Then(/^Fill General terms and conditions for monthly frequencies$/, function (callback) {
		ContractTandCsPage.fillMonthly_MonthlyInvoiceConditons_To_Check_FixORVaribaleBilling().then(function () { callback() })
	});

	this.Then(/^Fill Fixed billing TsandCs by Billing mode Fixed billing amount (.*) for the entire contract option$/, function (amount, callback) {
		ContractTandCsPage.fillFixedAmountDetails(amount).then(function () { callback() })
	});

	this.Then(/^Select No Escalation option$/, function (callback) {
		ContractTandCsPage.chooseNoEscalation().then(function () { callback() })
	});
	this.Then(/^Select start date from the widget$/, function (callback) {
		CreateUnschInvPage.selectDate().then(function () { callback() })
	});
	this.Then(/^Search for Billing invoice on the same contract (.*) for the period (.*)$/, function (contractId, period, callback) {         // Write code here that turns the phrase above into concrete actions
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, period).then(function () { callback() })
	});
	this.Then(/^Search for Billing invoice on the same contractt (.*) for the period (.*)$/, function (contractId, period, callback) {         // Write code here that turns the phrase above into concrete actions
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, period).then(function () { callback() })
	});

	this.Then(/^Search for the invoice on the same contract (.*) and period (.*)$/, function (contractId, period, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, period).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate amount (.*) as per the frequency$/, function (totalAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmount(totalAmount).then(function () { callback() })
	});

	this.Then(/^Fill Fixed billing TsandCs by Fixed billing at different start and end period option as (.*) and (.*)$/, function (period1Amount, period2Amount, callback) {
		ContractTandCsPage.fillFixedAmountOnDiffrenetDateRanges(period1Amount, period2Amount).then(function () { callback() })
	});

	this.Then(/^Choose NO Fixed Billing option from Fixed Billing section In TsCs$/, function (callback) {
		ContractTandCsPage.ChooseNofixedBilling().then(function () { callback() })
	});

	this.Then(/^Validate that there is no scheduled fixed billing inovice on same contract (.*) and period (.*)$/, function (contractId, period, callback) {
		CreateUnschInvPage.validateBillingschedule_EmptyRecord(contractId, period).then(function () { callback() })
	});

	this.Then(/^I can create different rates for different injection variable billing types$/, function (callback) {
		ContractTandCsPage.variableBilling_5_1_1_4_5_InjectionType().then(function () {
			callback();
		});
	});

	this.Then(/^Fill Variable TsCs by selecting one rate (.*) across the entire contract timeline$/, function (variableAmount, callback) {
		ContractTandCsPage.fillVariableAmount_TsCs(variableAmount).then(function () { callback() })
	});

	this.Then(/^Open Invoice on same contract (.*) and on aproved Op data month (.*)$/, function (contractId, month, callback) {
		CreateUnschInvPage.openVariableInvoice(contractId, month).then(function () { callback() })
	});

	this.Then(/^validate variable amount (.*) on each (.*) unit and total amount in the invoice with escalation (.*)$/, function (variableAmount, unitCount, escaltion, callback) {
		billingHomePage.ValidateVaribaleAmountInvoice(variableAmount, unitCount, escaltion).then(function () { callback() })
	});

	this.Then(/^Fill Variable billing TsandCs by Different rates across different time period option as (.*) and (.*)$/, function (period1Amount, period2Amount, callback) {
		ContractTandCsPage.fillVariableAmountOnDiffrenetDateRanges(period1Amount, period2Amount).then(function () { callback() })
	});

	this.Then(/^Fill Variable billing TsandCs by Different rates across different ranges option as (.*) and (.*)$/, function (range1Amount, range2Amount, callback) {
		ContractTandCsPage.fillVariableAmountOnDiffRanges(range1Amount, range2Amount).then(function () { callback() })
	});

	this.Then(/^Fill Variable billing TsandCs by Different rates across different FuelType option as (.*) and (.*) on monthly frequency and rate based on Op data$/, function (type1Amount, type2Amount, callback) {
		ContractTandCsPage.fillVarAmount_onDiffFueltypes_OpFactorAH_MonthlyRefresh_BasedOnOpdata(type1Amount, type2Amount).then(function () { callback() })
	});

	this.Then(/^Fill Variable billing TsandCs by Different rates across different FuelType option as (.*) and (.*) on monthly frequency and No Op data$/, function (type1Amount, type2Amount, callback) {
		ContractTandCsPage.fillVarAmount_onDiffFueltypes_OpFactorAH_MonthlyRefresh_NO_opData(type1Amount, type2Amount).then(function () { callback() })
	});

	this.Then(/^Fill Variable billing TsandCs by Different rates across different FuelType option with Quarterly frequency and based on Op data$/, function (callback) {
		ContractTandCsPage.fillVariableBillingWithQuartelryFrequencyBasedOnOpData().then(function () { callback() })
	});

	this.Then(/^Fill Variable billing TsandCs by Different rates across different FuelType option with Quarterly frequency and NO Op data$/, function (callback) {
		ContractTandCsPage.fillVariableBillingWithQuartelryFrequency_No_OpData().then(function () { callback() })
	});

	this.Then(/^Fill Variable billing TsandCs by Different rates across different FuelType option with Anually frequency and based on Op data$/, function (callback) {
		ContractTandCsPage.fillVariableBillingWithAnuallyFrequencyBasedOnOpData().then(function () { callback() })
	});

	this.Then(/^Fill Variable billing TsandCs by Different rates across different FuelType option with Anually frequency and No Op data$/, function (callback) {
		ContractTandCsPage.fillVariableBillingWithAnuallyFrequency_No_OpData().then(function () { callback() })
	});


	this.Then(/^Fill Milestone billing amount (.*) for Date Based Milestone option$/, function (amount, callback) {
		ContractTandCsPage.fillMilestoneTsCsOnDateBased(amount).then(function () { callback() })
	});

	this.Then(/^Search for Milestone Billing invoice on the same contract (.*)$/, function (contractId, callback) {
		CreateUnschInvPage.searchFOrDatebasedMilestoneInvoice(contractId).then(function () { callback() })
	});


	this.Then(/^Fill cumulative hours (.*) and billing amount (.*) for Ops based Milestone option$/, function (cumulativeAh, amount, callback) {
		ContractTandCsPage.fillMileStoneTsCs_onOpsBased(cumulativeAh, amount).then(function () { callback() })
	});

	this.Then(/^Search for Ops based Milestone invoice on the same contract (.*) and month (.*)$/, function (contractId, month, callback) {
		CreateUnschInvPage.searchForOpsBasedMilestoneInvoice(contractId, month).then(function () { callback() })
	});


	this.Then(/^Fill General TsCs on Contract level for Quartelry_Quarterly and generate separate invoices$/, function (callback) {
		ContractTandCsPage.FillGeneral_TsCs_For_Quarterly_Quarterly_generateSeparateInovices().then(function () { callback() })
	});

	this.Then(/^Provide Escalaton (.*) as One Rate for all Billings and separate by unit or by billing type$/, function (escalation, callback) {
		ContractTandCsPage.enterEscalationForOneRate_separateByUnit(escalation).then(function () { callback() })
	});

	this.Then(/^Enter fixed (.*) variable (.*) milestone (.*) in respective Terms and Conditions$/, function (fixAmount, varAmount, mileAmount, callback) {
		ContractTandCsPage.fill_Fixed_Var_Milestone_terms_Conditions_basedOn_Contracttype(fixAmount, varAmount, mileAmount).then(function () { callback() })
	});


	this.Then(/^Fill General TsCs on Contract level for Monthly_Quarterly and combine as a single invoice$/, function (callback) {
		ContractTandCsPage.fill_GeneralTsCs_Monthly_Quarter_combineIntoOneInv().then(function () { callback() })
	});

	this.Then(/^Provide Escalaton (.*) as One Rate for all Billings and Split Fixed and Variable fees escalations$/, function (escalation, callback) {
		ContractTandCsPage.enterEscalationForOneRate_separateByFixed_Var(escalation).then(function () { callback() })
	});

	this.Then(/^Provide Escalaton (.*) as One Rate for all Billings and Split Fixed and Variable fees escalations and Combine all escalation into one lines$/, function (escalation, callback) {
		ContractTandCsPage.enterEscalationForOneRate_CombineAllEscalationIntoSingleLine(escalation).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate combined escalaton (.*)$/, function (escalationAmount, callback) {
		billingHomePage.clickAndValidate_EscalationAmount(escalationAmount).then(function () { callback() })
	});

	this.Then(/^Fill General TsCs on Contract level for MonthlyFee_Monthly and combine as a single invoice$/, function (callback) {
		ContractTandCsPage.fill_GeneralTsCs_MonthlyFee_Monthly_combineIntoOneInv().then(function () { callback() })
	});

	this.Then(/^Provide Escalaton (.*) as One Rate for all Billings and Include escalation to the unit price and select Round to two decimals$/, function (escalation, callback) {
		ContractTandCsPage.enterEscalationForOneRate__round2(escalation).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate combine escalaton (.*) when round to two decimal$/, function (escalationAmount, callback) {
		billingHomePage.clickAndValidate_EscalationAmountRound2Dece(escalationAmount).then(function () { callback() })
	});

	this.Then(/^Provide Escalaton (.*) as One Rate for all Billings and Include escalation to the unit price and select dont round$/, function (escalation, callback) {
		ContractTandCsPage.enterEscalationForOneRate__DontRound(escalation).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate combine escalaton (.*) when dont round decimal$/, function (escalationAmount, callback) {
		billingHomePage.clickAndValidate_EscalationAmountRound2Dece(escalationAmount).then(function () { callback() })
	});

	this.Then(/^Search for Milestone Billingg invoice on the same contract (.*)$/, function (contractId, callback) {
		CreateUnschInvPage.searchFOrDatebasedMilestoneInvoiceOnSpecifiedMonth(contractId).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate combine escalaton (.*) when dont roundTwo decimals$/, function (totalAmount, callback) {
		billingHomePage.clickAndValidate_EscalationAmountDontRoundDecimalValues(totalAmount).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate periodOne amount (.*) when round to two decimal$/, function (period1Amount, callback) {
		billingHomePage.clickAndValidate_EscalationAmountRound2Dece(period1Amount).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate periodTwo amount (.*) when round to two decimal$/, function (period2Amount, callback) {
		billingHomePage.clickAndValidate_EscalationAmountRound2Dece(period2Amount).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) like Different rates per billing fee types and Split by unit or billing type$/, function (fixEsc, varEsc, mileEsc, callback) {
		ContractTandCsPage.enterDiffrentEScalation(fixEsc, varEsc, mileEsc).then(function () { callback() })
	});

	this.Then(/^Search for the Fixed Billing invoice on the same contract (.*) and period (.*)$/, function (contractId, periodFix, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, periodFix).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate Fixed amount (.*)$/, function (invFixAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmount(invFixAmount).then(function () { callback() })
	});

	this.Then(/^Search for the Variable Billing invoice on the same contract (.*) and period (.*)$/, function (contractId, periodVar, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, periodVar).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate Variable amount (.*)$/, function (invVarAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmount(invVarAmount).then(function () { callback() })
	});

	this.Then(/^Search for the Milestone Billing invoice on the same contract (.*) and period (.*)$/, function (contractId, periodMile, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, periodMile).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate Milestone amount (.*)$/, function (invMilestoneAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmount(invMilestoneAmount).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) like Different rates per billing fee types and Split Fixed and Variable fees escalations$/, function (fixEsc, varEsc, mileEsc, callback) {
		ContractTandCsPage.enterDiffrentEScalationOnSplitByBillType(fixEsc, varEsc, mileEsc).then(function () { callback() })
	});

	this.Then(/^Enter fixed billing (.*) variable billing (.*) in respective Terms and Conditions$/, function (fixAmount, varAmount, callback) {
		ContractTandCsPage.fill_Fixed_Var_terms_Conditions_basedOn_Contracttype(fixAmount, varAmount).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate amount (.*) as per the escalation$/, function (totalAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmount(totalAmount).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) like Different rates per billing fee types and combine all escalation into one line$/, function (fixEsc, varEsc, mileEsc, callback) {
		ContractTandCsPage.enterDiffrentEScalation_combineAll_EscalationIntoSingleLine(fixEsc, varEsc, mileEsc).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate combined Escalation (.*) as per terms and conditons$/, function (escaAmount, callback) {
		billingHomePage.clickAndValidate_combinedEScalation(escaAmount).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) as Different rates per billing fee and Include escalation to the unit price and select Round to two decimals$/, function (fixEsc, varEsc, mileEsc, callback) {
		ContractTandCsPage.enterDiffrentEScalation_RoundTwoDdecimal(fixEsc, varEsc, mileEsc).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) as Different rates per billing fee and Include escalation to the unit price and select Dont round$/, function (fixEsc, varEsc, mileEsc, callback) {
		ContractTandCsPage.enterDiffrentEScalation_dontRoundAmountValue(fixEsc, varEsc, mileEsc).then(function () { callback() })
	});

	this.Then(/^Provide different Escalation (.*) and (.*) on different periods and Split by unit or billing type$/, function (escalation1, escalation2, callback) {
		ContractTandCsPage.enterDifferentEscaOnDiffPeriodsSplitByUnit(escalation1, escalation2).then(function () { callback() })
	});

	this.Then(/^Searchh for the Fixed Billl invoice on the same contract (.*) and period (.*)$/, function (contractId, period1, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, period1).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate Fixed amountt (.*) for the period one$/, function (period1TotalAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmountOndifferentPeriods(period1TotalAmount).then(function () { callback() })
	});

	this.Then(/^Searchh for the Fixed Bill invoice on the same contract (.*) and period (.*)$/, function (contractId, period2, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, period2).then(function () { callback() })
	});

	this.Then(/^click on calculate buttonn and validate Variable amount (.*) for the period two$/, function (period2TotalAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmountOndifferentPeriods(period2TotalAmount).then(function () { callback() })
	});

	this.Then(/^Check No Fiexed Billing No Var bill, No escalation, No milestone check boxes$/, function (callback) {
		ContractTandCsPage.makeTsCsEmpty().then(function () { callback() })
	});

	this.Then(/^Change Escalation option to separate Invoices and Combine all escalation into one lines$/, function (callback) {
		ContractTandCsPage.enterDifferentEscaOnDiffPeriodsCombineEscalation().then(function () { callback() })
	});

	this.Then(/^Search for Fixed and Variable combined invoice on the same contract (.*) for the period (.*)$/, function (contractId, period1, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, period1).then(function () { callback() })
	});

	this.Then(/^Fill General TsCs on Contract level for Monthly_Quarterly with minus one month deviation and combine as a single invoice$/, function (callback) {
		ContractTandCsPage.fill_GeneralTsCs_Monthly_Quarter_combineIntoOneInvWithDeviation().then(function () { callback() })
	});

	this.Then(/^Change Escalation option separate Invoices and Split Fixed and Variable fees escalations$/, function (callback) {
		ContractTandCsPage.enterDifferentEscaOnDiffPeriodsSplitByVar_Fixed().then(function () { callback() })
	});

	this.Then(/^Fill General TsCs on Contract level for MonthlyFee_Monthly with minus one month deviation and combine as a single invoice$/, function (callback) {
		ContractTandCsPage.fill_GeneralTsCs_MonthlyFee_Monthly_combineIntoOneInv().then(function () { callback() })
	});

	this.Then(/^Provide different Escalationn (.*) and (.*) and Change Escalation option to Include escalation to the unit price and round to two decimal$/, function (escalation1, escalation2, callback) {
		ContractTandCsPage.enterDifferentEscaOnDiffPeriodsTwoRound(escalation1, escalation2).then(function () { callback() })
	});

	this.Then(/^Change Escalation option to Include escalationn to the unit price and select dont round option$/, function (callback) {
		ContractTandCsPage.enterDifferentEscaOnDiffPeriodsDontRound().then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on first projectId$/, function (fixEsc1, varEsc1, mileEsc1, callback) {
		ContractTandCsPage.enterDiffEscaOnprojectIdOne(fixEsc1, varEsc1, mileEsc1).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on second projectId and Split by unit or billing type$/, function (fixEsc2, varEsc2, mileEsc2, callback) {
		ContractTandCsPage.enterDiffEscaOnprojectIdTwo(fixEsc2, varEsc2, mileEsc2).then(function () { callback() })
	});

	this.Then(/^Search for the Billing invoice on the same contract for the first Project (.*) and period (.*)$/, function (contractId, projOneperiod, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, projOneperiod).then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate amount on ProjectOne (.*)$/, function (projOneAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmount(projOneAmount).then(function () { callback() })
	});

	this.Then(/^Search for the Billing invoice on the same contract for the second Project (.*) and period (.*)$/, function (contractId, projTwoperiod, callback) {
		CreateUnschInvPage.searchForInvoiceOnGivenPeriod(contractId, projTwoperiod).then(function () { callback() })
	});

	this.Then(/^click on Review button and validate amount on ProjectTwo (.*)$/, function (projTwoAmount, callback) {
		billingHomePage.clickOnReviewBtn_ValidateAMount(projTwoAmount, "").then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on second projecttId and Split Fixed and Variable fees escalations$/, function (fixEsc2, varEsc2, mileEsc2, callback) {
		ContractTandCsPage.enterDiffEscaOnprojectIdTwoWithSplitByFixVar(fixEsc2, varEsc2, mileEsc2).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on secondd projecttId and Combine all escalation into one lines$/, function (fixEsc2, varEsc2, mileEsc2, callback) {
		ContractTandCsPage.enterDiffEscaOnprojectIdTwoWithCombineAllEscIntoOneLine(fixEsc2, varEsc2, mileEsc2).then(function () { callback() })
	});

	this.Then(/^click on Review button and validate combined Escalation (.*) as per terms and conditons$/, function (period2EscaAmount, callback) {
		billingHomePage.clickOnReviewAndValidate_combinedEScalation(period2EscaAmount).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on second project and select round two decimals$/, function (fixEsc2, varEsc2, mileEsc2, callback) {
		ContractTandCsPage.enterDiffEscaOnprojectIdTwoWithCombineAllEscIntoOneLineRoundTwoDecimals(fixEsc2, varEsc2, mileEsc2).then(function () { callback() })
	});

	this.Then(/^click on Review buttonn and validate amount on ProjectTwo (.*) when round to two decimals$/, function (projTwoAmount, callback) {
		billingHomePage.clickOnReviewBtn_ValidateAMountWhenRoundTwodecimals(projTwoAmount).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on second projectt and select dont round decimals$/, function (fixEsc2, varEsc2, mileEsc2, callback) {
		ContractTandCsPage.enterDiffEscaOnprojectIdTwoWithCombineAllEscIntoOneLineDontRoundDecimals(fixEsc2, varEsc2, mileEsc2).then(function () { callback() })
	});


	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on first Unit$/, function (fixEsc1, varEsc1, mileEsc1, callback) {
		ContractTandCsPage.escalationOnUnitOne(fixEsc1, varEsc1, mileEsc1, "", "").then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on second Unit and select spliByUnit$/, function (fixEsc2, varEsc2, mileEsc2, callback) {
		ContractTandCsPage.escalationOnUnitTwoSplitByUnit(fixEsc2, varEsc2, mileEsc2, "", "").then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate amount on invoice (.*)$/, function (invoiceAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmount(invoiceAmount).then(function () { callback() })
	});

	this.Then(/^Validate escalation on each Unit in variable billing invoice$/, function (callback) {
		billingHomePage.displayAllAvailableUnitsEScalationValues().then(function () { callback() })
	});

	this.Then(/^Select Split Fixed and Variable fees escalations option$/, function (callback) {
		ContractTandCsPage.escalationOnUnitTwoSplitFix_Var_Mile().then(function () { callback() })
	});

	this.Then(/^Select Combine all escalation into one lines option$/, function (callback) {
		ContractTandCsPage.escalationOnUnitTwoCombineAllEScalation().then(function () { callback() })
	});

	this.Then(/^click on calculate button and validate invoice amount (.*) when decimals round two$/, function (fixedAmount, callback) {
		billingHomePage.clickOnCalculateBtn_validateAmountOndifferentPeriods(fixedAmount).then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on first Unit round to two decimal$/, function (fixEsc1, varEsc1, mileEsc1, callback) {
		ContractTandCsPage.escalationOnUnitOneEdit(fixEsc1, varEsc1, mileEsc1, "", "").then(function () { callback() })
	});

	this.Then(/^Provide FixInvEsc (.*) VarInvEsc (.*) MilestoneInvEsc (.*) on second Unitt and Round to two decimals$/, function (fixEsc2, varEsc2, mileEsc2, callback) {
		ContractTandCsPage.escalationOnUnitTwoRoundTwo(fixEsc2, varEsc2, mileEsc2, "", "").then(function () { callback() })
	});

	this.Then(/^Change Escalation option to dont to two decimal$/, function (callback) {
		ContractTandCsPage.escalationOnUnitTwoDontRound().then(function () { callback() })
	});

	this.Then(/^Select no escalation from terms and conditions$/, function (callback) {
		ContractTandCsPage.selectNOEscalation().then(function () { callback() })
	});


	this.Then(/^Click on forecast setup and choose Use previous year's monthly Ops data option$/, function (callback) {
		taskMgmtPage.clickOnForecastsetupAndChooseOption().then(function () { callback() })
	});




	this.Then(/^Click on any One unit and take the Cumulative AH and AH values for any two unlocked months$/, function (callback) {
		taskMgmtPage.clickOnUnitTakeVAlues().then(function () { callback() })
	});


	this.Then(/^Go to forecast summary table and lock any one month and come back to foreccast screen$/, function (callback) {
		taskMgmtPage.lockInvoiceOnSelectedMonth().then(function () { callback() })
	});



	this.Then(/^Change Ops Data option to Use average monthly data from a previous twelve months$/, function (callback) {
		taskMgmtPage.ChangeOptionTOPreviousYear().then(function () { callback() })
	});

	this.Then(/^Verify that locked row still same as previous or not$/, function (callback) {
		taskMgmtPage.verifyLockedRow().then(function () { callback() })
	});


	this.Then(/^verify that unlocked row changed to new values or not$/, function (callback) {
		taskMgmtPage.verifyUnlockedRows().then(function () { callback() })
	});


	this.Then(/^Change Ops data option to  Manually adjust Ops data for forecast$/, function (callback) {
		taskMgmtPage.changeOptionToManualAdjustOpdata().then(function () { callback() })
	});

	this.Then(/^Unlock the same inovice$/, function (callback) {
		taskMgmtPage.changeOptionToManualAdjustOpdata().then(function () { callback() })
	});

	this.Then(/^I can choose option Manual Not configured in ICAM$/, function (callback) {
		ContractTandCsPage.clickOnManualVarialeRdoBtn().then(function () { callback() })
	});

	this.Then(/^Click on calulate button and approve milestone inovice$/, function (callback) {
		billingHomePage.clickOnCalculateAndApprove().then(function () { callback() })
	});

	this.Then(/^Click on calculate button and add adjustments and verify total billable amount$/, function (callback) {
		billingHomePage.clickOnCalculateAndAddAdjustments().then(function () {})
		billingHomePage.fillAdjustmentDetails(5, 6).then(function () {callback() })
	});

	this.Then(/^Click on calculate button and add adjustments and verify total billable amountt$/, function (callback) {
		billingHomePage.clickOnCalculateAndAddAdjustments().then(function () {})
		billingHomePage.fillAdjustmentDetails(10, 6).then(function () { callback()})
	});

	this.Given(/^I can click on billing schedule Calculate Back button$/, function (callback) {
		taskMgmtPage.billingScheduleCalculateBackBtnOnManualInv().then(function () { callback() })
	});

	this.Then(/^Search for the variable invoice in forecast summary and verify the amount (.*) and period (.*)$/, function (amount, period, callback) {
		taskMgmtPage.verifyManualVariableInvAmountForInvoice(amount, period).then(function () { callback() })
	});

	this.Given(/^I can provide milestone amountt (.*) in Milestone Billing TsCs$/, function (milestoneAmount, callback) {
		ContractTandCsPage.fillMilestoneTsCsOnDateBasedInBilling(milestoneAmount).then(function () { callback() })
	});

	this.Then(/^Click on calulate buttonn and approve selected inovice$/, function (callback) {
		billingHomePage.clickOnCalculateAndApprove().then(function () { callback() })
	});

	this.Then(/^Veify that whether approved invoice available in forecast summary table for the period (.*)$/, function (period, callback) {
		taskMgmtPage.verifyNoVariableInvoiceInForecast(period).then(function () { callback() })
	  });

	this.Then(/^Click on Review buttonn and approve selected inovice$/, function (callback) {
		billingHomePage.clickOnReviewBtnANdThenApproveInvoice().then(function () { callback() })
	});

	this.Then(/^Validate if draft invoice has been selected as yes then one touch button should be enabled$/, function (callback) {
		ContractTandCsPage.sendToAlphaPopupYesButtonFunction().then(function () { callback() })
	});

	this.Then(/^Validate if draft invoice has been selected as no then one touch button should not be enabled$/, function (callback) {
		ContractTandCsPage.sendToAlphaPopupNOButtonFunction().then(function () { callback() })
	});

	this.Then(/^Validate one touch button enabled$/, function (callback) {
		ContractTandCsPage.oneTouchApprovalButtonFunction().then(function () {
			callback();
		});
	});

	this.Then(/^Validate Forecast Signoff button and Header text in signoff popup$/, function (callback) {
		ContractTandCsPage.forecastSignOffwithDigestedAndSanityTxt().then(function () {
			callback();
		});
	});

	this.Then(/^Validate Forecast Signoff Digested view per quarter table data$/, function (callback) {
		ContractTandCsPage.disegistedViewQuarterTableTxt().then(function () {
			callback();
		});
	});

	this.Then(/^Validate Sanity check on potential defects table data$/, function (callback) {
		ContractTandCsPage.sanityCheckOnPotentialDefects().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Audit Trail Button$/, function (callback) {
		ContractTandCsPage.auditTrailBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Audit Trail popup Close Button$/, function (callback) {
		ContractTandCsPage.auditTrailCloseBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Audit Trail Initial row step$/, function (callback) {
		ContractTandCsPage.auditTrailInitialRowValidation().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to validate Approve text Audit Trail$/, function (callback) {
		ContractTandCsPage.auditTrailApproveValidation().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to validate Unapprove text in Audit Trail$/, function (callback) {
		ContractTandCsPage.auditTrailUnapprovedValidation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Recalculate text Audit Trail$/, function (callback) {
		ContractTandCsPage.auditTrailRecalculateValidation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Pending Draft invoice approval text Audit Trail$/, function (callback) {
		ContractTandCsPage.auditTrailRecalculateValidation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Recalculate button$/, function (callback) {
		ContractTandCsPage.invoiceRecalculateBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Approve invoice records in Audit Trail$/, function (callback) {
		ContractTandCsPage.validationAuditTrailApproveBtn().then(function () {
			callback();
		});
	});
	this.Then(/^I can able to validate Unapprove invoice records in Audit Trail$/, function (callback) {
		ContractTandCsPage.validationAuditTrailUnapproveBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on invoice details with Reason selection back button$/, function (callback) {
		ContractTandCsPage.invoiceBackBtn().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to select Yes in Send to Alpha section$/, function (callback) {
		ContractTandCsPage.sendToAlphaPopupYesButtonFunction().then(function () { callback() })
	});

	this.Then(/^I can able to select No in Send to Alpha section$/, function (callback) {
		ContractTandCsPage.sendToAlphaPopupNOButtonFunction().then(function () { callback() })
	});

	this.Then(/^I can able to validate Send to Alpha text in Audit trail$/, function (callback) {
		ContractTandCsPage.auditTrailSendToAlphaYesValidation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate One Touch Approval text in Audit trail$/, function (callback) {
		ContractTandCsPage.auditTrailOnetouchApprovalValidation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to validate Billed Out text in Audit trail$/, function (callback) {
		ContractTandCsPage.auditTrailBilledOutValidation().then(function () {
			callback();
		});
	});

	this.Then(/^I can able to click on Onetouch Approval button and validate Invoice should be successfully sent to Alpha$/, function (callback) {
		ContractTandCsPage.oneTouchApproval().then(function () {
			callback();
		});
	});



};//last line
