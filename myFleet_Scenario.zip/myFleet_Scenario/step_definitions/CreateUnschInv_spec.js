var billingHomePage = require("..//PageObjects//Billing_po.js");

module.exports = new function(){

    this.When(/^User on home page click on Create Unscheduled Invoices button$/, function (callback) {
        billingHomePage.clickOnCreateUnscheduledInvoices().then(function(){callback();});
      });

};

