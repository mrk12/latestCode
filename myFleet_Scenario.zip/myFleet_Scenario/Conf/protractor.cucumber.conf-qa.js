/**
 * Created by 212556710 on 5/9/16.

 */
var path1 = require('path');
var downloadsPath = path1.resolve(__dirname, '../TestData/DownLoad');
//const { Authenticator } = require('authenticator-browser-extension');

exports.config = {

	// directConnect: true,
	sauceUser: null,
	sauceKey: null,
	sauceSeleniumAddress: null,
	directConnect: true,
	firefoxPath: null,
	//framework: 'jasmine2',
	//chromeDriver: '../../../chrome-driver/chromedriver_2.33.exe',
	//chromeDriver: '../../../node_modules/protractor/selenium/chromedriver_2.33',

	// Organize spec files into suites. To run specific suite, --suite=<name of suite>
	suites: {

		myFleet: [
			//"../Features/aero_Leased.feature",
			//"../Features/billingCalculation.feature"
			//"../Features/monetization.feature",
			//"../Features/myFleet_sample.feature",
			//"../Features/aero_forecast.feature",
			//"../Features/CCLContracts.feature", 
			"../Features/PGS_Forecast.feature",			
			//"../Features/aero_nonleased.feature",
			//"../Features/TurbineOpsData.feature"
			//"../Features/unscheduledInvoices.feature",
			//"../Features/Reoccur_Update.feature"
			//"../Features/JanSprint.feature"
			//"../Features/Escalation_Revamp.feature"
			//"../Features/VariableManualInvoice.feature"
			//"../Features/auditTrail.feature",
		],
	},

	// Hooks running in the background
	plugins: [{
		path: '../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',
		// path: 'hook.js',
	}],

	capabilities: {
		browserName: 'chrome',
		// proxy:{
		//     proxyType:'manual',
		//     httpProxy: 'sjc1intproxy01.crd.ge.com:8080',
		//     sslProxy: 'sjc1intproxy01.crd.ge.com:8080',
		// },


		count: 1,
		shardTestFiles: false,
		maxInstances: 1,
		framework: 'jasmine',
		'chromeOptions': {
			args: ['--no-sandbox', '--test-type=browser'],
			//args: [ '--headless', '--disable-gpu', '--no-sandbox', '--window-size=1920x1200' ],
			//extensions: [Authenticator.for('503114663', 'Radha@11m').asBase64()],
			//args: ["--incognito"],
			prefs: {

				'download': {
					'prompt_for_download': false,
					'default_directory': downloadsPath,
					//'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
					'directory_upgrade': true,
				}
			}
		}
	},


	maxSessions: -1,
	allScriptsTimeout: 250000,
	getPageTimeout: 1650000,
	beforeLaunch: function () {
	},
	
	onPrepare: function () {
		var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
		var mkdirp = require('mkdirp');
		var reportsPath = "./Reports/";
		mkdirp(reportsPath, function (err) {
			if (err) {
				console.error(err);
			} else {
			}
		});
		


		browser.manage().deleteAllCookies();
		browser.manage().timeouts().pageLoadTimeout(90000);
		browser.manage().timeouts().implicitlyWait(30000);
		browser.driver.manage().window().maximize();
		//browser.manage().window().setSize(1400, 900);
		chai = require('chai');
		expect = chai.expect;
		path = require('path');
		Cucumber = require('cucumber');
		fs = require('fs');

		// Initializing necessary utils from ProUI-Utils module
		TestHelper = require('proui-utils').TestHelper;
		TestHelperPO = require('proui-utils').TestHelperPO;
		ElementManager = require('proui-utils').ElementManager;
		Logger = require('proui-utils').Logger;
		cem = new ElementManager('../../../myFleet_Scenario/taskmngmnt-element-repo.json');
		//cem = new ElementManager('../../../planmngmnt-element-repo.json');
		TestHelper.setElementManager(cem);
		RestHelper = require('proui-utils').RestHelper;

		// Initializing page object variables
		taskMgmtPage = require('../PageObjects/myFleet_po.js');
		myFleetPage = require('../PageObjects/monetization_po.js');
		myFleetAero = require('../PageObjects/myFleetAero_po.js');
		userStory = require('../PageObjects/userStories_po.js');

	},

	// A callback function called once tests are finished
	onComplete: function () { },


	// A callback function called once tests are cleaning up
	onCleanUp: function (exitCode) {

	},

	// A callback function after tests are launched
	afterLaunch: function () {

	},

	params: {
		login: {

			baseUrl: 'https://st-tpomyfleet.gepower.com/',
			//"username": "503114663",
			//"password": "Radha@11m",

			"username": "503154951",
			"password": "sURI1234@Q",

			"errMsg": "Incorrect User ID or Password ",
			"btn": '//*[@value="Log In & Remember Me"]',

		}
	},

	resultJsonOutputFile: null,

	// If true, protractor will restart the browser between each test.
	// CAUTION: This will cause your tests to slow down drastically.
	restartBrowserBetweenTests: false,

	// Custom framework in this case cucumber
	framework: 'custom',
	frameworkPath: require.resolve('protractor-cucumber-framework'),
	cucumberOpts: {

		// define your step definitions in this file
		require: [
			'../step_definitions/env.js',
			'../step_definitions/myFleet-spec.js',
			'../step_definitions/userStories-spec.js',
			'../../node_modules/proui-utils/Compressed_Utils/Reporter.js'
		],

		format: 'pretty',
		
	}

};

