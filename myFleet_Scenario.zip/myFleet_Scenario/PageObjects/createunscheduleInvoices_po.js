/*
Created by Suresh BM

*/

var util = require("../PageObjects/Utility.js");
var SelectWrapper = require("..//Utility/select-wrapper.js");
let contractNumberr = new SelectWrapper(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td/select"))
var today = util.todayDateIn_dd_format();
var tomorrowDate = parseInt(today) + 1;
var dayAftertomorrowDate = parseInt(today) + 2;
var presentMonth = util.currentMonth();
var thirdMonth = util.thirdMonth();
var aprilMonth = util.aprlMonth();
var ContractTsCsPage = require("../PageObjects/ContractT&CsPage.js");
var billingPo = require("../PageObjects/Billing_po.js");

module.exports = {


    Locators:
    {
        pageTitle: element(by.xpath("//*[contains(text(), 'Create Unscheduled Invoices')]")),
        billingScheduleEndDateIcon: element(by.xpath("//input[@id='invEndDate']/parent::span/button")),
        manualInvotype: element(by.css("input[value='MANUAL INVOICE']")),
        creditMemoRadioBtn: element(by.css("input[value='CREDIT-MEMO']")),
        debitMemoRadioBtn: element(by.css("input[value='DEBIT-MEMO']")),
        modelId: element(by.xpath("(//*[@id='addInvoicealert']/parent::div//select)[2]/option[2]")),
        projectId: $$("input[name='projectName']"),
        manualScheduleYesRdoBtn: element(by.xpath("//input[@name='manualSchedule-Radio'][@value='Yes']")),
        startDateIcon: element(by.xpath("//input[@id='manualScheduleStartDate']/parent::span/button")),
        endDateIcond: element(by.xpath("//input[@id='manualScheduleEndDate']/parent::span/button")),
        monthlyBillingFrequencyRdoBtn: element(by.xpath("//input[@name='manualScheduleFreq-Radio'][@value='MONTHLY']")),
        proceed: element(by.xpath("//button[@onclick='saveNewInvoice()']")),
        saveButton: element(by.css("a#saveManualSchedule")),
        successmessage: element(by.xpath("//div[@id='SuccessmessageDiv']/div/strong")),
        confirmBtn: element(by.xpath("//input[@value='Confirm']")),
        billingSheduleSearchfield: element(by.xpath("//input[@data-filter-table='myInvoiceTable']")),
        applyBtn: element(by.xpath("//*[@id='billingScheduleAbtMdle']/parent::div//button[@id='dateApplyInvoice']")),
        saveBtnMilestone : element(by.xpath("//*[@id='confirmSave']")),
        projectIdColumn: element(by.xpath("//table[@id='myInvoiceCustomerTable']/tbody/tr/td[5]")),
        invoiceTypeCol: element(by.xpath("//table[@id='myInvoiceCustomerTable']/tbody/tr/td[6]")),
        todayDate: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '" + today + "')]")),
        Day1: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '1')]")),
        Day2: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '2')]")),
        tommorrowDate: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '" + today + "')]")),
        dayAfterTommrowDate: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '" + dayAftertomorrowDate + "')]")),
        swtitchToMonht: element(by.xpath("//div[@class='datepicker-days']//*[@class='datepicker-switch']")),
        thirdMonthh: element(by.xpath("//span[@class='month' or @class='month active'][contains(text(), '" + thirdMonth + "')]")),
        JanMonthh: element(by.xpath("//span[@class='month' or @class='month active'][contains(text(), 'Jan')]")),
        aprilMonthh: element(by.xpath("//span[@class='month' or @class='month active'][contains(text(), '" + aprilMonth + "')]")),
        currentMonthh: element(by.xpath("//span[@class='month' or @class='month active'][contains(text(), '" + presentMonth + "')]")),
        OccurenceRdoBtn: element(by.xpath("//input[@value='Occurrence']")),
        occurenceCountTextField: element(by.css("input#msNumOfOccurrence")),
        successMsgCloseBtn: element(by.xpath("//div[@id='SuccessmessageDiv']//button")),
        billingScheduleTable: element(by.xpath("//div[@id='myInvoiceCustomerTable_wrapper']")),
        BillingScheStartDateIcon: element(by.xpath("//input[@id='invStartDate']/parent::span/button")),
        BillScheEmptyRecordText: element(by.xpath("//table[@id='myInvoiceCustomerTable']//td")),
        calculateButton: element(by.css("a#Calculate")),
        generateCalConfirmYes: element(by.css("a#invCalId")),
        dateErrorMsg: element(by.xpath("//div[@id='billErrorMsgDiv']//strong")),
        dateErrorClose: element(by.xpath("//div[@id='billErrorMsgDiv']//button")),
        swtitchToMonhtWhenDays: element(by.xpath("//div[@class='datepicker-days']//*[@class='datepicker-switch']")),
        swtitchToMonhtWhenMonths: element(by.xpath("//div[@class='datepicker-months']//*[@class='datepicker-switch']")),
        year2019: element(by.xpath("//span[@class='year' or @class='year old' or @class='year active'][contains(text(), '2019')]")),
        year2020: element(by.xpath("//span[@class='year' or @class='year old' or @class='year new'][contains(text(), '2020')]")),

    },

    verifyPopupTitle: function () {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        browser.sleep(3000);
        return locate.pageTitle.isDisplayed().then(function (condition) {
            assert.equal(condition, true);
        })
    },

    selectContractId: function (contractId) {
        var locate = this.Locators;
        return contractNumberr.selectByText(contractId);
    },

    selectModelId: function () {
        var locate = this.Locators;
        return locate.modelId.click();
    },

    selectManualInvoiceType: function () {
        var locate = this.Locators;
        return locate.manualInvotype.isDisplayed().then(function (condition) {
            if (condition == true) {
                locate.manualInvotype.click();
            }
        })
    },

    chooseProjectId: function () {
        var locate = this.Locators;
        for (let i = 0; i < locate.projectId.count(); i++) {
            locate.projectId.get(i).click();
        }
        return browser.sleep(1000);
    },

    clickOnmanualScheduleRdobtn: function () {
        var locate = this.Locators;
        return locate.manualScheduleYesRdoBtn.click();
    },

    selectStart_EndDates: function () {
        var locate = this.Locators;
        locate.startDateIcon.click();
        locate.startDateIcon.click();
        locate.todayDate.click();
        locate.endDateIcond.click();
        browser.sleep(2000)
        locate.swtitchToMonht.click();
        locate.thirdMonthh.click();
        return locate.todayDate.click();
    },

    chooseMonthlyBillingFrequency: function () {
        var locate = this.Locators;
        return locate.monthlyBillingFrequencyRdoBtn.click();
    },

    clickOnProceedAndVerifysuccessMessage: function () {
        var locate = this.Locators;

        browser.sleep(2000)
        locate.proceed.click();
        browser.sleep(1000)
        locate.confirmBtn.isDisplayed().then(function (condtion) {
            if (condtion == true) {
                locate.confirmBtn.click();
            }
        })
        util.waitForPageReadyState().then(function () { });
        browser.sleep(1000)
       locate.saveButton.click();
        //util.waitForPageReadyState().then(function(){});
        return locate.successmessage.getText().then(function (message) {
            assert.equal(message, "Manual Invoice has been generated successfully");
        })
    },

    validateGeneratedInvoice: function (contractId, cond) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingSheduleSearchfield).then(function () { })
        locate.billingSheduleSearchfield.clear();
        locate.billingSheduleSearchfield.sendKeys(contractId + " " + util.todayDateIn_yyyy_mm_dd_format());
        if (cond == "dates") {
            browser.sleep(2000)
            locate.billingScheduleEndDateIcon.click();
            locate.swtitchToMonht.click();
            locate.thirdMonthh.click();
            var text = contractId.substring(0, 4);
            if (text == "AERO") {
                locate.dayAfterTommrowDate.click();
            } else {
                locate.tommorrowDate.click();
            }
        }
        locate.applyBtn.click();
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.invoiceTypeCol.getText().then(function (invType) {
            assert.equal(invType, "MANUAL INVOICE");
        })
        browser.sleep(1000)
        locate.billingSheduleSearchfield.clear();
        locate.billingSheduleSearchfield.sendKeys(contractId + " " + util.secondMonthDateIn_yyyy_mm_dd_format());
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.invoiceTypeCol.getText().then(function (invType) {
            assert.equal(invType, "MANUAL INVOICE");
        })
        browser.sleep(1000)
        locate.billingSheduleSearchfield.clear();
        locate.billingSheduleSearchfield.sendKeys(contractId + " " + util.thirdMonthDateIn_yyyy_mm_dd_format());
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.invoiceTypeCol.getText().then(function (invType) {
            assert.equal(invType, "MANUAL INVOICE");
        })
        browser.navigate().refresh();
        return util.waitForPageReadyState().then(function () { });
    },

    validateGeneratedInvoiceOnDates: function (contractId) {
        return this.validateGeneratedInvoice(contractId, "dates");
    },

    validateGeneratedInvoiceOnOccurences: function (contractId) {
        return this.validateGeneratedInvoice(contractId, "Occurences");
    },

    enterNoOfOccurences: function () {
        var locate = this.Locators;
        locate.startDateIcon.click();
        locate.startDateIcon.click();
        browser.sleep(1000)
        locate.todayDate.click();
        locate.OccurenceRdoBtn.click();
        locate.occurenceCountTextField.clear();
        return locate.occurenceCountTextField.sendKeys(3);
    },



    selectCreditInvoiceRdobtn: function () {
        var locate = this.Locators;
        locate.creditMemoRadioBtn.click();
        locate.proceed.click();
        return util.waitForPageReadyState().then(function () { })
    },

    selectDebitInvoiceRdobtn: function () {
        var locate = this.Locators;
        locate.debitMemoRadioBtn.click();
        element(by.xpath("//*[@id='projectIdDiv']/label[4]/input")).click()
        locate.proceed.click();
        return util.waitForPageReadyState().then(function () { })
    },

    searchForInvoiceOnGivenPeriod: function (period, contractId) {
        var locate = this.Locators;
        browser.sleep(3000)
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSheduleSearchfield.clear();
        locate.billingSheduleSearchfield.sendKeys(contractId+" "+period);
        util.waitUntilElementDisplayed(locate.applyBtn).then(function () { })
        browser.sleep(3000)
        locate.applyBtn.click();
        return util.waitForPageReadyState().then(function () { })
    },

    selectDate: function () {
        var locate = this.Locators;
        browser.sleep(1000)
        locate.BillingScheStartDateIcon.click()
        browser.sleep(1000)
        locate.swtitchToMonhtWhenDays.click()
        locate.swtitchToMonhtWhenMonths.click()
        locate.year2019.click()
        locate.JanMonthh.click()
        return locate.Day1.click()
    },

    validateBillingschedule_EmptyRecord: function (contractId, period) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSheduleSearchfield.clear();
        locate.billingSheduleSearchfield.sendKeys(contractId + " " + period + " Fixed");
        browser.sleep(2000)
        return locate.BillScheEmptyRecordText.getText().then(function (text) {
            assert.equal("No matching records found", text)
        })
    },

    openVariableInvoice: function (contractId, month) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSheduleSearchfield.clear();
        locate.billingSheduleSearchfield.sendKeys(contractId + " " + month + " Variable");
        locate.calculateButton.click();
        browser.sleep(1000)
        locate.generateCalConfirmYes.click()
        return util.waitForPageReadyState().then(function () { })
    },

    searchFOrDatebasedMilestoneInvoice: function (contractId) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSheduleSearchfield.clear();
        return locate.billingSheduleSearchfield.sendKeys(contractId + " " + util.todayDateIn_yyyy_mm_dd_format() + " Milestone");
    },

    searchFOrDatebasedMilestoneInvoiceOnSpecifiedMonth: function (contractId) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSheduleSearchfield.clear();
        locate.billingSheduleSearchfield.sendKeys(contractId + " " + util.todayDateIn_yyyy_mm_dd_format()  + " Milestone");
        util.waitUntilElementDisplayed(locate.applyBtn).then(function () { })
        locate.applyBtn.click();
        return util.waitForPageReadyState().then(function () { })
    },

    searchForOpsBasedMilestoneInvoice: function (contractId, month) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSheduleSearchfield.clear();
        locate.billingSheduleSearchfield.sendKeys(contractId + " " + month + " Milestone");
        locate.BillingScheStartDateIcon.click()
        locate.swtitchToMonht.click()
        locate.JanMonthh.click()
        locate.Day1.click()
        locate.applyBtn.click()
        return util.waitForPageReadyState().then(function () { })
    }

};// last line