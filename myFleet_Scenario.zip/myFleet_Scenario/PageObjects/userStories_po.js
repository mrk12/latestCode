(function() {
    'use strict';
    var invoiceCurrency;
    var invoiceCurrencyType;
    var currentPage = 'userStory';
    var myFleetPo = require("..//PageObjects//myFleet_po.js");
    
    var userStory = function() {

        return {


            waitUntilElementDisplayed: function (elemnt) {
                var EC = protractor.ExpectedConditions;
                browser.wait(EC.visibilityOf(elemnt), 60000);
                return browser.driver.sleep(1000);
            },
        validateQ2_5and5_0: function (callback) {
        browser.waitForAngular();
        myFleetPo.waitForPageReadyState().then(function(){});
        element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function (value) {
            console.log(value);
            if (value == true || value == "true") {
                browser.sleep(2000);
                element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                    browser.sleep(1000);
                    element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Radha');
                    browser.sleep(1000);
                    element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                        browser.sleep(10000);
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='180-91-RADIO']")).click();
                            browser.sleep(1000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(1000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(1000);
                            //2.5 - Within (Prior to end of billing period)/ No estimation required
                            element(by.xpath("//*[@id='5-320-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month of the quarter (within billing period)']")).click();
                            browser.sleep(1000);
                            // element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            // browser.sleep(5000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
                                console.log(value);
                                if (value == false) {
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    console.log("Selected Specified day of the month");
                                } else { console.log("Specified day of the month already selected"); }
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month of the quarter (within billing period)']")).click();
                                browser.sleep(1000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='33-129-RADIO']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='33-129-RADIO']")).click();
                                browser.sleep(5000);
                                callback();
                            });
                        });
                    });
                });
            } else {
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).isPresent();
                browser.sleep(5000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                    browser.sleep(1000);
                    element(by.xpath("//*[@id='1-1-RADIO']")).click();
                    browser.sleep(5000);
                    element(by.xpath("//*[@id='180-91-RADIO']")).click();
                    browser.sleep(1000);
                    //Selecting Monthly from 2.2 section
                    element(by.xpath("//*[@id='2-4-RADIO']")).click();
                    browser.sleep(1000);
                    //Selecting Quarterly from 2.3 section
                    element(by.xpath("//*[@id='3-9-RADIO']")).click();
                    browser.sleep(1000);
                    //2.5 - Within (Prior to end of billing period)/ No estimation required
                    element(by.xpath("//*[@id='5-320-RADIO']")).click();
                    browser.sleep(2000);
                    element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month of the quarter (within billing period)']")).click();
                    browser.sleep(1000);
                    // element(by.xpath("//*[@id='16-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                    // browser.sleep(5000);
                    element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
                        console.log(value);
                        if (value == false) {
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).click();
                            console.log("Selected Specified day of the month");
                        } else { console.log("Specified day of the month already selected"); }
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month of the quarter (within billing period)']")).click();
                        browser.sleep(1000);
                        //2.8--No
                        element(by.xpath("//*[@id='19-92-RADIO']")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='33-129-RADIO']")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='33-129-RADIO']")).click();
                        browser.sleep(5000);
                        browser.sleep(9000);
                        callback();
                    });
                });
            }
        });
    },

    noVariableBillingRadioBtn: function () {
        browser.waitForAngular();
       browser.driver.sleep(8000);
       return expect(element(by.xpath("//*[@id='33-129-RADIO']")).isPresent()).to.eventually.be.equals(true);
   },
   
   noVariableBillingRadioBtnTooltip: function () {
    browser.waitForAngular();
    browser.driver.sleep(5000);
    browser.actions().mouseMove(element(by.xpath("//*[@id='variabletermsAndConditionForms']//div/div[3]/label"))).perform();
    browser.driver.sleep(1000);
    return element(by.xpath("//*[@id='variabletermsAndConditionForms']//div/div[3]/label")).getAttribute('data-original-title');
},

    clickOnCommitBtn: function () {
    browser.waitForAngular();
     element(by.xpath("//*[@id='commit']")).click();
     browser.sleep(4000);
     console.log("User able to Commit");
     return element(by.xpath("//*[@id='confirmid3']")).click();
 },
 refreshPage: function () {
    browser.waitForAngular();
     browser.sleep(4000);
     return browser.driver.navigate().refresh();
 },
 
     validateTrueupForActualHoursQ2_13: function (callback) {
        browser.waitForAngular();
        myFleetPo.waitForPageReadyState().then(function(){});
        element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function (value) {
            console.log(value);
            if (value == true || value == "true") {
                browser.sleep(2000);
                element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                    browser.sleep(1000);
                    element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Radha');
                    browser.sleep(1000);
                    element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                        browser.sleep(10000);
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(2000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='180-91-RADIO']")).click();
                            browser.sleep(1000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(1000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(1000);
                            //2.5 - After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
                                console.log(value);
                                if (value == false) {
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    console.log("Selected Specified day of the month");
                                } else { console.log("Specified day of the month already selected"); }
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month following the end of each calendar quarter']")).click();
                                browser.sleep(1000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(1000);
                                //2.13 --Yes
                                element(by.xpath("//*[@id='130-91-RADIO']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='130-91-RADIO']")).click();
                                browser.sleep(5000);
                                callback();
                            });
                        });
                    });
                });
            } else {
                browser.sleep(5000);
                element(by.xpath("//*[@id='commit']")).isPresent();
                browser.sleep(1000);
                element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                    browser.sleep(3000);
                    element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='monetizationConfirmPopup']/div/div/div[3]/input[2]")).click();
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='180-91-RADIO']")).click();
                            browser.sleep(1000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(1000);
                            //Selecting Quarterly from 2.3 section
                            element(by.xpath("//*[@id='3-9-RADIO']")).click();
                            browser.sleep(1000);
                            //2.5 - After (After end of billing period)
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
                                console.log(value);
                                if (value == false) {
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    console.log("Selected Specified day of the month");
                                } else { console.log("Specified day of the month already selected"); }
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month following the end of each calendar quarter']")).click();
                                browser.sleep(1000);
                                //2.8--No
                                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                browser.sleep(1000);
                                //2.13 --Yes
                                element(by.xpath("//*[@id='130-91-RADIO']")).click();
                                browser.sleep(1000);
                                element(by.xpath("//*[@id='130-91-RADIO']")).click();
                                browser.sleep(5000);
                               callback();
                    });
                });
            }
        });
    },

    generalTCscommitBtn: function () {
        browser.waitForAngular();
        myFleetPo.waitForPageReadyState().then(function(){});
        element(by.xpath("//*[@id='130-92-RADIO']")).click();
        browser.sleep(2000);
         element(by.xpath("//*[@id='commit']")).click();
         browser.sleep(4000);
         console.log("User able to Commit");
         return element(by.xpath("//*[@id='confirmid3']")).click();
     },

     generalTCscommit2_5Btn: function () {
        browser.waitForAngular();
        myFleetPo.waitForPageReadyState().then(function(){});
         element(by.xpath("//*[@id='commit']")).click();
         browser.sleep(4000);
         console.log("User able to Commit");
         return element(by.xpath("//*[@id='confirmid3']")).click();
     },
     
    trueUpForActualHRS2_13RadioBtn: function () {
        browser.waitForAngular();
       browser.driver.sleep(8000);
       return expect(element(by.xpath("//*[@id='131-423-RADIO']")).isPresent()).to.eventually.be.equals(true);
   },
   
   trueUpInvoiceDateAmountRadioBtnTooltip: function () {
    browser.waitForAngular();
    browser.driver.sleep(5000);
    element(by.xpath("//*[@id='130-91-RADIO']")).click();
    browser.driver.sleep(1000);
    browser.actions().mouseMove(element(by.xpath("//*[@id='131']/div/div/div[2]/label"))).perform();
    browser.driver.sleep(1000);
    return element(by.xpath("//*[@id='131']/div/div/div[2]/label")).getAttribute('data-original-title');
     },

    // 9th jan 2020

    clickOnParametersTab: function(){
        myFleetPo.waitForPageReadyState().then(function(){})
        browser.sleep(2000)
         element(by.xpath("//li[@id='AeroCSAConstantsTab']/a")).click();
         return myFleetPo.waitForPageReadyState().then(function(){})
            },

     clickOnFuelTypeEditBtn: function(){
        myFleetPo.waitForPageReadyState().then(function(){})
            return element(by.xpath("(//span[@class='glyphicon glyphicon-pencil'])[3]")).click();
        },
        
        selectGasType: function(fuelType){
            browser.sleep(1000)
            element(by.xpath("//select[contains(@id, 'SELECT')]//option[@value='"+fuelType+"']")).click();
             element(by.xpath("//button[@id='updateParam']")).click();
             return myFleetPo.waitForPageReadyState().then(function(){});
        },
        
        selectNaturalGas: function(){
           return this.selectGasType("natural gas").then(function(){});
        },
          
        validateFuelTypeDropdownValue: function(fuelType){
            browser.sleep(1000)
        element(by.xpath("//li[@id='AeroCSAHoursTab']/a")).click();
        myFleetPo.waitForPageReadyState().then(function(){});
        element(by.xpath("//a[contains(@ng-click, 'Unapproved') or contains(@ng-click, 'null')]")).click();
        myFleetPo.waitForPageReadyState().then(function(){});
        element(by.xpath("//a[@ng-click='renderAddRowAeroHoursEditor()']")).click();
        browser.sleep(1000)
        element(by.xpath("//input[contains(@id, 'running')]")).click();
         return element(by.xpath("(//div[@class='ui-grid-cell-contents ng-binding ng-scope'])[2]")).getAttribute("title").then(function(text){
            assert.equal(fuelType, text);
            console.log(text+" Restricted to dropdown")
        })
        },
        
        validateNaturalgasRestriction: function(){
        return this.validateFuelTypeDropdownValue("natural gas").then(function(){});
        },
        
        validateRefinerygasRestriction: function(){
            return this.validateFuelTypeDropdownValue("refinery gas").then(function(){});
            },
        
            validateLowBTUGasgasRestriction: function(){
                return this.validateFuelTypeDropdownValue("Low BTU Gas").then(function(){});
                },
        
        changefuelTypeInParameterTable: function(FuelType){
        element(by.xpath("//button[@id='buttonClose']")).click();
        element(by.xpath("//*[@id='AeroCSAConstantsTab']")).click();
        this.clickOnFuelTypeEditBtn().then(function(){});
        return this.selectGasType(FuelType).then(function(){});
        },

changeRefineryGasType: function(){
return this.changefuelTypeInParameterTable("refinery gas").then(function(){})
},

changeLowBTUGasType: function(){
    return this.changefuelTypeInParameterTable("Low BTU Gas").then(function(){})
    },

    generalTCsForCCL150TxtValidation: function (callback) {
        browser.waitForAngular();
        myFleetPo.waitForPageReadyState().then(function(){});
        browser.sleep(1000);
        element(by.xpath("//*[@id='1-1-RADIO']")).click();
        browser.sleep(5000);
        element(by.xpath("//*[@id='180-91-RADIO']")).click();
        browser.sleep(1000);
        //Selecting Quarterly from 2.2 section
        element(by.xpath("//*[@id='2-5-RADIO']")).click();
        browser.sleep(1000);
         //Selecting Quarterly from 2.3 section
        element(by.xpath("//*[@id='3-9-RADIO']")).click();
        browser.sleep(1000);
        //2.5 - After (After end of billing period)
        element(by.xpath("//*[@id='5-19-RADIO']")).click();
        browser.sleep(2000);
        //2.6.1.Select day --Actual Day
        element(by.xpath("//*[@id='12-256-RADIO']")).click();
        browser.sleep(2000);
        element(by.xpath("//*[@id='12-SELECT']/option[@value='5th']")).click();
        browser.sleep(2000);
        element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
        browser.sleep(1000);
        element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
        console.log(value);
        if (value == false) {
        browser.sleep(1000);
        element(by.xpath("//*[@id='14-232-chkbox']")).click();
        console.log("Selected Specified day of the month");
        } else { console.log("Specified day of the month already selected"); }
        browser.sleep(1000);
        element(by.xpath("//*[@id='93-256-RADIO']")).click();
        browser.sleep(1000);
        element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
        browser.sleep(1000);
        element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month following the end of each calendar quarter']")).click();
        browser.sleep(1000);
        //2.8--No
        element(by.xpath("//*[@id='19-92-RADIO']")).click();
        //CCL Project Id selection
        browser.sleep(1000);
        element(by.xpath("//*[@id='102-1-chkbox']")).isSelected().then(function(status){
            //console.log("status :"+ status)
            if(status === false){
                element(by.xpath("//*[@id='102-1-chkbox']")).click();
                console.log("Selected CCL Project id");
            }else{console.log("lready Selected CCL Project id")}
                callback();
              });
           });
     },

     billingPeriodEditBtn: function(){
        myFleetPo.waitForPageReadyState().then(function(){})
        browser.sleep(2000)
         element(by.xpath("//*[@role='gridcell']/a/span")).click();
         element(by.xpath("//*[@id='poLine']")).sendKeys("Testing");
         element(by.xpath("(//*[@id='cclItem']/option[2])[2]")).click();
         browser.sleep(1000)
         element(by.xpath("(//*[@id='cclDes']/option[2])[2]")).click();
         browser.sleep(1000)
         element(by.xpath("(//*[@id='TaxClassification']/option[2])[2]")).click();
         browser.sleep(1000)
         element(by.xpath("(//*[@id='invLineAddlInfo1'])[2]")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
         browser.sleep(1000)
         element(by.xpath("(//*[@id='invLineAddlInfo2'])[2]")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
         browser.sleep(1000)
         element(by.xpath("(//*[@id='invLineAddlInfo3'])[2]")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
         browser.sleep(1000)
         element(by.xpath("(//*[@id='invLineAddlInfo4'])[2]")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
         browser.sleep(1000)
         element(by.xpath("//*[@id='invLineAddlInfo5']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
         browser.sleep(1000)
         element(by.xpath("//*[@id='OpfixedSave']")).click();
         return myFleetPo.waitForPageReadyState().then(function(){})
        },

        unscheduleManualInvoiceCreation: function(){
            myFleetPo.waitForPageReadyState().then(function(){})
            browser.sleep(2000)
             element(by.xpath("//*[@id='billingSchAddInvoice']")).click();
             browser.sleep(1000)
             element(by.xpath("(//*[@ng-model='selectedContractId']/option[text()='9992146'])[1]")).click();
             browser.sleep(1000)
             element(by.xpath("//*[@ng-model='selectedModelId']/option[2]")).click();
             browser.sleep(1000)
             element(by.xpath("(//*[@id='outageSave'])[1]")).click();
             return myFleetPo.waitForPageReadyState().then(function(){})
            },

            unscheduleCreditInvoiceCreation: function(){
                myFleetPo.waitForPageReadyState().then(function(){})
                browser.sleep(2000)
                 element(by.xpath("//*[@id='billingSchAddInvoice']")).click();
                 browser.sleep(1000)
                 element(by.xpath("(//*[@ng-model='selectedContractId']/option[text()='9992146'])[1]")).click();
                 browser.sleep(1000)
                 element(by.xpath("//*[@ng-model='selectedModelId']/option[2]")).click();
                 browser.sleep(1000)
                 element(by.xpath("//*[@value='CREDIT-MEMO']")).click();
                 browser.sleep(1000)
                 element(by.xpath("(//*[@id='outageSave'])[1]")).click();                 
                 return myFleetPo.waitForPageReadyState().then(function(){})
                },

                unscheduleDebitInvoiceCreation: function(){
                    myFleetPo.waitForPageReadyState().then(function(){})
                    browser.sleep(2000)
                     element(by.xpath("//*[@id='billingSchAddInvoice']")).click();
                     browser.sleep(1000)
                     element(by.xpath("(//*[@ng-model='selectedContractId']/option[text()='9992146'])[1]")).click();
                     browser.sleep(1000)
                     element(by.xpath("//*[@ng-model='selectedModelId']/option[2]")).click();
                     browser.sleep(1000)
                     element(by.xpath("//*[@value='DEBIT-MEMO']")).click();
                     browser.sleep(1000)
                     element(by.xpath("(//*[@id='outageSave'])[1]")).click();                     
                     return myFleetPo.waitForPageReadyState().then(function(){})
                    },

            unscheduleInvoiceValidation: function(){
                myFleetPo.waitForPageReadyState().then(function(){})
                browser.sleep(2000)
                 element(by.xpath("//*[@id='billingInvAddRow']")).click();
                 element(by.xpath("//*[@id='poLineId']")).sendKeys("Testing");
                 element(by.xpath("//*[@id='AdjItem']/option[2]")).click();
                 browser.sleep(1000)
                 element(by.xpath("//*[@id='cclDesAdj']/option[2]")).click();
                 browser.sleep(1000)
                 element(by.xpath("//*[@id='qtyId']")).clear();
                 browser.sleep(1000)
                 element(by.xpath("//*[@id='qtyId']")).sendKeys('1');
                 element(by.xpath("//*[@id='unitPriceId']")).clear();
                 browser.sleep(1000)
                 element(by.xpath("//*[@id='unitPriceId']")).sendKeys('1');
                 element(by.xpath("//*[@id='AdjTaxClassification']/option[2]")).click();
                 element(by.xpath("//*[@id='AdjInvLineAddlInfo1']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                 browser.sleep(1000)
                 element(by.xpath("//*[@id='AdjInvLineAddlInfo2']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                 browser.sleep(1000)
                 element(by.xpath("//*[@id='AdjInvLineAddlInfo3']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                 browser.sleep(1000)
                 element(by.xpath("//*[@id='AdjInvLineAddlInfo4']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                 browser.sleep(1000)
                 element(by.xpath("//*[@id='AdjInvLineAddlInfo5']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                 browser.sleep(1000)
                 element(by.xpath("(//*[@class='modal-footer']/i/b[text()='Inv Line Addtl Info fields must be 150 characters max.'])[1]")).getText().then(function(text){
            assert.equal('Inv Line Addtl Info fields must be 150 characters max.', text);
            console.log(text)
            });
            browser.sleep(2000)
              element(by.xpath("//*[@id='confirmSave']")).click();
         return myFleetPo.waitForPageReadyState().then(function(){})         
        },

                unscheduleCreditInvoiceValidation: function(){
                    myFleetPo.waitForPageReadyState().then(function(){})
                    browser.sleep(2000)
                     element(by.xpath("//*[@id='billingInvAddRow']")).click();
                     element(by.xpath("//*[@id='poLineId']")).sendKeys("Testing");
                     element(by.xpath("//*[@id='AdjItem']/option[2]")).click();
                     browser.sleep(1000)
                     element(by.xpath("//*[@id='cclDesAdj']/option[2]")).click();
                     browser.sleep(1000)
                     element(by.xpath("(//*[@id='qtyId'])[2]")).clear();
                     browser.sleep(1000)
                     element(by.xpath("(//*[@id='qtyId'])[2]")).sendKeys('-1');
                     element(by.xpath("//*[@id='unitPriceId']")).clear();
                     browser.sleep(1000)
                     element(by.xpath("//*[@id='unitPriceId']")).sendKeys('1');
                     element(by.xpath("//*[@id='AdjTaxClassification']/option[2]")).click();
                     element(by.xpath("//*[@id='AdjInvLineAddlInfo1']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                     browser.sleep(1000)
                     element(by.xpath("//*[@id='AdjInvLineAddlInfo2']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                     browser.sleep(1000)
                     element(by.xpath("//*[@id='AdjInvLineAddlInfo3']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                     browser.sleep(1000)
                     element(by.xpath("//*[@id='AdjInvLineAddlInfo4']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                     browser.sleep(1000)
                     element(by.xpath("//*[@id='AdjInvLineAddlInfo5']")).sendKeys("myFleet automation test script design for CCL ContractmyFleet automation test script design for CCL ContractmyFleet automation test script design forC");
                     browser.sleep(1000)
                     element(by.xpath("(//*[@class='modal-footer']/i/b[text()='Inv Line Addtl Info fields must be 150 characters max.'])[1]")).getText().then(function(text){
                        assert.equal('Inv Line Addtl Info fields must be 150 characters max.', text);
                        console.log(text)
                        });
                        browser.sleep(2000)
                          element(by.xpath("//*[@id='confirmSave']")).click();
                     return myFleetPo.waitForPageReadyState().then(function(){})         
                    },
                    
                    validationProjectCurrencyTable: function (callback) {
                        browser.waitForAngular();
                        myFleetPo.waitForPageReadyState().then(function(){});
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='1-1-RADIO']")).click();
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='180-91-RADIO']")).click();
                        browser.sleep(1000);
                        //Selecting Quarterly from 2.2 section
                        element(by.xpath("//*[@id='2-5-RADIO']")).click();
                        browser.sleep(1000);
                         //Selecting Quarterly from 2.3 section
                        element(by.xpath("//*[@id='3-9-RADIO']")).click();
                        browser.sleep(1000);
                        //2.5 - After (After end of billing period)
                        element(by.xpath("//*[@id='5-19-RADIO']")).click();
                        browser.sleep(2000);
                        //2.6.1.Select day --Actual Day
                        element(by.xpath("//*[@id='12-256-RADIO']")).click();
                        browser.sleep(2000);
                        element(by.xpath("//*[@id='12-SELECT']/option[@value='5th']")).click();
                        browser.sleep(2000);
                        element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
                        console.log(value);
                        if (value == false) {
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='14-232-chkbox']")).click();
                        console.log("Selected Specified day of the month");
                        } else { console.log("Specified day of the month already selected"); }
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='93-256-RADIO']")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month following the end of each calendar quarter']")).click();
                        browser.sleep(1000);
                        //2.8--No
                        element(by.xpath("//*[@id='19-92-RADIO']")).click();
                        //CCL Project Id selection
                        browser.sleep(1000);                      
                        // element(by.xpath("//*[@id='102-1-chkbox']")).isSelected().then(function(status){
                        //     element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        //     if(status === false){
                        //         element(by.xpath("//*[@id='102-1-chkbox']")).click();
                        //         console.log("Selected Second Project id");
                        //     }else{console.log("Already Selected Second Project id")}
                        // });
                        element(by.xpath("//*[@id='102-0-chkbox']")).click();
                        element(by.xpath("//*[@id='102-0-chkbox']")).isSelected().then(function(status){                            
                                if(status === false){
                                    element(by.xpath("//*[@id='102-0-chkbox']")).click();
                                    console.log("Selected 1st Project id");
                                }else{console.log("Already Selected 1st Project id")}
                                    callback();
                                  });
                        
                           });
                     },

                     projectCurrencyTableHeaderValidation: function(TableHeader){
                        browser.sleep(1000)
                        var text = element(by.xpath("//*[@role='button'][@title='"+TableHeader+"']/span")).getText();
                        //console.log(text);
                        return myFleetPo.waitForPageReadyState().then(function(){});
                    },

                    currencyTableProjectId: function(){
                        return this.projectCurrencyTableHeaderValidation("Project ID").then(function(){});
                     },

                     currencyTableContractCurrency: function(){
                        return this.projectCurrencyTableHeaderValidation("Contract Currency").then(function(){});
                     },

                     currencyTableInvoiceCurrency: function(){
                        return this.projectCurrencyTableHeaderValidation("Invoice Currency").then(function(){});
                     },

                     
                     currencyTableInvoiceAlternativeCurrency: function(){
                        return this.projectCurrencyTableHeaderValidation("Invoice Secondary Currency").then(function(){});
                     },

                     projectIdCount: function(){
                     element.all(by.xpath("//*[@class='ui-grid-cell-contents small-grid-font ng-binding ng-scope']")).count().then(function (count) {
                        console.log(count);
                        //assert.equal(count, '6');
                        });
                    },

                    ValidateCurrencytypeNA: function(){
                        browser.waitForAngular();
                         element(by.xpath("(//div[@class='ui-grid-cell-contents ng-binding ng-scope'])[3]")).getAttribute("title").then(function (count) {
                        //console.log(count); 
                         assert.equal(count, 'N/A');                   
                        // element(by.xpath("(//div[@class='ui-grid-cell-contents ng-binding ng-scope'])[6]")).getAttribute("title").then(function (count) {
                        // assert.equal(count, 'N/A');                     
                        // });
                     });
                     return browser.driver.sleep(1000);
                    },

                    enterFixedAmountPart: function (fixedAmount) {
                        browser.waitForAngular();
                        browser.driver.sleep(2000);
                        element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                        browser.driver.sleep(2000);
                        element(by.xpath("//*[@id='26-104-RADIO']")).click();
                        browser.driver.sleep(2000);
                        element(by.xpath("//input[@name='27-Currency']")).clear();
                        element(by.xpath("//input[@name='27-Currency']")).sendKeys(fixedAmount);
                        return browser.driver.sleep(5000);
                    },
        
                    enterVariableAmountPart: function (variableAmount) {
                        browser.waitForAngular();
                        browser.driver.sleep(2000);
                        element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                        browser.driver.sleep(2000);
                        element(by.xpath("//*[@id='33-127-RADIO']")).click();
                        element(by.xpath("//*[@id='34-SELECT']/option[text()='Actual Hours (AH)']")).click();
                        browser.driver.sleep(1000);
                        element(by.xpath("//*[@id='252-91-RADIO']")).click();
                        element(by.xpath("//*[@id='59-137-RADIO']")).click();
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).clear();
                        element(by.xpath("(//*[@name='60-Currency'])[1]")).sendKeys(variableAmount);
                        return browser.driver.sleep(5000);
                    },

                    creationOfUnscheduleManualInvoice: function(contract){
                        myFleetPo.waitForPageReadyState().then(function(){})
                        browser.sleep(2000)
                         element(by.xpath("//*[@id='billingSchAddInvoice']")).click();
                         browser.sleep(1000)
                         element(by.xpath("(//*[@ng-model='selectedContractId']/option[text()='"+ contract +"'])[1]")).click();
                         browser.sleep(1000)
                         element(by.xpath("//*[@ng-model='selectedModelId']/option[2]")).click();
                         browser.sleep(1000)
                         element(by.xpath("(//*[@id='outageSave'])[1]")).click();
                         return myFleetPo.waitForPageReadyState().then(function(){})
                        },

                        validateInvoiceCurrencyRadioBtn:function (callback) {
                            myFleetPo.waitForPageReadyState().then(function(){})
                            browser.sleep(3000)
                            element(by.xpath("(//*[@id='billingCalcContractID'])[1]")).isPresent().then(function(value){           
                            if(value == true || value == "true"){
                                    element(by.xpath("(//*[@name='invSecCurrFlag'])[2]")).isPresent().then(function () {
                                        console.log("Currency radio button is present");
                                        callback();
                                    });
                                }else{
                                        console.log("Currency radio button is not present");
                                        callback();
                                }
                            });
                        },

                        validationConversiondetailsForAlphaProcessing: function () {
                            myFleetPo.waitForPageReadyState().then(function(){})
                            element(by.xpath("(//*[@name='invSecCurrFlag'])[2]")).click();
                            browser.driver.sleep(1000);
                            return element(by.xpath("//*[@id='invoiceCurrency']")).getText().then(function (invoiceCurrencyTxt) {
                                invoiceCurrency = invoiceCurrencyTxt;
                                
                            });            
                        },
                        validationinvoiceCurrencyType: function () {
                            myFleetPo.waitForPageReadyState().then(function(){})
                            return element(by.xpath("//*[@id='calculatorSummary']/div[39]/div/section/table[6]/tbody/tr[1]/td[2]/label")).getText().then(function (currency) {
                                console.log("Invoice Currency Type:" + currency);
                                //invoiceCurrencyType = currency;
                                invoiceCurrencyTxt = currency;

                            });            
                        },

                        selectInvoiceAlternativeCurrencytype: function(currencyType){
                            myFleetPo.waitForPageReadyState().then(function(){})
                            var elem = element(by.xpath("(//div[contains(@class, 'ui-grid-cell ng-scope ui-grid-coluiGrid')])[4]"));
                            browser.actions().click(elem).perform();  
                            element(by.xpath("(//div[contains(@class, 'ui-grid-cell ng-scope ui-grid-coluiGrid')])[4]//*[contains(text(), '" + currencyType +"')]")).click();
                          return browser.driver.sleep(1000);
                        },

                        manualInvoiceApproveBtn: function(){
                            myFleetPo.waitForPageReadyState().then(function(){})
                            browser.sleep(2000)
                             element(by.xpath("(//*[@id='approveCalculator'])[1]")).click();
                             browser.sleep(1000)
                             element(by.xpath("(//*[@id='invCalId'][text()='Confirm'])[2]")).click();
                             browser.sleep(1000)
                             return myFleetPo.waitForPageReadyState().then(function(){})
                            },

                            manualInvoiceUnapproveBtn: function(){
                                myFleetPo.waitForPageReadyState().then(function(){})
                                browser.sleep(2000)
                                 element(by.xpath("(//*[@id='unApproveCalculator'])[1]")).click();
                                 browser.sleep(2000)                             
                                 return myFleetPo.waitForPageReadyState().then(function(){})
                                },

                                validateDisabledInvoiceCurrencyRadioBtn:function (callback) {
                                    myFleetPo.waitForPageReadyState().then(function(){})
                                    browser.sleep(3000)
                                    element(by.xpath("(//*[@name='invSecCurrFlag'][@disabled='disabled'])[1]")).isPresent().then(function(value){           
                                    if(value === true){
                                            element(by.xpath("(//*[@name='invSecCurrFlag'][@disabled='disabled'])[1]")).isPresent().then(function () {
                                                console.log("Currency radio button is Disabled");
                                                callback();
                                            });
                                        }else{
                                                console.log("Currency radio button is not Disabled");
                                                callback();
                                        }
                                    });
                                },

                                validationProjectCurrencyTableCCL: function (callback) {
                                    browser.waitForAngular();
                                    myFleetPo.waitForPageReadyState().then(function(){});
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='1-1-RADIO']")).click();
                                    browser.sleep(5000);
                                    element(by.xpath("//*[@id='180-91-RADIO']")).click();
                                    browser.sleep(1000);
                                    //Selecting Quarterly from 2.2 section
                                    element(by.xpath("//*[@id='2-5-RADIO']")).click();
                                    browser.sleep(1000);
                                     //Selecting Quarterly from 2.3 section
                                    element(by.xpath("//*[@id='3-9-RADIO']")).click();
                                    browser.sleep(1000);
                                    //2.5 - After (After end of billing period)
                                    element(by.xpath("//*[@id='5-19-RADIO']")).click();
                                    browser.sleep(2000);
                                    //2.6.1.Select day --Actual Day
                                    element(by.xpath("//*[@id='12-256-RADIO']")).click();
                                    browser.sleep(2000);
                                    element(by.xpath("//*[@id='12-SELECT']/option[@value='5th']")).click();
                                    browser.sleep(2000);
                                    element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month of the quarter (within billing period)']")).click();
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
                                    console.log(value);
                                    if (value == false) {
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    console.log("Selected Specified day of the month");
                                    } else { console.log("Specified day of the month already selected"); }
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month of the quarter (within billing period)']")).click();
                                    browser.sleep(1000);
                                    //2.8--No
                                    element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                    //CCL Project Id selection
                                    browser.sleep(1000);                      
                                    // element(by.xpath("//*[@id='102-1-chkbox']")).isSelected().then(function(status){
                                    //     element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    //     if(status === false){
                                    //         element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    //         console.log("Selected Second Project id");
                                    //     }else{console.log("Already Selected Second Project id")}
                                    // });
                                    element(by.xpath("//*[@id='102-0-chkbox']")).click();
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    element(by.xpath("//*[@id='102-1-chkbox']")).isSelected().then(function(status){                            
                                            if(status === false){
                                                element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                                console.log("Selected 1st Project id");
                                            }else{console.log("Already Selected 1st Project id")}
                                                callback();
                                              });
                                    
                                       });
                                 },

                                 
            searchforContractInBillingSchedule: function (contractId) {
                browser.sleep(2000);
                this.waitUntilElementDisplayed(element(by.xpath("//table[@id='myInvoiceCustomerTable']"))).then(function(){})
                return element(by.xpath("//input[@data-filter-table='myInvoiceTable']")).sendKeys(contractId);
        
            },

            clickOnBillingScheduleReview: function () {
                browser.sleep(2000);
                element(by.css("a#Review")).isDisplayed().then(function (condition) {
                    if (condition == true)
                        element(by.css("a#Review")).click()
                    else
                        element(by.css("a#Calculate")).clik()
                })
                return this.waitForPageReadyState().then(function () { })
            },

            selectEntitlement_InvoiceDate: function () {
                myFleetPo.waitForPageReadyState().then(function(){});
                //let today = new Date().getDate();
                var tommorrow = parseInt(new Date().getDate()) + 1;
                browser.sleep(1000)
                //element(by.xpath("//td[@class='day' or @class='new day'][contains(text(), '" + today + "')]")).click()
                element(by.xpath("//span[@id='userInvoiceDateVal']/button")).click()
                element(by.xpath("//span[@id='userInvoiceDateVal']/button")).click()
                browser.sleep(1000)
               /*  if (today != "31" || "30") {
                    element(by.xpath("//td[@class='day' or @class='new day'][contains(text(), '" + tommorrow + "')]")).click()
                }
                if (today == "31" || "30") {
                    element(by.xpath("//td[@class='day' or @class='new day'][contains(text(), '1')]")).click()
                } */
                return element(by.xpath("//td[@class='day' or @class='new day'][contains(text(), '" + tommorrow + "')]")).click()
            },

            validateFoxtrotWarningMsg: function(){
                myFleetPo.waitForPageReadyState().then(function(){});
            element(by.css("button#approveCalculator")).click();
            browser.sleep(1000);
             element(by.xpath("//div[@id='AeroFutureINVWarning']//div[@id='alertmodel']//p[2]")).getText().then(function(text){
                assert.equal(text, "Your invoice date is in future.")
                console.log(text)
            })
            element(by.xpath("//div[@id='AeroFutureINVWarning']//div[@id='alertmodel']/p[3]")).getText().then(function(text){
                assert.equal(text, "Please carefully review as Foxtrot will generate the invoice on this future date.")
            console.log(text)
             })
             element(by.xpath("//div[@id='AeroFutureINVWarning']//div[@id='alertmodel']/p[4]")).getText().then(function(text){
                assert.equal(text, "If future date falls within ERP closing period, invoice will be generated on the first date of next open billing period.")
             console.log(text)
             })
             element(by.xpath("//div[@id='AeroFutureINVWarning']//*[contains(text(), 'Close')]")).click();
             browser.sleep(1000);
             return element(by.xpath("//div[@id='invoiceApprModal']//a[1]")).click();
            },


            validationProjectCurrencyTableAero: function (callback) {
                browser.waitForAngular();
                myFleetPo.waitForPageReadyState().then(function(){});
                browser.sleep(1000);
                element(by.xpath("//*[@id='1-1-RADIO']")).click();
                browser.sleep(5000);
                element(by.xpath("//*[@id='180-91-RADIO']")).click();
                browser.sleep(1000);
                //Selecting Quarterly from 2.2 section
                element(by.xpath("//*[@id='2-5-RADIO']")).click();
                browser.sleep(1000);
                 //Selecting Quarterly from 2.3 section
                element(by.xpath("//*[@id='3-9-RADIO']")).click();
                browser.sleep(1000);
                //2.5 - After (After end of billing period)
                element(by.xpath("//*[@id='5-19-RADIO']")).click();
                browser.sleep(2000);
                //2.6.1.Select day --Actual Day
                element(by.xpath("//*[@id='12-256-RADIO']")).click();
                browser.sleep(2000);
                element(by.xpath("//*[@id='12-SELECT']/option[@value='5th']")).click();
                browser.sleep(2000);
                element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month following the end of each calendar quarter']")).click();
                browser.sleep(1000);
                element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
                console.log(value);
                if (value == false) {
                browser.sleep(1000);
                element(by.xpath("//*[@id='14-232-chkbox']")).click();
                console.log("Selected Specified day of the month");
                } else { console.log("Specified day of the month already selected"); }
                browser.sleep(1000);
                element(by.xpath("//*[@id='93-256-RADIO']")).click();
                browser.sleep(1000);
                element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                browser.sleep(1000);
                element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month following the end of each calendar quarter']")).click();
                browser.sleep(1000);
                //2.8--No
                element(by.xpath("//*[@id='19-92-RADIO']")).click();
                //CCL Project Id selection
                browser.sleep(1000);                      
                // element(by.xpath("//*[@id='102-1-chkbox']")).isSelected().then(function(status){
                //     element(by.xpath("//*[@id='102-1-chkbox']")).click();
                //     if(status === false){
                //         element(by.xpath("//*[@id='102-1-chkbox']")).click();
                //         console.log("Selected Second Project id");
                //     }else{console.log("Already Selected Second Project id")}
                // });
                element(by.xpath("//*[@id='102-0-chkbox']")).click();
                element(by.xpath("//*[@id='102-0-chkbox']")).isSelected().then(function(status){                            
                        if(status === false){
                            element(by.xpath("//*[@id='102-0-chkbox']")).click();
                            console.log("Selected 1st Project id");
                        }else{console.log("Already Selected 1st Project id")}
                        element(by.xpath("//*[@id='126-419-RADIO']")).click();
                            callback();
                          });
                
                   });
             },


                                 generalTCsForCombineAllEscalationValidation: function (callback) {
                                    browser.waitForAngular();
                                    myFleetPo.waitForPageReadyState().then(function(){});
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='1-1-RADIO']")).click();
                                    browser.sleep(5000);
                                    element(by.xpath("//*[@id='180-91-RADIO']")).click();
                                    browser.sleep(1000);
                                    //Selecting Quarterly from 2.2 section
                                    element(by.xpath("//*[@id='2-5-RADIO']")).click();
                                    browser.sleep(1000);
                                     //Selecting Quarterly from 2.3 section
                                    element(by.xpath("//*[@id='3-9-RADIO']")).click();
                                    browser.sleep(1000);
                                    //2.5 - Within (Prior to end of billing period)/ Estimation required
                                    element(by.xpath("//*[@id='5-20-RADIO']")).click();
                                    browser.sleep(2000);
                                    //2.6.1.Select day --Actual Day
                                    element(by.xpath("//*[@id='12-256-RADIO']")).click();
                                    browser.sleep(2000);
                                    //2.5.1-Contract level
                                    element(by.xpath("//*[@id='6-21-RADIO']")).click();
                                    browser.sleep(2000);
                                    //2.5.2-Manual input each period to be specified at the time of invoice generation
                                    element(by.xpath("//*[@id='7-23-RADIO']")).click();
                                    browser.sleep(2000);
                                    element(by.xpath("//*[@id='12-SELECT']/option[@value='5th']")).click();
                                    browser.sleep(2000);
                                    element(by.xpath("//*[@id='13-SELECT']")).element(by.xpath("//*[@id='13-SELECT']/option[text()='1st month of the quarter (within billing period)']")).click();
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).isSelected().then(function (value) {
                                    console.log(value);
                                    if (value == false) {
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='14-232-chkbox']")).click();
                                    console.log("Selected Specified day of the month");
                                    } else { console.log("Specified day of the month already selected"); }
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='93-256-RADIO']")).click();
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='15-SELECT']")).element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='16-SELECT']")).element(by.xpath("//*[@id='16-SELECT']/option[@value='1st month of the quarter (within billing period)']")).click();
                                    browser.sleep(1000);
                                    //2.8--No
                                    element(by.xpath("//*[@id='19-92-RADIO']")).click();
                                    //CCL Project Id selection
                                    browser.sleep(1000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).isSelected().then(function(status){
                                        //console.log("status :"+ status)
                                        if(status === false){
                                            element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                            console.log("Selected CCL Project id");
                                        }else{console.log("lready Selected CCL Project id")}
                                        element(by.xpath("//*[@id='126-419-RADIO']")).click();
                                            callback();
                                          });
                                       });
                                 },
                escalationRateTab: function () {
                myFleetPo.waitForPageReadyState().then(function(){});       
                element(by.xpath("//*[@id='escalationRateWidget']/div[1]/h3")).click()
                browser.sleep(1000)
                element(by.xpath("//*[@id='241-634-RADIO']")).click()
                browser.sleep(1000)
                element(by.xpath("//*[@id='248-656-RADIO']")).click()
                return myFleetPo.waitForPageReadyState().then(function(){});
            },

            combineAllEscalationIntoOneLineRadioBtn: function () {
            browser.waitForAngular();
            browser.driver.sleep(8000);
            return expect(element(by.xpath("//*[@id='249-660-RADIO']")).isPresent()).to.eventually.be.equals(true);
        },

        combineAllEscalationIntoOneLineRadioBtnTooltip: function () {
            myFleetPo.waitForPageReadyState().then(function(){})
            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
            browser.actions().mouseMove(element(by.xpath("//*[@id='249']/div/div/div[3]/label"))).perform();
            return element(by.xpath("//*[@class='tooltip fade top in']/div[2]")).getText().then(function(tooltipInfo){
             //return element(by.xpath("//*[@class='tooltip fade top in']/div[2]")).getAttribute('data-original-title');
             console.log("3.2.1 - Tooltip Text:"+ tooltipInfo);
		assert.equal(tooltipInfo, 'As contract is setup with variable estimation, escalation cannot be combined (fixed & variable)'); 
    });
    },

    excelReaderFunction: function () {
        /*var Excel = require('exceljs');
        var wrkbook = new Excel.Workbook();
        wrkbook.xlsx.readFile('../TestData/Sample-Template.xlsx').then(function() { 
            var worksheet = wrkbook.getWorksheet('Master');
            worksheet.eachRow(function (Row, rowNumber) {
               return console.log("Row " + rowNumber + " = " + JSON.stringify(Row.values));
            });
        });*/
var XLSX = require('xlsx');
var workbook = XLSX.readFile('../test.xlsx');
var first_sheet_name = workbook.SheetNames[0];
//var first_sheet_name = "LoginTest";
var address_of_cell = 'B2';
var worksheet = workbook.Sheets[first_sheet_name];
/* Find desired cell */
var desired_cell = worksheet[address_of_cell];
/* Get the value */
var desired_value = desired_cell.v;
//console.log(desired_value);
var sheet_name_list = workbook.SheetNames;
sheet_name_list.forEach(function(y) { /* iterate through sheets */
    var worksheet = workbook.Sheets[y];
    for (z in worksheet) {
        /* all keys that do not begin with "!" correspond to cell addresses */
        if(z[0] === '!') continue;
        console.log(y + "!" + z + "=" + JSON.stringify(worksheet[z].v));
    }
});
    },

                                 

                                 

                            

 

   };
};

module.exports = new userStory();

}());