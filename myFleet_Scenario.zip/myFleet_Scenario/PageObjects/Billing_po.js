/*
Created by Suresh BM

*/

var util = require("../PageObjects/Utility.js");
var today = util.todayDateIn_dd_format();
var locator = require('../taskmngmnt-element-repo.json')
var Excel = require('exceljs');
const XLSX = require('xlsx');
var filename;
var cond;
var myFleetPo = require("../PageObjects/myFleet_po.js");
var unScheInvPage = require("../PageObjects/createunscheduleInvoices_po.js");
var calBtnPresence = false;
var escalationAmount;

module.exports = {

    Locators:
    {
        createUnscheduledInvoices: element(by.xpath("//a[@id='billingSchAddInvoice']")),
        billingScheduleTable: element(by.xpath("//div[@id='myInvoiceCustomerTable_wrapper']")),
        billingSearcField: element(by.xpath("//input[@data-filter-table='myInvoiceTable']")),
        applyButton: element(by.xpath("button#dateApplyInvoice")),
        reviewBtn: element(by.css("a#Review")),
        reviewBtnCount: element.all(by.css("a#Review")),
        addAdjustmentbtn: element(by.xpath("//*[contains(@ng-click, 'invoiceAddParam')]")),
        poLineTextField: element(by.css("input#poLineId")),
        feeTypeDropdown: element(by.xpath("(//select[@id='selectedFeeType'])[3]//option[@value='VARIABLE']")),
        descriptiontextField: element(by.css("textarea[id='descriptionId']")),
        quantityField: element(by.xpath("(//input[@id='qtyId'])[1]")),
        unitPriceField: element(by.xpath("(//*[@id='unitPriceId'])[2]")),
        reccuringYesRdoBtn: element(by.xpath("//input[@name='ReOccurrence-Radio'][@value='Y']")),
        addBtn: element(by.xpath("//div[@id='invoiceAddAdjModal']//a[contains(@ng-click, 'SAVE')]")),
        updateBtn: element(by.css("a#confirmUpdate")),
        calculateButton: element(by.css("a#Calculate")),
        popupAdjAmount: element(by.xpath("//div[@id='otherAdjustGrid']//*[contains(text(), 'Total')]")),
        adjustmentsTemplate: element(by.css("a#adjustmentsTemplateLink")),
        uploadAdjustments: element(by.xpath("//a[@ng-click='uploadTrueUpAdjustments();']")),
        chooseBtn: element(by.css("input#files")),
        uploadBtn: element(by.xpath("//div[@id='uploadTrueUpAdjustmentsTemplate']//a[@id='uploadSubmit']")),
        poLineTitleViaDoc: element(by.xpath("//*[text()='Po line via doc " + today + "']")),
        forecastSummarySearchbox: element(by.xpath("//input[@data-filter-table='forecastSummaryGrid']")),
        forecastSummaryStatusCol: element(by.xpath("//table[@id='forecastSummary']/tbody/tr/td[10]")),
        forecastSummaryAmountCol: element(by.xpath("//table[@id='forecastSummary']/tbody/tr/td[8]")),
        forecastSummaryReviewBtn2: element(by.xpath("//a[@id='Review']")),
        forecastSummarytable: element(by.xpath("//table[@id='forecastSummary']")),
        unlockForecastBtn: element(by.css("button#unlockForecast")),
        EditIcon: element(by.xpath("//div[@id='otherAdjustGrid']//span[@class='glyphicon glyphicon-pencil']")),
        invoiceLockbutton: element(by.css("button#lockForecast")),
        proceedWithLock: element(by.css("a#forecastCalId")),
        billingScheduleAmountCol: element(by.xpath("//table[@id='myInvoiceCustomerTable']/tbody/tr/td[8]")),
        deleteInvoice: element(by.css("button#deleteInvoice")),
        confirmYesBtn: element(by.css("a#deleteInvoiceId")),
        contractNumberlab: element(by.css("label#billingCalcContractID")),
        creditMemoReasonDropdwn: element(by.xpath("//select[@id='creditMemoReason']//option[@value='Fixed Monthly Fee Adjustment']")),
        backButton: element(by.css("button#backCalculator")),
        emptyTableTextMsg: element(by.xpath("//td[contains(text(), 'No matching records found')]")),
        approveBtn: element(by.css("button#approveCalculator")),
        proceedWithApprove: element(by.xpath("//a[@id='invCalId' and contains(text(), 'Proceed with Approval')]")),
        BillingScheduleStatusCol: element(by.xpath("//table[@id='myInvoiceCustomerTable']//td[11]")),
        reasonOther: element(by.css("input#Other")),
        confirmReason: element(by.css("a#confirmInvoiceReason")),
        deleteIcon: element(by.xpath("//span[@class='glyphicon glyphicon-trash']")),
        deleteEvent: element(by.xpath("//input[@name='adjDelOnSeriesOrEvent'][@value='EVENT']")),
        deleteSeries: element(by.xpath("//input[@name='adjDelOnSeriesOrEvent'][@value='SERIES']")),
        deleteConfirm: element(by.css("a#deleteid1")),
        adjustmentAmountCol: element(by.xpath("(//div[@id='otherAdjustGrid']//div[@role='gridcell'])[9]")),
        billingScheduleAmountCol1: element(by.xpath("//div[@id='myInvoiceCustomerTable_wrapper']/table/tbody/tr[1]/td[8]")),
        billingScheduleAmountCol2: element(by.xpath("//div[@id='myInvoiceCustomerTable_wrapper']/table/tbody/tr[2]/td[8]")),
        billingScheduleAmountCol3: element(by.xpath("//div[@id='myInvoiceCustomerTable_wrapper']/table/tbody/tr[3]/td[8]")),
        generateCalConfirmYes: element(by.css("a#invCalId")),
        invoiceTotalAmount: element(by.xpath("//div[@id='invoiceBillingGrid']//*[contains(text(), 'Total')]")),
        escaTotalAmount: element(by.xpath("//div[@id='invoiceBillingGrid']//*[contains(text(), 'Escalation')]/parent::div/parent::div/div[9]/div")),
        allUnitsEsca: element.all(by.xpath("//div[@id='invoiceBillingGrid']//*[contains(text(), 'Escalation')]/parent::div/parent::div/div[9]/div")),
        escTotalAmountAERO: element(by.xpath("//*[contains(text(), 'Escalation')]/parent::div/parent::div/div[8]")),
        allUnitsEscaAERO: element.all(by.xpath("//*[contains(text(), 'Escalation')]/parent::div/parent::div/div[8]")),
        invoiceBillingGridRows: element.all(by.xpath("//div[@id='invoiceBillingGrid']//div[@class='ui-grid-row ng-scope']")),
        NotApprovalOkBtn: element(by.xpath("//div[@id='opsDataApprovalModal']//a[contains(text(), 'Ok')]")),
        nextBtn: element(by.xpath("//div[@id='myInvoiceCustomerTable_wrapper']//li[4]/a")),
        addMilestoneButton: element(by.css("a#billingAddMilInv")),
        ApprovedMileAmnt: element(by.xpath("//div[@id='manualInvoiceGrid']/div[2]/div/div[2]/div/div/div/div[2]/div")),
        mileAmountSaveBtn: element(by.css("a#confirmSaveMilInv")),
        totlaBillable: element(by.css("input#totalFixedBilling")),
        customerPaymentDateVal: element(by.xpath("//*[@id='customerPaymentDateVal']/button")),
        todayDatee: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '" + today + "')]")),

    },



    clickOnCreateUnscheduledInvoices: function () {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { });
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        return locate.createUnscheduledInvoices.click();
    },

    validateCreatedunscheduledInvoiceinBillindSchedule: function (contractID) {
        var locate = this.Locators;
        var todayDate = util.todayDateIn_yyyy_mm_dd_format().then(function () { })
        locate.billingSearcField.sendkeys(contractID + " " + todayDate);
        locate.applyButton.click();
        return util.waitForPageReadyState().then(function () { });
    },

    openCreatedManualInvoice: function (contractId, month) {
        var locate = this.Locators;
        browser.sleep(1000)
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSearcField.clear();
        locate.billingSearcField.sendKeys(contractId + " " + month);
        browser.sleep(1000)
        locate.reviewBtn.click();
        return util.waitForPageReadyState().then(function () { })
    },

    openfirstmonthInvoice: function (contractId) {
        return this.openCreatedManualInvoice(contractId, util.todayDateIn_yyyy_mm_dd_format())
    },

    openSecondmonthInvoice: function (contractId) {
        return this.openCreatedManualInvoice(contractId, util.secondMonthDateIn_yyyy_mm_dd_format())
    },

    clickOnAddAdjustment: function () {
        var locate = this.Locators;
        browser.sleep(2000)
        return locate.addAdjustmentbtn.click();
    },

    fillAdjustmentDetails: function (quantity, unitPrice) {
        var locate = this.Locators;
        browser.sleep(2000)
        locate.poLineTextField.isDisplayed().then(function (condtion) {
            if (condtion == true) {
                locate.poLineTextField.clear();
                locate.poLineTextField.sendKeys("Po line on " + today);
            }
        })
        util.waitUntilElementDisplayed(locate.feeTypeDropdown).then(function () { })
        locate.feeTypeDropdown.click();
        locate.descriptiontextField.sendKeys("Test manual Invoice adustments");
        locate.quantityField.sendKeys(quantity)
        locate.unitPriceField.sendKeys(unitPrice)
        locate.reccuringYesRdoBtn.click();
        browser.sleep(2000)
        locate.addBtn.click()
        browser.sleep(6000)
        return util.waitForPageReadyState().then(function () { })
    },

    validateAddedAdjustmentViaPopup: function () {
        var locate = this.Locators;
        util.waitUntilElementDisplayed(locate.popupAdjAmount).then(function () { })
        browser.sleep(1000)
        return locate.popupAdjAmount.getText().then(function (text) {
            var amount = text.substring(7);
            console.log("amount: " + amount)
            assert.equal(amount, " 30.00");
        })
    },

    downloadAdjustmentTemplate: function () {
        var locate = this.Locators;
        var path = require('path');

        // var filename = path.resolve(__dirname, locator.filePath.unscheduledInvAdjustmentTemplt);
        locate.contractNumberlab.getText().then(function (text) {
            var cond = text.substring(0, 4);
            if (cond == "AERO") {
                filename = path.resolve(__dirname, locator.filePath.unscheduledInvAdjustmentTempltAERO);
            } else {
                filename = path.resolve(__dirname, locator.filePath.unscheduledInvAdjustmentTemplt);
            }
        })
        if (fs.existsSync(filename)) {
            fs.unlinkSync(filename);
        }
        locate.adjustmentsTemplate.click();
        browser.driver.sleep(3000);
        browser.driver.wait(function () {
            return fs.existsSync(filename);
        }, 30000).then(function () {
            expect(fs.existsSync(filename)).to.equal(true);
        });
        return browser.driver.sleep(1000);
    },

    editAdjustmentTemplate: function () {

        var locate = this.Locators;
        var path = require('path');
        browser.sleep(2000)
        locate.contractNumberlab.getText().then(function (text) {
            console.log("text: " + text)
            cond = text.substring(0, 4);
            if (cond == "AERO") {
                filename = path.resolve(__dirname, locator.filePath.unscheduledInvAdjustmentTempltAERO);
                const workbook = XLSX.readFile(filename, { bookVBA: true });
                let worksheet = workbook.Sheets['TrueUpAdjustments Template'];
                XLSX.utils.sheet_add_aoa(worksheet, [
                    [],
                    ["FIXED", 'N/A', 'Test manual Invoice adustments through Excel', 10, 10, 'YES']
                ]);
                XLSX.writeFile(workbook, filename);
            } else {
                filename = path.resolve(__dirname, locator.filePath.unscheduledInvAdjustmentTemplt);
                const workbook = XLSX.readFile(filename, { bookVBA: true });
                let worksheet = workbook.Sheets['TrueUpAdjustments Template'];
                XLSX.utils.sheet_add_aoa(worksheet, [
                    [],
                    ["Po line via doc " + today, "FIXED", 'N/A', 'Test manual Invoice adustments through Excel', 10, 10, 'YES']
                ]);
                XLSX.writeFile(workbook, filename);
            }
        })
        try {
            console.log('Completed ...');

        } catch (error) {
            console.log(error.message);
            console.log(error.stack);
        }
        locate.uploadAdjustments.click();
        locate.chooseBtn.sendKeys(filename);
        browser.sleep(1000);
        locate.uploadBtn.click();
        return util.waitForPageReadyState().then(function () { })
    },

    validateAddedAdjustmentViaExcel: function () {
        var locate = this.Locators;
        util.waitUntilElementDisplayed(locate.popupAdjAmount).then(function () { })
        browser.sleep(1000)
        return locate.popupAdjAmount.getText().then(function (text) {
            var amount = text.substring(7);
            console.log("amount: " + amount)
            assert.equal(amount.trim(), "130.00");
        })
    },

    searchForInvoice_VerifyInvoiceLock: function () {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        browser.sleep(1000);
        element(by.css("section[id='forecastOpsDataWidget']")).click();
        browser.sleep(1000);
        element(by.css("input[value='Previous Year Monthly Average']")).click();
        element(by.css("input#useCurrentRate")).click();
        element(by.css("button[value='Forecast']")).click()
        util.waitForPageReadyState().then(function () { })
        browser.sleep(3000);
        locate.forecastSummarySearchbox.sendKeys(util.secondMonthDateIn_yyyy_mm_dd_format());
        return locate.forecastSummaryStatusCol.getText().then(function (value) {
            assert.equal(value, "Forecast");
        })
    },

    validateInvoiceInForecastSummaryTable: function () {
        var locate = this.Locators;
        return locate.forecastSummaryAmountCol.getText().then(function (value) {
            console.log("value: " + value)
            assert.equal(value.trim(), "130.00");
        })
    },


    goToInvoiceFromForecastSummary: function () {
        var locate = this.Locators;
        locate.forecastSummaryReviewBtn2.click();
        return util.waitForPageReadyState().then(function () { })
    },

    verifyInvoiceAdjustmentLines: function () {
        var locate = this.Locators;
        browser.sleep(1000)
        return locate.popupAdjAmount.getText().then(function (text) {
            var amount = text.substring(7);
            console.log("amount: " + amount)
            assert.equal(amount.trim(), "130.00");
        })
    },

    unlockInvoice: function () {
        var locate = this.Locators;
        locate.unlockForecastBtn.click();
        browser.sleep(3000)
        return util.waitForPageReadyState().then(function () { })
    },

    editExistRecord: function () {
        var locate = this.Locators;
        browser.sleep(1000)
        locate.EditIcon.click();
        browser.sleep(2000)
        locate.unitPriceField.clear()
        return locate.unitPriceField.sendKeys(100)

    },

    updateDetails: function () {
        var locate = this.Locators;
        locate.updateBtn.click()
        return util.waitForPageReadyState().then(function () { })
    },

    lockInvoice: function () {
        var locate = this.Locators;
        locate.invoiceLockbutton.click();
        util.waitUntilElementDisplayed(locate.proceedWithLock).then(function () { })
        locate.proceedWithLock.click()
        browser.sleep(25000)
        return util.waitForPageReadyState().then(function () { })

    },

    validateEditedDetailsInActualBilling: function (contractID, amount, date) {
        var locate = this.Locators;
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSearcField.sendKeys(contractID + " " + date)

        return locate.billingScheduleAmountCol.getText().then(function (value) {
            console.log("Adjusted invoice amount: " + value)
            if (value.trim() == "600.00" || "1,030.00") {
                assert.equal(value.trim(), "600.00" || "1,030.00")
            } else {
                console.log("Invoice amount not generating as per expectation")
                //assert.equal(true, false)
            }
        })
    },

    validateEditedDetailsInActualBilling_P_A: function (contractID) {
        return this.validateEditedDetailsInActualBilling(contractID, "1,030.00", util.secondMonthDateIn_yyyy_mm_dd_format())
    },

    validateEditedDetailsInActualBilling_CreditMemo: function (contractID) {
        return this.validateEditedDetailsInActualBilling(contractID, "-1,000.00", util.todayDateIn_yyyy_mm_dd_format() + " " + "Credit")
    },

    validateEditedDetailsInActualBilling_DebitMemo: function (contractID) {
        return this.validateEditedDetailsInActualBilling(contractID, "1,000.00", util.todayDateIn_yyyy_mm_dd_format() + " " + "Debit")
    },

    deleteInvoiceFromActualBilling: function (contractID) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSearcField.clear()
        locate.billingSearcField.sendKeys(contractID + " " + today)
        locate.reviewBtn.click();
        util.waitForPageReadyState().then(function () { })
        locate.deleteInvoice.click();
        browser.sleep(1000)
        locate.confirmYesBtn.click();
        return util.waitForPageReadyState().then(function () { })
    },


    validateDeletedInvoiceFromBilling: function (contractID) {
        var locate = this.Locators;
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSearcField.sendKeys(contractID + " " + util.todayDateIn_yyyy_mm_dd_format());

        locate.reviewBtnCount.count().then(function (count) {
            if (count < 5) {
                console.log("Invoice deleted from Billing schedule successfully")
            } else if (locate.emptyTableTextMsg.isDisplayed() == true) {
                console.log("Invoice deleted from Billing schedule successfully")
            } //else assert.equal(true, false);
        })
        browser.navigate().refresh();
        return util.waitForPageReadyState().then(function () { })
    },

    validateDeletedInvoiceFromForecast: function () {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.forecastSummarytable).then(function () { })
        locate.forecastSummarySearchbox.sendKeys(util.todayDateIn_yyyy_mm_dd_format() + " MANUAL INVOICE");
        return locate.reviewBtnCount.count().then(function (count) {
            if (count < 5) {
                assert.equal(true, true);
                console.log("Invoice deleted from foecast summary successfully")
            } else assert.equal(true, false);
        })
    },

    fillAdjustmentDetailsOnCreditMemo: function () {
        var locate = this.Locators;
        locate.poLineTextField.isDisplayed().then(function (condtion) {
            if (condtion == true) {
                locate.poLineTextField.sendKeys("Po line on " + today);
            }
        })
        util.waitUntilElementDisplayed(locate.feeTypeDropdown).then(function () { })
        locate.feeTypeDropdown.click();
        locate.creditMemoReasonDropdwn.click();
        locate.descriptiontextField.sendKeys("Test manual Invoice adustments");
        locate.quantityField.sendKeys(10)
        locate.unitPriceField.sendKeys(10)
        browser.sleep(2000);
        locate.addBtn.click();
        return util.waitForPageReadyState().then(function () { })
    },

    validateMemoInvoice: function (type) {
        var locate = this.Locators;
        element(by.css("section[id='forecastOpsDataWidget']")).click();
        browser.sleep(1000);
        element(by.css("input[value='Previous Year Monthly Average']")).click();
        element(by.css("input#useCurrentRate")).click();
        element(by.css("button[value='Forecast']")).click()
        util.waitForPageReadyState().then(function () { })
        browser.sleep(3000);
        locate.forecastSummarySearchbox.sendKeys(type + util.todayDateIn_yyyy_mm_dd_format());
        return locate.forecastSummaryStatusCol.getText().then(function (value) {
            assert.equal(value, "Forecast");
        })
    },

    searchForCreditMemoInvoice_VerifyInvoiceLock: function () {
        return this.validateMemoInvoice("Credit ").then(function () { })
    },

    searchForDebitMemoInvoice_VerifyInvoiceLock: function () {
        return this.validateMemoInvoice("Debit ").then(function () { })
    },

    validateInvoiceAmount: function (amount) {
        var locate = this.Locators;
        return locate.forecastSummaryAmountCol.getText().then(function (value) {
            console.log("value: " + value)
            assert.equal(value.trim(), amount);
        })
    },
    validateCreditMemo_InvoiceInForecastSummaryTable: function () {
        return this.validateInvoiceAmount("-100.00")
    },

    validateDebitMemo_InvoiceInForecastSummaryTable: function () {
        return this.validateInvoiceAmount("100.00")
    },

    clickOnBackButton: function () {
        var locate = this.Locators;
        locate.backButton.click();
        return util.waitForPageReadyState().then(function () { })
    },

    clickOnReviewButton: function () {
        var locate = this.Locators;
        locate.reviewBtn.click();
        return util.waitForPageReadyState().then(function () { })
    },

    fillAdjustmentDetailsOnDebit: function () {
        var locate = this.Locators;
        browser.sleep(2000)
        locate.feeTypeDropdown.click();
        locate.descriptiontextField.sendKeys("Test manual Invoice adustments");
        locate.quantityField.sendKeys(10)
        locate.unitPriceField.sendKeys(10)
        locate.addBtn.click();
        return util.waitForPageReadyState().then(function () { })
    },
    fillAdjustmentDetailsOnDebit1: function () {
        //var locate = this.Locators;
        browser.sleep(2000)
        element(by.xpath("//*[@id='poLineId']")).sendKeys("po lone 9");
        browser.sleep(1000)
        element(by.xpath("//*[@id='AdjItem']/option[2]")).click();
        element(by.xpath("//*[@id='cclDesAdj']/option[2]")).click();
        element(by.xpath("//*[@id='qtyId']")).sendKeys("5");
        element(by.xpath("//*[@id='unitPriceId']")).sendKeys("5");
        element(by.xpath("//*[@id='AdjTaxClassification']/option[2]")).click();
        element(by.xpath("//*[@id='AdjInvLineAddlInfo1']")).sendKeys("Test manual Invoice1");
        element(by.xpath("//*[@id='AdjInvLineAddlInfo2']")).sendKeys("Test manual Invoice2");
        element(by.xpath("//*[@id='AdjInvLineAddlInfo3']")).sendKeys("Test manual Invoice3");
        element(by.xpath("//*[@id='AdjInvLineAddlInfo4']")).sendKeys("Test manual Invoice4");
        element(by.xpath("//*[@id='AdjInvLineAddlInfo5']")).sendKeys("Test manual Invoice5");
        browser.sleep(1000)
        element(by.xpath("//*[@id='confirmSave']")).click();
        return util.waitForPageReadyState().then(function () { })
    },

    approveAndvalidateManlinv: function (contractId) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        locate.approveBtn.click();
        browser.sleep(1000)
        locate.proceedWithApprove.click();
        browser.sleep(1000)
        util.waitForPageReadyState().then(function () { })
        browser.sleep(1000)
        locate.backButton.click();
        browser.sleep(1000)
        /* locate.reasonOther.isDisplayed().then(function(condtion){
            if(condtion == true){
            util.waitUntilElementDisplayed(locate.reasonOther).then(function(){})
            locate.reasonOther.click()
            locate.confirmReason.click()
            }
        }) */
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSearcField.sendKeys(contractId + " " + util.secondMonthDateIn_yyyy_mm_dd_format() + " Approved");
        return locate.BillingScheduleStatusCol.getText().then(function (text) {
            assert.equal(text, "Approved")
        })
    },


    OpenNextInvoiceEditAndApprove: function (contractId) {
        var locate = this.Locators;
        locate.billingSearcField.clear();
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSearcField.sendKeys(contractId + " " + util.thirdMonthDateIn_yyyy_mm_dd_format());
        locate.reviewBtn.click();
        util.waitForPageReadyState().then(function () { })
        locate.addAdjustmentbtn.click()
        browser.sleep(1000)
        util.waitUntilElementDisplayed(locate.feeTypeDropdown).then(function () { })
        locate.feeTypeDropdown.click();
        locate.descriptiontextField.sendKeys("Test manual Invoice adustments");
        locate.quantityField.sendKeys(5)
        locate.unitPriceField.sendKeys(6)
        locate.reccuringYesRdoBtn.click();
        locate.addBtn.click();
        util.waitForPageReadyState().then(function () { })
        browser.sleep(1000)
        locate.approveBtn.click()
        util.waitUntilElementDisplayed(locate.proceedWithApprove).then(function () { })
        locate.proceedWithApprove.click();
        util.waitForPageReadyState().then(function () { })
        locate.backButton.click();
        browser.sleep(1000)
        locate.reasonOther.isDisplayed().then(function (condtion) {
            if (condtion == true) {
                util.waitUntilElementDisplayed(locate.reasonOther).then(function () { })
                locate.reasonOther.click()
                locate.confirmReason.click()
            }
        })
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.billingScheduleTable).then(function () { })
        locate.billingSearcField.sendKeys(contractId + " " + util.thirdMonthDateIn_yyyy_mm_dd_format() + " Approved");
        return locate.BillingScheduleStatusCol.getText().then(function (text) {
            assert.equal(text, "Approved")
        })
    },


    refreshPage: function () {
        browser.navigate().refresh()
        return util.waitForPageReadyState().then(function () { })
    },

    clickOnDebitMemoBackBtn: function () {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        browser.sleep(5000)
        locate.backButton.click();
        browser.sleep(2000)
        return util.waitForPageReadyState().then(function () { })
    },

    verifySingleDeleteOption: function (contractId) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        locate.deleteIcon.click();
        browser.sleep(2000)
        locate.deleteEvent.click();
        browser.sleep(1000)
        locate.deleteConfirm.click();
        util.waitForPageReadyState().then(function () { })
        myFleetPo.billingScheduleCalculateBackBtn().then(function () { })
        locate.billingSearcField.sendKeys(contractId + " " + util.todayDate() + " " + "Manual Invoice")
        browser.sleep(2000)
        locate.billingScheduleAmountCol1.getText().then(function (value) {
            assert.equal(value, '');
        })
        locate.billingScheduleAmountCol2.getText().then(function (value) {
            assert.equal(value, '30.00');
        })
        locate.billingScheduleAmountCol3.getText().then(function (value) {
            assert.equal(value, '30.00');
        })
        return browser.sleep(1000)
    },

    verifyDeleteAllOption: function (contractId) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        locate.deleteIcon.click();
        browser.sleep(2000)
        locate.deleteSeries.click();
        browser.sleep(1000)
        locate.deleteConfirm.click();
        util.waitForPageReadyState().then(function () { })
        myFleetPo.billingScheduleCalculateBackBtn().then(function () { })
        locate.billingSearcField.sendKeys(contractId + " " + util.todayDate() + " " + "Manual Invoice")
        browser.sleep(2000)
        locate.billingScheduleAmountCol1.getText().then(function (value) {
            assert.equal(value, '');
        })
        locate.billingScheduleAmountCol2.getText().then(function (value) {
            assert.equal(value, '');
        })
        locate.billingScheduleAmountCol3.getText().then(function (value) {
            assert.equal(value, '');
        })
        return browser.sleep(1000)

    },



    clickOnCalculateBtn_validateAmount: function (amount) {
        return this.clickAndValidate(amount, "invoiceTotalAmount", "", "Calculate").then(function () { })
    },

    clickOnCalculateBtn_validateAmountOndifferentPeriods: function (amount) {
        return this.clickAndValidate(amount, "invoiceTotalAmount", "round2", "Calculate").then(function () { })
    },

    clickOnReviewBtn_ValidateAMount: function (amount, escaType) {
        return this.clickAndValidate(amount, "invoiceTotalAmount", "", "Review").then(function () { })
    },

    clickOnReviewBtn_ValidateAMountWhenRoundTwodecimals: function (amount, escaType) {
        return this.clickAndValidate(amount, "invoiceTotalAmount", "round2", "Review").then(function () { })
    },


    clickOnCalculateAndApprove: function () {
        var locate = this.Locators;
        browser.sleep(1000)
        locate.calculateButton.click()
        browser.sleep(1000)
        locate.generateCalConfirmYes.click()
        util.waitForPageReadyState().then(function () { })
        browser.sleep(1000)
        locate.approveBtn.click()
        browser.sleep(1000)
        locate.proceedWithApprove.click()
        return util.waitForPageReadyState().then(function () { })
    },

    clickOnReviewBtnANdThenApproveInvoice: function () {
        var locate = this.Locators;
        browser.sleep(1000)
        locate.reviewBtn.click()
        util.waitForPageReadyState().then(function () { })
        // locate.customerPaymentDateVal.click();
        // locate.customerPaymentDateVal.click();
        // locate.todayDatee.click()
        locate.approveBtn.click()
        browser.sleep(1000)
        locate.proceedWithApprove.click()
        return util.waitForPageReadyState().then(function () { })
    },

    clickOnCalculateAndAddAdjustments: function () {
        var locate = this.Locators;
        browser.sleep(1000)
        locate.calculateButton.click()
        browser.sleep(1000)
        locate.generateCalConfirmYes.click()
        util.waitForPageReadyState().then(function () { })
        browser.sleep(1000)
        locate.addMilestoneButton.click()
        util.waitForPageReadyState().then(function () { })
        browser.sleep(1000)
        locate.mileAmountSaveBtn.click()
        util.waitForPageReadyState().then(function () { })
        browser.sleep(1000)
        element(by.css("a#billingInvAddRow")).click()
        return browser.sleep(1000)
    },

    clickAndValidate: function (amount, amountType, escaType, btnType) {

        var locate = this.Locators;
        if (btnType == "Calculate") {
            browser.sleep(2000)
            locate.calculateButton.click()
            browser.sleep(1000)
            locate.generateCalConfirmYes.click()
            browser.sleep(3000)
            locate.NotApprovalOkBtn.isDisplayed().then(function (status) {
                console.log("status: " + status)
                if (status == true) {
                    locate.NotApprovalOkBtn.click()
                    console.log("Please Approve Op data")
                }
            })
        }
        if (btnType == "Review") {
            browser.sleep(2000)
            locate.reviewBtn.click()
        }
        util.waitForPageReadyState().then(function () { })
        if (amountType == "invoiceTotalAmount") {
            locate.invoiceTotalAmount.getText().then(function (text) {
                var actualAmount = text.substring(8).replace(/,/g, "");
                console.log("actualAmount: " + actualAmount)
                if (escaType == "round2") {
                    assert.equal(parseFloat(actualAmount), amount)
                } else {
                    assert.equal(parseInt(actualAmount), amount)
                }
            })
        }
        if (amountType == "escTotalAmount") {
            browser.sleep(2000)
            locate.contractNumberlab.getText().then(function (contID) {
                var status = contID.substring(0, 4)
                console.log("status: " + status)
                if (status == "AERO") {
                    browser.sleep(2000)
                    return locate.escTotalAmountAERO.getText().then(function (text) {
                        console.log("escalationAmount: " + text)
                        var actualAmount = text.replace(/,/g, "");
                        console.log("escaTotalAmount: " + actualAmount)
                        if (escaType == "round2") {
                            assert.equal(parseFloat(actualAmount), amount)
                        } else {
                            assert.equal(parseInt(actualAmount), amount)
                        }
                    })
                } else {
                    browser.sleep(1000)
                    locate.escaTotalAmount.click()
                    browser.sleep(1000)
                    return locate.escaTotalAmount.getText().then(function (text) {
                        console.log("escalationAmount: " + text)
                        var actualAmount = text.replace(/,/g, "");
                        console.log("escaTotalAmount: " + actualAmount)
                        if (escaType == "round2") {
                            assert.equal(parseFloat(actualAmount), amount)
                        } else {
                            assert.equal(parseInt(actualAmount), amount)
                        }
                    })
                }
            })
        }
        return browser.sleep(1000)
    },


    clickAndValidate_EscalationAmount: function (amount) {
        return this.clickAndValidate(amount, "escTotalAmount", "", "Calculate").then(function () { })
    },

    clickAndValidate_EscalationAmountRound2Dece: function (amount) {
        return this.clickAndValidate(amount, "invoiceTotalAmount", "round2", "Calculate").then(function () { })
    },

    clickAndValidate_EscalationAmountDontRoundDecimalValues: function (amount) {
        return this.clickAndValidate(amount, "invoiceTotalAmount", "round2", "Calculate").then(function () { })
    },

    ValidateVaribaleAmountInvoice: function (variableAmount, unitCount, escaltion) {
        var locate = this.Locators;
        var escAmount = parseInt(variableAmount) * parseFloat(escaltion) * parseInt(600)
        var amountWithoutEsc = parseInt(variableAmount) * parseInt(600)
        var expectedPerUnit = parseInt(escAmount) + parseInt(amountWithoutEsc)
        var expectedTotal = parseInt(expectedPerUnit) * parseInt(unitCount)

        return locate.invoiceTotalAmount.getText().then(function (text) {
            var actualAmount = text.substring(8).replace(/,/g, "");
            console.log("actualVariableAmount: " + actualAmount + "Expected varibale amount :" + expectedTotal)
            assert.equal(parseInt(actualAmount), parseInt(expectedTotal))
        })
    },

    clickAndValidate_combinedEScalation: function (amount) {
        return this.clickAndValidate(amount, "escTotalAmount", "", "Calculate").then(function () { })
    },

    clickOnReviewAndValidate_combinedEScalation: function (amount) {
        return this.clickAndValidate(amount, "escTotalAmount", "", "Review").then(function () { })
    },

    displayAllAvailableUnitsEScalationValues: function () {
        var locate = this.Locators;
        return locate.contractNumberlab.getText().then(function (contID) {
            var status = contID.substring(0, 4)
            if (status == "AERO") {
                browser.sleep(2000)
                return locate.allUnitsEscaAERO.getText().then(function (text) {
                    console.log("Escalation on two Units: " + text)
                })
            } else {
                browser.sleep(1000)
                locate.allUnitsEsca.getText().then(function (text) {
                    console.log("Escalation on two Units: " + text)
                })
            }
        })
    }


};// last line

