var util = require("../PageObjects/Utility.js");
var presentMonth = util.currentMonth();
var janMonth = util.janMonth();
var CreateUnsheInvPage = require("../PageObjects/createunscheduleInvoices_po.js");
var today = util.todayDateIn_dd_format();
var contractType;
let unitCount;
var currentPage = 'taskMgmtPage';

module.exports = {

    Locators: {

        generalContctTs_Cs_Tab: element(by.xpath("//section[@id='generalContractWidget']/div/h3")),
        contractIdLabelValue: element(by.css("label#contractID")),
        LeasedUnit_Yes_RdoBtn: element(by.xpath("//*[contains(text(), 'Does the Contract have Leased Unit')]/parent::div//input[@value='Yes']")),
        LeasedUnit_No_RdoBtn: element(by.xpath("//*[contains(text(), 'Does the Contract have Leased Unit')]/parent::div//input[@value='No']")),
        Contract_level: element(by.xpath("//input[@value='Contract level']")),
        confirmMonetiseButton: element(by.css("input[value='Confirm']")),
        Individual_equipment_level: element(by.xpath("//input[@value='Individual equipment level']")),
        are_Fix_Var_Billed_sameFreYesRdoBtn: element(by.xpath("//*[contains(text(), 'Are fixed and variable fees billed at')]/parent::div//input[@value='Yes']")),
        are_Fix_Var_Billed_sameFreNoRdoBtn: element(by.xpath("//*[contains(text(), 'Are fixed and variable fees billed at')]/parent::div//input[@value='No']")),
        MonthlyFee_FixVar: element(by.xpath("//*[contains(text(), 'Fee application frequency -Fixed Billing') or contains(text(), 'Fee application frequency - Variable/ Fixed Billing')]/parent::div//input[@value='Monthly fee']")),
        Quarterlyfee_FixVar: element(by.xpath("//*[contains(text(), 'Fee application frequency -Fixed Billing') or contains(text(), 'Fee application frequency - Variable/ Fixed Billing')]/parent::div//input[@value='Quarterly fee']")),
        Semiannualfee_FixVar: element(by.xpath("//*[contains(text(), 'Fee application frequency -Fixed Billing') or contains(text(), 'Fee application frequency - Variable/ Fixed Billing')]/parent::div//input[@value='Semi-annual fee']")),
        Annualfee_FixVar: element(by.xpath("//*[contains(text(), 'Fee application frequency -Fixed Billing') or contains(text(), 'Fee application frequency - Variable/ Fixed Billing')]/parent::div//input[@value='Annual fee']")),
        Monthly_FixVar: element(by.xpath("//*[contains(text(), 'Invoicing Frequency --Fixed Billing') or contains(text(), 'Invoicing Frequency - Variable/Fixed')]/parent::div//input[@value='Monthly']")),
        Quarterly_FixVar: element(by.xpath("//*[contains(text(), 'Invoicing Frequency --Fixed Billing') or contains(text(), 'Invoicing Frequency - Variable/Fixed')]/parent::div//input[@value='Quarterly']")),
        Semiannually_FixVar: element(by.xpath("//*[contains(text(), 'Invoicing Frequency --Fixed Billing') or contains(text(), 'Invoicing Frequency - Variable/Fixed')]/parent::div//input[@value='Semi-annually']")),
        Annually_FixVar: element(by.xpath("//*[contains(text(), 'Invoicing Frequency --Fixed Billing') or contains(text(), 'Invoicing Frequency - Variable/Fixed')]/parent::div//input[@value='Annually']")),
        deviation_dropdown: element(by.xpath("//select[@id='4-SELECT']/option[@value='0']")),
        deviation_dropdownOnemonth: element(by.xpath("//select[@id='4-SELECT']/option[@value='-1']")),
        AfterRdoBtn_FixVar: element(by.css("input[id='5-19-RADIO']")),
        withinEstiReqRdoBtn_FixVar: element(by.css("input[id='5-20-RADIO']")),
        within_No_EstiReqRdoBtn_FixVar: element(by.css("input[id='5-320-RADIO']")),
        contractIDOnTsCs: element(by.css("label[id='contractID']")),

        AfterRdoBtn_Fix: element(by.css("input[id='184-19-RADIO']")),
        withinEstiReqRdoBtn_Fix: element(by.css("input[id='184-20-RADIO']")),
        within_No_EstiReqRdoBtn_Fix: element(by.css("input[id='184-320-RADIO']")),

        AfterRdoBtn_Var: element(by.css("input[id='204-19-RADIO']")),
        withinEstiReqRdoBtn_Var: element(by.css("input[id='204-20-RADIO']")),
        within_No_EstiReqRdoBtn_Var: element(by.css("input[id='204-320-RADIO']")),

        Invoice_ActualDay_FixVar: element(by.css("input[id='12-256-RADIO']")),
        InvoiceCurrentMonthBilling: element(by.xpath("//select[@id='13-SELECT']/option[@value='Current billing month (within billing period)']")),
        Invoice_BussinessDay_FixVar: element(by.css("input[id='12-257-RADIO']")),
        InvoiceDate_FixVar: element(by.xpath("//select[@id='12-SELECT']/option[@value='6th']")),
        invoice1stMonth_FixVar: element(by.xpath("//select[@id='13-SELECT']/option[@value='1st month following the end of each calendar quarter']")),
        invoicepostMonth_FixVar: element(by.xpath("//select[@id='13-SELECT']/option[@value='Month post billing period close']")),
        invoice2ndPostMonth_FixVar: element(by.xpath("//select[@id='13-SELECT']/option[@value='2nd Month post billing period close']")),

        Invoice_ActualDay_Fix: element(by.css("input[id='193-256-RADIO']")),
        Invoice_BussinessDay_Fix: element(by.css("input[id='193-257-RADIO']")),
        InvoiceDate_Fix: element(by.xpath("//select[@id='193-SELECT']/option[@value='" + today + "th']")),
        InvoiceCurrentMonth_Fix: element(by.xpath("//select[@id='194-SELECT']/option[@value='Current billing month (within billing period)']")),

        Invoice_ActualDay_Var: element(by.css("input[id='213-256-RADIO']")),
        Invoice_BussinessDay_Var: element(by.css("input[id='213-257-RADIO']")),
        InvoiceDate_Var: element(by.xpath("//select[@id='213-SELECT']/option[@value='6th']")),

        Specified_dayof_themonth_FixVar: element(by.css("input[id='14-232-chkbox']")),
        Specified_NumberOf_days_FixVar: element(by.css("input[id='14-233-chkbox']")),
        specified_dayOf_month_Fix: element(by.css("input[id='195-232-chkbox']")),
        Specified_NumberOf_days_Fix: element(by.css("input[id='195-233-chkbox']")),

        paymentActualDay_FixVar: element(by.css("input[id='93-256-RADIO']")),
        paymentBussinessDay_FixVar: element(by.css("input[id='93-257-RADIO']")),
        paymentDate_FixVar: element(by.xpath("//select[@id='15-SELECT']//option[@value='10th']")),
        paymentPostMonth_Fixvar: element(by.xpath("//select[@id='16-SELECT']//option[@value='Month post billing period close']")),
        payment1stMonth_Fixvar: element(by.xpath("//select[@id='16-SELECT']//option[@value='1st month following the end of each calendar quarter']")),
        payment2ndMonth_Fixvar: element(by.xpath("//select[@id='16-SELECT']//option[@value='2nd Month post billing period close']")),
        NumberOfDaysDropDown: element(by.xpath("//select[@id='17-SELECT']//option[@value='30']")),
        earlierOf_FixVar: element(by.css("input[id='18-89-RADIO']")),
        laterOf_FixVar: element(by.css("input[id='18-90-RADIO']")),
        bonus_LD_YesRdo_FixVar: element(by.css("input[id='19-91-RADIO']")),
        bonus_LD_NoRdo_FixVar: element(by.css("input[id='19-92-RADIO']")),
        NoBillingEscalationRdoBtn: element(by.css("input[id='20-92-RADIO']")),
        projectIdChCkBox: element(by.css("//*[contains(text(), 'Please select the Project ID')]/parent::div//input[contains(@name, 'checkBox')]")),
        Use_default_description: element(by.css("input[value='Use default description']")),
        Create_customized_description: element(by.css("input[value='Create customized description']")),
        Combine_as_a_single_invoice: element(by.css("input[value='Combine as a single invoice']")),
        Generate_separate_invoices: element(by.css("input[value='Generate separate invoices']")),
        NoTruUpRdoBtn_FixVar: element(by.css("input[id='130-92-RADIO']")),
        TruUpRdoBtnYes_FixVar: element(by.css("input[id='130-91-RADIO']")),

        escalationTab: element(by.xpath("//section[@id='escalationRateWidget']/div/h3")),
        Onerateforallbillings: element(by.xpath("//input[@value='One rate for all billings']")),
        Different_ratesper_billingfeetypes: element(by.xpath("//input[@value='Different rates per billing fee types']")),
        Differentratesperperiod: element(by.xpath("//input[@value='Different rates per period']")),
        Differentratesperequipment: element(by.xpath("//input[@value='Different rates per equipment (SN)']")),
        Different_rates_perprojectID: element(by.xpath("//input[@value='Different rates per project ID']")),
        no_Escalation: element(by.xpath("//input[@value='No escalation']")),
        Escalation_Rate_TextField: element(by.xpath("//input[contains(@id, 'Escalation Rate')]")),
        allbillingsChkBox: element(by.xpath("//input[@id='243-639-chkbox']")),
        Fixed_billings: element(by.xpath("//input[@id='243-640-chkbox']")),
        Variable_billings: element(by.xpath("//input[@id='243-641-chkbox']")),
        Milestone_billings: element(by.xpath("//input[@id='243-642-chkbox']")),
        Bonus_Chkbx: element(by.xpath("//input[@id='243-643-chkbox']")),
        LD_Chkbx: element(by.xpath("//input[@id='243-644-chkbox']")),
        AsaSeparateLine_RdoBtn: element(by.css("input[value='As a separate line']")),
        Include_Escalation_RdoBtn: element(by.xpath("//input[contains(@value, 'Include escalation to the unit price')]")),
        splitByUnit_RdoBtn: element(by.xpath("//input[contains(@value, 'Split by unit/by billing type')]")),
        Split_Fix_Var_Mile_fee_escalations_RdoBtn: element(by.xpath("//input[contains(@value, 'Split Fixed, Variable and Milestone fees escalations')]")),
        Combine_all_escalation_into_oneline: element(by.xpath("//input[contains(@value, 'Combine all escalation into one line')]")),

        escRowsOnDifferentPeriods: element.all(by.xpath("//form[@id='escalationtermsAndConditionForms']//span[@class='glyphicon glyphicon-trash']")),
        escRowsOnDifferentPeriod: element.all(by.xpath("(//form[@id='escalationtermsAndConditionForms']//span[@class='glyphicon glyphicon-trash'])[1]")),
        escDeletebrn: element(by.css("input[id='deleteRow']")),
        escAddButton: element(by.xpath("//form[@id='escalationtermsAndConditionForms']//a[contains(@ng-click, 'renderAddRowPopUp')]")),
        escEditOneIcon: element(by.xpath("(//form[@id='escalationtermsAndConditionForms']//a[contains(@ng-click, 'renderEditPopUp')])[1]")),
        escEditTwoIcon: element(by.xpath("(//form[@id='escalationtermsAndConditionForms']//a[contains(@ng-click, 'renderEditPopUp')])[2]")),
        escOnDiffPerTextFiled: element(by.css("input[id='Escalation Rate-textBox']")),
        escApplyAllBillings: element(by.xpath("//div[@id='editTableTree']//input[@id='245-chkBox-all']")),
        escApplyAllBillingsAERO: element(by.xpath("(//div[@id='editTableTree']//input[@id='245-chkBox-all'])[2]")),
        escApplyFixBilling: element(by.xpath("//div[@id='editTableTree']//input[@id='245-chkBox-fixed']")),
        escStartDateIcon: element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button")),
        escEndDateIcon: element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[4]/td[2]/div/span/button")),

        perUnitEScIDOne: element(by.xpath("//select[@id='246-SELECT']/option[2]")),
        perUnitEScIDTwo: element(by.xpath("//select[@id='246-SELECT']/option[3]")),
        perUnitEScIDOneEdit: element(by.xpath("//select[@id='246-SELECT']/option[1]")),
        perUnitEScIDTwoEdit: element(by.xpath("//select[@id='246-SELECT']/option[2]")),
        perUnitFixed: element(by.css("input[id='Fixed-246']")),
        perUnitVariable: element(by.css("input[id='Variable-246']")),
        perUnitMilestone: element(by.css("input[id='Milestone-246']")),
        perUnitBonus: element(by.css("input[id='Bonus-246']")),
        perUnitLDs: element(by.css("input[id='LDs-246']")),

        diffEscOnDiff_editIconOne: element(by.xpath("(//p[contains(text(), 'Please update escalations per project ID')]/parent::div//a/span)[1]")),
        diffEscOnDiff_editIconTwo: element(by.xpath("(//p[contains(text(), 'Please update escalations per project ID')]/parent::div//a/span)[2]")),
        fixedEscalation: element(by.xpath("//input[@id='Fixed-247']")),
        variableEscalation: element(by.xpath("//input[@id='Variable-247']")),
        milestoneEscalation: element(by.xpath("//input[@id='Milestone-247']")),
        updateEscaltion: element(by.xpath("//button[contains(@ng-click,'UpdateParam')]")),

        fixBillEscaTextField: element(by.css("input[id='Fixed billings-244']")),
        varBillEscaTextField: element(by.css("input[id='Variable billings-244']")),
        mileBillEscaTextField: element(by.css("input[id='Milestone billings-244']")),
        bonusBillEscaTextField: element(by.css("input[id='Bonus-244']")),
        LDBillEscaTextField: element(by.css("input[id='LD-244']")),
        fixMemberEscaTextField: element(by.css("input[id='Fixed Membership-244']")),
        varLeaseBillEscaTextField: element(by.css("input[id='Variable lease fee-244']")),
        weeklyLeaseEscaTextField: element(by.css("input[id='Weekly lease Fee-244']")),

        VariableBillingTsCs: element(by.xpath("//section[@id='variableBillingWidget']/div/h3")),
        AutoamticCalculationModeRdoBtn: element(by.css("input[value='Automatic calculation mode using Operating Factors']")),
        ManualVariable: element(by.css("input[value='Manual - Not configured in ICAM']")),
        OpFactorAHdropdwon: element(by.xpath("//select[@id='34-SELECT']/option[@value='Actual Hours (AH)']")),
        No_vaiableBilling: element(by.css("input[value='No variable billings']")),
        calculation3620YesRdoBtn: element(by.css("input[id='252-91-RADIO']")),
        decimal2: element(by.css("input[value='2 decimal']")),
        roundDecimal2: element(by.css("input[value='Round to 2 decimals']")),
        dontRoundRdobtn: element(by.css("input[value='Do not Round']")),
        oneRateAcrossEntireContractRdoBtn: element(by.css("input[value='One rate across the entire contract timeline']")),
        diffRatesAcross_DiffDateRanngesRdoBtn: element(by.css("input[value='Different rates across different time periods']")),
        diffRatesAcross_DiffRangeOfOperationsRdoBtn: element(by.css("input[value='Different rates across different range of operations']")),
        AHRateTextField: element(by.css("input[name='60-Currency']")),
        variableMonetisedNO: element(by.css("input[id='120-92-RADIO']")),
        differentRangesAHTextField: element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")),
        startinRangeTextField: element(by.css("input[id='Starting Range-textBox']")),
        endRangetextfield: element(by.css("input[id='Ending Range-textBox']")),
        diffRatesOn_DiffFuelTypesRdoBtn: element(by.css("input[value='Different rates for different fuel types']")),
        operatingFactorAHRdoBtn: element(By.css("input[value='Actual Hours(AH)']")),
        operatingFactorFFHRdoBtn: element(By.css("input[value='Factored Fired Hours(FFH)']")),
        refreshFrequencyMonthly: element(by.css("input[id='228-552-RADIO']")),
        refreshFrequencyQuarterly: element(by.css("input[id='228-553-RADIO']")),
        refreshFrequencyAnually: element(by.css("input[id='228-554-RADIO']")),
        refreshFrequencyAnualMOnth: element(by.xpath("//select[@id='229-SELECT']/option[@value='Feb']")),
        Does_rate_based_on_ops_range_YesRdoBtn: element(by.css("input[id='230-91-RADIO']")),
        Does_rate_based_on_ops_range_NoRdoBtn: element(by.css("input[id='230-92-RADIO']")),
        selectFuelTypeAsNaturalGas: element(by.xpath("//option[@value='Natural Gas Hours']")),
        selectFuelTypeAsRefineryGas: element(by.xpath("//option[@value='Refinery Gas Hours']")),
        AHRateAcrossDiffFuelType: element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/input")),


        FixedBillingTab: element(by.xpath("//section[@id='fixedBillingWidget']/div/h3")),
        FixedBillEntireContract: element(by.css("input[value='Fixed billing amount for the entire contract']")),
        FixedBillfor_start_endPeriods: element(by.css("input[value='Fixed billing amount at different start and end period']")),
        FixedBill_At_Diff_Events: element(by.css("input[value='Fixed billing amount at different Event Dates']")),
        FixedBill_specified_Op_DataRadnge: element(by.css("input[value='Fixed billing amount to change with specified operating data ranges']")),
        NO_FixedBill: element(by.css("input[value='No Fixed Billing']")),
        FixBillTextField: element(by.css("input[name='27-Currency']")),
        prorateFixBillYes: element(by.css("input[id='99-91-RADIO']")),
        prorateFixBillNo: element(by.css("input[id='99-92-RADIO']")),
        FixedBillSubhjectToMonetiseYes: element(by.css("input[id='118-91-RADIO']")),
        FixedBillSubhjectToMonetiseNo: element(by.css("input[id='118-92-RADIO']")),

        fixedBillAddrowBtn: element(by.xpath("//form[@id='fixedtermsAndConditionForms']//a[contains(@ng-click, 'renderAddRowPopUp')]")),
        variableBillAddrowBtn: element(by.xpath("//form[@id='variabletermsAndConditionForms']//a[contains(@ng-click, 'renderAddRowPopUp')]")),
        fixBill_popupTextField: element(by.css("input[name='28-textBox']")),
        varBill_popupTextField: element(by.css("input[name='61-textBox']")),
        fixBill_StartdateIcon: element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[2]/td[2]/div/span/button")),
        swtitchToMonhtWhenDays: element(by.xpath("//div[@class='datepicker-days']//*[@class='datepicker-switch']")),
        swtitchToMonhtWhenMonths: element(by.xpath("//div[@class='datepicker-months']//*[@class='datepicker-switch']")),
        year2019: element(by.xpath("//span[@class='year' or @class='year old' or @class='year active'][contains(text(), '2019')]")),
        year2020: element(by.xpath("//span[@class='year' or @class='year old' or @class='year new'][contains(text(), '2020')]")),
        JanMonthh: element(by.xpath("//span[@class='month' or @class='month active'][contains(text(), 'Jan')]")),
        Day1: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '1')]")),
        fixBill_enddateIcon: element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[3]/td[2]/div/span/button")),
        DecMonthh: element(by.xpath("//span[@class='month' or @class='month active'][contains(text(), 'Dec')]")),
        Day31: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '31')]")),
        FixBill_Addbutton: element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")),

        MilestoneBillingTab: element(by.xpath("//section[@id='milestoneBillingWidget']/div/h3")),
        eventBasedMilestone: element(by.css("input[id='84-185-chkbox']")),
        OpearationsBasedMile: element(by.css("input[id='84-186-chkbox']")),
        dateBasedMile: element(by.css("input[id='84-187-chkbox']")),
        relationshipBasedMile: element(by.css("input[id='84-188-chkbox']")),
        NOMilestone: element(by.css("input[id='84-605-chkbox']")),
        MilestoneMOnetisedNORdoBtn: element(by.css("input[id='122-92-RADIO']")),
        MIlestoneMonetisedYesRdoBtn: element(by.css("input[id='122-91-RADIO']")),
        MilestoneAddRowBtn: element(by.xpath("//form[@id='milestonetermsAndConditionForms']/div[6]/div/div[2]//a[contains(@ng-click, 'renderAddRowPopUp') or contains(@ng-click, 'renderEditPopUp')]")),
        
        MilestoneAmountTextField: element(by.css("input[name='124-textBox']")),
        MilestoneDescription: element(by.css("textarea[name='124-textBox']")),
        currentMonthh: element(by.xpath("//span[@class='month' or @class='month active'][contains(text(), '" + presentMonth + "')]")),
        januaryMonthh: element(by.xpath("//span[@class='month' or @class='month active'][contains(text(), '" + janMonth + "')]")),
        swtitchToMonht: element(by.xpath("//div[@class='datepicker-days']//*[@class='datepicker-switch']")),
        todayDate: element(by.xpath("//td[@class='day' or @class='active day'][contains(text(), '" + today + "')]")),

        OpsBasedMileAddrowbtn: element(by.xpath("//*[contains(text(), 'Operations based milestone billings')]/parent::div/div[2]//a")),
        equipmentId: element(by.xpath("//select[@id='86-SELECT']/option[2]")),
        OperatingFactrAH: element(by.xpath("//select[@id='86-SELECT']/option[@value='AH']")),
        noOfHoursTextField: element(by.css("input[id='No. of Hours/Starts-textBox']")),
        OpsbasedCurrencyTextField: element(by.xpath("//input[@name='86-textBox'][@format='currency']")),
        OpsBasedMIleDescription: element(by.css("textarea[id='Description-textBox']")),

        unitCountAll: element.all(by.xpath("//a[contains(@onclick, 'loadEquipLevelData')]")),
        MilestoneAddRowBtnp: element(by.xpath("//a[contains(@ng-click, 'renderAddRowPopUp')]")),

        BackToForecast: element(by.css("button#backToForecast")),
       // Variable Billing Tab
        Variable_billings_Tab: element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")),
        Variable_Automatic_calculationMode : element(by.xpath("//*[@id='33-127-RADIO']")),
        Variable_5_1_1_0 : element(by.xpath("//*[@id='33-127-RADIO']")),
        Variable_5_1_1_1 : element(by.xpath("//*[@id='221-540-RADIO']")),
        Variable_5_1_1_4 : element(by.xpath("//*[@id='59-663-RADIO']")),
        Variable_5_1_1_4_5_DeleteRow :element(by.xpath("//*[@class='glyphicon glyphicon-trash']")),
        Variable_5_1_1_4_5_DeleteRowConfBtn : element(by.xpath("//*[@id='deleteRow']")),
        Variable_5_1_1_4_5_AddRowBtn : element(by.xpath("//*[@id='251']/div[5]/div[2]/a")),
        Variable_5_1_1_4_5_AHRateAmount : element(by.xpath("//*[@id='alertmodel']/table/tbody/tr[1]/td[2]/input")),
        Variable_5_1_1_4_5_InjectionType : element(by.xpath("//*[@id='251-SELECT']/option[text()='Water injection']")),
        Variable_5_1_1_4_5_AddFinalRowBtn : element(by.xpath("//*[@id='editTableTree']/div/div/div[3]/button")),
//Send to Alpha Button
        sendToAlphaButton : element(by.xpath("(//*[@id='sendToAlpha'])[1]")),
        sendToAlphaPopupYesButton : element(by.xpath("//*[@id='alertmodel']/input[1]")),
        sendToAlphaPopupNoButton : element(by.xpath("//*[@id='alertmodel']/input[2]")),
        sendToAlphaPopUpYesSSOButton : element(by.xpath("(//*[@id='alertmodel']/div/input)[4]")),
        sendToAlphaSaveButton :  element(by.xpath("//*[@id='sendToErpAlertModal']/div/div/div[3]/a[2]")),
        sendToAlphaPopupNoOKButton  : element(by.xpath("//*[@id='sendToErpAlertModal']/div/div/div[3]/a[1]")),
//One Touch Button
        oneTouchApprovalButton : element(by.xpath("(//*[@id='alphaAutoApproval'])[1]")),
        proceedWithOneTouchApprovalButton : element(by.xpath("(//*[@id='approveId'])[2]")),
    oneTouchApprovalReturntoInvoiceButton : element(by.xpath("(//*[@class='btn btn-primary'][text()='Return to Invoice'])[2]")),
    oneTouchApprovalPopupText : element(by.xpath("//*[@id='alertmodel']/span")),

     //PGS Forecast :- Forecast signoff
     forecastSignoffBtn : element(by.xpath("//*[@id='forecastSignoffButton'][text()='Forecast Signoff']")),
     forecastDigestedViewPerQuarterTxt : element(by.xpath("//*[@class='modal-content']/div[text()='Digested view per quarter (based on invoice due date)']")),
     forecastSanityCheckOnPotentialDefects : element(by.xpath("//*[@class='modal-content']/div[text()='Sanity check on potential defects. Your forecast has']")),
     forecastDigestedEntitlementTxt : element(by.xpath("//*[@class='ng-binding ng-scope'][text()='Entitlement']")),
     forecastDigestedAmountTxt : element(by.xpath("//*[@class='ng-binding ng-scope'][text()='Amount - USD']")),
     forecastDigestedEntitlementQuarter : element(by.xpath("//*[@id='forcastSignOffModal']/div/div/table[1]/tbody/tr/td")),
     forecastSignoffSanityMilestone : element(by.xpath("//*[@id='forcastSignOffModal']/div/div/table[2]/thead/tr[1]/th")),
     forecastSignoffSanityEventAt0 : element(by.xpath("//*[@id='forcastSignOffModal']/div/div/table[2]/thead/tr[3]/th")),
     forecastSignoffPopupSignOffBtn : element(by.xpath("//*[@id='forcastSignOffIdSave'][text()='Sign-Off']")),
//Audit Trail CS26024
     auditTrailBtn : element(by.xpath("//*[@id='invoideAuditDetailsBtn']")),
     auditTrailInitiallyTxt : element(by.xpath("//*[@title='Calculate Invoice']")),
     auditTrailCloseBtn : element(by.xpath("(//*[@class='btn btn-primary'][text()='Close'])[3]")),
     invoiceBackBtn : element(by.xpath("(//*[@class='btn btn-info btn-lg backCalculator'])[1]")),
     invoiceBackReasonBtn : element(by.xpath("(//*[@name='reasonListInvoice'])[4]")),
     invoiceBackReasonConfBtn : element(by.xpath("//*[@id='confirmInvoiceReason']")),
     invoiceRecalculateBtn : element(by.xpath("(//*[@id='generateCalculator'])[1]")),
     invoiceRecalculateYesBtn : element(by.xpath("(//*[@id='invCalId'][text()='Yes'])[3]")),

    },


    
    //AuditTrail

    auditTrailBtn: function () {
        var locate = this.Locators;
        browser.sleep(2000)
        util.waitForPageReadyState().then(function () { })
        return locate.auditTrailBtn.click()
     },

     auditTrailCloseBtn: function () {
        var locate = this.Locators;
        browser.sleep(2000)
        util.waitForPageReadyState().then(function () { })
        return locate.auditTrailCloseBtn.click()
     },
     invoiceBackBtn: function () {
        var locate = this.Locators;
        browser.sleep(1000)
        util.waitForPageReadyState().then(function () { })
      locate.invoiceBackBtn.click()
      browser.sleep(3000)
      locate.invoiceBackReasonBtn.click()
      browser.sleep(1000)
      return locate.invoiceBackReasonConfBtn.click()
     },
   oneTouchApproval: function () {
    var locate = this.Locators;
    browser.sleep(2000)
    util.waitForPageReadyState().then(function () { })
    locate.oneTouchApprovalButton.click()
    util.waitForPageReadyState().then(function () { })
    browser.sleep(3000)
    locate.proceedWithOneTouchApprovalButton.click()        
    return browser.sleep(6000)
 },

     invoiceRecalculateBtn: function () {
        var locate = this.Locators;
        browser.sleep(2000)
        util.waitForPageReadyState().then(function () { })
        locate.invoiceRecalculateBtn.click()
        //util.waitForPageReadyState().then(function () { })
        browser.sleep(3000)
        locate.invoiceRecalculateYesBtn.click()        
        return browser.sleep(5000)
     },
 
     auditTrailInitialRowValidation: function () {
        var locate = this.Locators;
        var invoiceTxt = "Calculate Invoice";
        browser.sleep(4000)
        util.waitForPageReadyState().then(function () { })
        //return locate.auditTrailInitiallyTxt().getText().then(function (text) {
        return element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[1]")).getText().then(function (text) {
             console.log(text)
         assert.equal(invoiceTxt, text);        
        })
    },
    auditTrailRecalculateValidation: function () {
        var locate = this.Locators;
        var invoiceTxt = "Recalculate Invoice";
        browser.sleep(4000)
        util.waitForPageReadyState().then(function () { })
        //return locate.auditTrailInitiallyTxt().getText().then(function (text) {
        return element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[1]")).getText().then(function (text) {
             console.log(text)
         assert.equal(invoiceTxt, text);        
        })
    },

    auditTrailPendingDraftInvoiceApprovalValidation: function () {
        var locate = this.Locators;
        var invoiceTxt = "Pending draft invoice approval";
        browser.sleep(2000)
        util.waitForPageReadyState().then(function () { })
        //return locate.auditTrailInitiallyTxt().getText().then(function (text) {
        return element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[1]")).getText().then(function (text) {
             console.log(text)
         assert.equal(invoiceTxt, text);        
        })
    },

    auditTrailApproveValidation: function () {
        var locate = this.Locators;
        var invoiceTxt = "Approve";
        browser.sleep(4000)
        util.waitForPageReadyState().then(function () { })
        //return locate.auditTrailInitiallyTxt().getText().then(function (text) {
        return element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[1]")).getText().then(function (text) {
             console.log(text)
         assert.equal(invoiceTxt, text);        
        })
    },
    auditTrailUnapprovedValidation: function () {
        var locate = this.Locators;
        var invoiceTxt = "Unapprove";
        browser.sleep(4000)
        util.waitForPageReadyState().then(function () { })
        //return locate.auditTrailInitiallyTxt().getText().then(function (text) {
        return element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[1]")).getText().then(function (text) {
             console.log(text)
         assert.equal(invoiceTxt, text);        
        })
    },

    auditTrailSendToAlphaYesValidation: function () {
        var locate = this.Locators;
        var invoiceTxt = "Send To Alpha";
        browser.sleep(4000)
        util.waitForPageReadyState().then(function () { })
        //return locate.auditTrailInitiallyTxt().getText().then(function (text) {
        return element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[1]")).getText().then(function (text) {
             console.log(text)
         assert.equal(invoiceTxt, text);        
        })
    },

    auditTrailOnetouchApprovalValidation: function () {
        var locate = this.Locators;
        var invoiceTxt = "One Touch Approval";
        browser.sleep(4000)
        util.waitForPageReadyState().then(function () { })
        //return locate.auditTrailInitiallyTxt().getText().then(function (text) {
        return element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[1]")).getText().then(function (text) {
             console.log(text)
         assert.equal(invoiceTxt, text);        
        })
    },
    auditTrailBilledOutValidation: function () {
        var locate = this.Locators;
        var invoiceTxt = "Billed Out";
        browser.sleep(4000)
        util.waitForPageReadyState().then(function () { })
        //return locate.auditTrailInitiallyTxt().getText().then(function (text) {
        return element(by.xpath("(//*[@class='ui-grid-cell-contents ng-binding ng-scope'])[1]")).getText().then(function (text) {
             console.log(text)
         assert.equal(invoiceTxt, text);        
        })
    },

    validationAuditTrailApproveBtn: function () {
        browser.sleep(2000)        
        element.all(by.xpath("//*[@class='ui-grid-cell-contents ng-binding ng-scope']")).getAttribute('title').then(function (columnText) {
            for (let i = 1; i <=8; i++) {

            }
            console.log(columnText)
        });
        return browser.driver.sleep(1000);
    },

    validationAuditTrailUnapproveBtn: function () {
        browser.sleep(2000)        
        element.all(by.xpath("//*[@class='ui-grid-cell-contents ng-binding ng-scope']")).getAttribute('title').then(function (columnText) {
            for (let i = 1; i <=8; i++) {

            }
            console.log(columnText)
        });
        return browser.driver.sleep(1000);
    },

    variableBilling_5_1_1_4_5_InjectionType: function () {
        var locate = this.Locators;
        locate.Variable_billings_Tab.click()
        browser.sleep(1000)
        locate.Variable_Automatic_calculationMode.click();
        locate.Variable_5_1_1_0.click()
        locate.Variable_5_1_1_1.click()
        locate.Variable_5_1_1_4.click()
        this.variableBilling_DeleteRowInjection().then(function () { })
        browser.sleep(3000)
        util.waitUntilElementDisplayed(locate.Variable_5_1_1_4_5_AddRowBtn).then(function () { })
       locate.Variable_5_1_1_4_5_AddRowBtn.click()
        locate.Variable_5_1_1_4_5_AHRateAmount.clear();
        locate.Variable_5_1_1_4_5_AHRateAmount.sendKeys("10");
        locate.Variable_5_1_1_4_5_InjectionType.click()
        return locate.Variable_5_1_1_4_5_AddFinalRowBtn.click()
    },

    sendToAlphaPopupYesButtonFunction: function () {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        locate.sendToAlphaButton.click()
        browser.sleep(1000)
        locate.sendToAlphaPopupYesButton.click()
        locate.sendToAlphaPopUpYesSSOButton.sendKeys("503114663")
        return locate.sendToAlphaSaveButton.click()
    },

    waitUntilElementDisplayed: function (elemnt) {
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.visibilityOf(elemnt), 60000);
        return browser.driver.sleep(1000);
    },

    disegistedViewQuarterTableTxt: function () {
        browser.sleep(2000)        
        element.all(by.xpath("//*[@id='forcastSignOffModal']/div/div/table[1]/tbody/tr/td")).getText().then(function (columnText) {
                    for (let i = 1; i < columnText; i++) {
                        //console.log(columnText)
                //});
            }
            console.log(columnText)
        });
        return browser.driver.sleep(1000);
    },

    sanityCheckOnPotentialDefects: function () {
        var locate = this.Locators;
        var Milestone = "Milestone";
        var Event = "Event at 0 value or empty";
        //browser.sleep(1000)
        util.waitForPageReadyState().then(function () { })
        locate.forecastSignoffSanityMilestone.getText().then(function (text) {
            assert.equal(Milestone, text);
        })
        util.waitForPageReadyState().then(function () { })
         locate.forecastSignoffSanityEventAt0.getText().then(function (text) {
            assert.equal(Event, text);
        })
        return locate.forecastSignoffPopupSignOffBtn.click() 
    },

   
    forecastSignOffwithDigestedAndSanityTxt: function () {
        var locate = this.Locators;
        var Digested = 'Digested view per quarter (based on invoice due date)';
        var Sanity = 'Sanity check on potential defects. Your forecast has';
        var Entitlement = 'Entitlement';
        var Amount = 'Amount - USD';
        //browser.sleep(1000)
        util.waitForPageReadyState().then(function () { }) 
        locate.forecastSignoffBtn.click()
        browser.sleep(1000)
        locate.forecastDigestedViewPerQuarterTxt.getText().then(function (text) {
            assert.equal(Digested, text);
        })
        locate.forecastDigestedEntitlementTxt.getText().then(function (text) {
            assert.equal(Entitlement, text);
        })
        locate.forecastDigestedAmountTxt.getText().then(function (text) {
            assert.equal(Amount, text);
        })
        browser.sleep(1000)
        util.waitForPageReadyState().then(function () { })
        return locate.forecastSanityCheckOnPotentialDefects.getText().then(function (text) {
            assert.equal(Sanity, text);
        })
    },
    
    sendToAlphaPopupNOButtonFunction: function () {
        var locate = this.Locators;
        //browser.sleep(1000)
        util.waitForPageReadyState().then(function () { })
        locate.sendToAlphaButton.click()
        browser.sleep(1000)
        locate.sendToAlphaPopupNoButton.click()
        browser.sleep(1000)
        util.waitForPageReadyState().then(function () { })
        return locate.sendToAlphaPopupNoOKButton.click()
    },
    
    oneTouchApprovalButtonFunction: function () {
        var oneTouchApprovalText = 'Important Notice:';
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        //browser.sleep(10000)
        return locate.oneTouchApprovalButton.isDisplayed().then(function (status) {
            if (status == true) {
                locate.oneTouchApprovalButton.click()
                browser.sleep(10000)
                locate.oneTouchApprovalPopupText.getText().then(function (text) {
                    assert.equal(oneTouchApprovalText, text);
                locate.oneTouchApprovalReturntoInvoiceButton.click()
                console.log("One Touch Approval Button Enabled")
            })
            } else
            console.log("One Touch Approval Button Not Enabled")
        })
        
    },

    variableBilling_DeleteRowInjection: function () {
        var locate = this.Locators;
        browser.sleep(10000)
        return locate.Variable_5_1_1_4_5_DeleteRow.isDisplayed().then(function (status) {
            if (status == true) {
        locate.Variable_5_1_1_4_5_DeleteRow.click()
        browser.sleep(10000)
        locate.Variable_5_1_1_4_5_DeleteRowConfBtn.click()
        browser.sleep(6000)
            } else
            console.log("No records found")
        })
        
    util.waitForPageReadyState().then(function () { })
    },

    provide_Esclation: function (escRate) {
        var locate = this.Locators;
        util.waitForPageReadyState().then(function () { })
        util.waitUntilElementDisplayed(locate.escalationTab).then(function () { })
        locate.escalationTab.click();
        util.waitUntilElementDisplayed(locate.Onerateforallbillings).then(function () { })
        locate.Onerateforallbillings.click();
        locate.Escalation_Rate_TextField.clear();
        locate.Escalation_Rate_TextField.sendKeys(escRate);
        locate.Fixed_billings.click()
        locate.allbillingsChkBox.click();
        locate.AsaSeparateLine_RdoBtn.click();
        return locate.Split_Fix_Var_Mile_fee_escalations_RdoBtn.click();
    },

    clickOnManualVarialeRdoBtn: function(){
        var locate = this.Locators;
        browser.sleep(1000)
        return locate.ManualVariable.click()
    },

    commit_Ts_Cs_To_Validate_Escaltion_In_Forecast: function () {
        var locate = this.Locators;
        locate.generalContctTs_Cs_Tab.click()
        locate.LeasedUnit_Yes_RdoBtn.isDisplayed().then(function (condtion) {
            //console.log("condtion: " + condtion)
            if (condtion == true) {
                util.waitUntilElementDisplayed(locate.LeasedUnit_Yes_RdoBtn).then(function () { })
                locate.LeasedUnit_Yes_RdoBtn.click()
            }
        })
        locate.Contract_level.click()
        this.handleMonetisationPopup().then(function () { })
        browser.sleep(1000)
        locate.are_Fix_Var_Billed_sameFreYesRdoBtn.click()
        locate.Quarterlyfee_FixVar.click()
        locate.Quarterly_FixVar.click()
        locate.deviation_dropdown.click()
        locate.AfterRdoBtn_FixVar.click()
        locate.Invoice_BussinessDay_FixVar.click()
        locate.InvoiceDate_FixVar.click()
        locate.invoice1stMonth_FixVar.click()
        //locate.Specified_NumberOf_days_FixVar.click()
        this.handleSpecifiedDayOfmonthCheckbox_FixVar().then(function () { })
        locate.paymentActualDay_FixVar.click()
        locate.paymentDate_FixVar.click()
        locate.payment1stMonth_Fixvar.click()
        locate.bonus_LD_NoRdo_FixVar.click()
        locate.Use_default_description.click()
        return locate.Generate_separate_invoices.click()
    },

    clickOnBackButtonInForecastDetails: function () {
        var locate = this.Locators;
        locate.BackToForecast.click()
        return util.waitForPageReadyState().then(function () { })
    },

    makeTsCsEmpty: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.no_Escalation.click()
        locate.FixedBillingTab.click()
        browser.sleep(1000)
        locate.NO_FixedBill.click()
        locate.VariableBillingTsCs.click()
        browser.sleep(1000)
        locate.No_vaiableBilling.click()
        locate.MilestoneBillingTab.click()
        browser.sleep(1000)
        return locate.NOMilestone.click()
    },

    selectNOEscalation: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        return locate.no_Escalation.click()
    },

    handleMonetisationPopup: function () {
        var locate = this.Locators;
        browser.sleep(2000)
        locate.confirmMonetiseButton.isDisplayed().then(function (conditon) {
            if (conditon == true) {
                locate.confirmMonetiseButton.click();
            }
        })
        return util.waitForPageReadyState().then(function () { })
    },

    handleSpecifiedDayOfmonthCheckbox_FixVar: function () {
        var locate = this.Locators;
        browser.sleep(10000)
        return locate.Specified_dayof_themonth_FixVar.isSelected().then(function (status) {
            if (status == true) {
                console.log("already selected")
            } else
                locate.Specified_dayof_themonth_FixVar.click()
        })
    },

    handleSpecifiedNumberOfDaysCheckbox_FixVar: function () {
        var locate = this.Locators;
        browser.sleep(10000)
        return locate.Specified_NumberOf_days_FixVar.isSelected().then(function (status) {
            if (status == true) {
                console.log("already selected")
            } else
                locate.Specified_NumberOf_days_FixVar.click()
        })
    },

    handleSpecifiedNumberOfDaysCheckbox_Fix: function () {
        var locate = this.Locators;
        browser.sleep(10000)
        return locate.Specified_NumberOf_days_Fix.isSelected().then(function (status) {
            if (status == true) {
                console.log("already selected")
            } else
                locate.Specified_NumberOf_days_Fix.click()
        })
    },

    handleSpecifiedCheckBox: function (locator) {
        var locate = this.Locators;
        browser.sleep(10000)
        return locator.isSelected().then(function (status) {
            if (status == true) {
                console.log("already selected")
            } else
                locator.click()
        })
    },

    setMonthly_monthly: function () {
        var locate = this.Locators;
        locate.generalContctTs_Cs_Tab.click()
        locate.Monthly_FixVar.click();
        return locate.MonthlyFee_FixVar.click();
    },


    fillMonthly_MonthlyInvoiceConditons_To_Check_FixORVaribaleBilling: function () {
        var locate = this.Locators;
        locate.generalContctTs_Cs_Tab.click()
        browser.sleep(1000)
        locate.Contract_level.click();
        this.handleMonetisationPopup().then(function () { });
        locate.are_Fix_Var_Billed_sameFreYesRdoBtn.click()
        locate.MonthlyFee_FixVar.click()
        locate.Monthly_FixVar.click()
        locate.AfterRdoBtn_FixVar.click()
        locate.Invoice_BussinessDay_FixVar.click()
        locate.InvoiceDate_FixVar.click()
        locate.invoicepostMonth_FixVar.click()
        this.handleSpecifiedDayOfmonthCheckbox_FixVar().then(function () { })
        this.handleSpecifiedNumberOfDaysCheckbox_FixVar().then(function () { })
        locate.paymentActualDay_FixVar.click()
        locate.paymentDate_FixVar.click()
        locate.paymentPostMonth_Fixvar.click()
        locate.NumberOfDaysDropDown.click()
        locate.earlierOf_FixVar.click()
        locate.bonus_LD_NoRdo_FixVar.click()
        locate.Use_default_description.click()
        return locate.Generate_separate_invoices.click()
    },

    fillVariableBillingTermsToCheckvariableAmount: function (variableAmount) {
        var locate = this.Locators;
        locate.VariableBillingTsCs.click()
        browser.sleep(1000)
        locate.AutoamticCalculationModeRdoBtn.click()
        locate.OpFactorAHdropdwon.click()
        locate.calculation3620YesRdoBtn.click()
        locate.decimal2.click()
        locate.oneRateAcrossEntireContractRdoBtn.click()
        locate.AHRateTextField.clear()
        locate.AHRateTextField.sendKeys(variableAmount)
        return locate.variableMonetisedNO.isDisplayed().then(function (conditon) {
            if (conditon == true) {
                locate.variableMonetisedNO.click()
            }
        })
    },

    fillFixedAmountDetails: function (amount) {
        var locate = this.Locators;
        locate.FixedBillingTab.click()
        browser.sleep(1000)
        locate.FixedBillEntireContract.click()
        locate.FixBillTextField.clear()
        locate.FixBillTextField.sendKeys(amount)
        locate.prorateFixBillNo.click()
        return locate.FixedBillSubhjectToMonetiseNo.isDisplayed().then(function (text) {
            if (text == true) {
                locate.FixedBillSubhjectToMonetiseNo.click()
            }
        })
    },

    chooseNoEscalation: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        return locate.no_Escalation.click()
    },

    fillFixedAmountOnDiffrenetDateRanges: function (period1Amount, period2Amount) {
        var locate = this.Locators;
        locate.FixedBillingTab.click()
        browser.sleep(1000)
        locate.FixedBillfor_start_endPeriods.click()
        browser.sleep(1000)
        this.addFixedAmountForselectedPeriod(period1Amount, "period1").then(function () { })
        this.addFixedAmountForselectedPeriod(period2Amount, "period2").then(function () { })
        locate.prorateFixBillNo.click()
        return locate.FixedBillSubhjectToMonetiseNo.isDisplayed().then(function (text) {
            if (text == true) {
                locate.FixedBillSubhjectToMonetiseNo.click()
            }
        })
    },

    addFixedAmountForselectedPeriod: function (amount, condtion) {
        return this.addAmountFor_selectedPeriod(amount, condtion, "fixed").then(function () { })
    },

    addVariableAmountForselectedPeriod: function (amount, condtion) {
        return this.addAmountFor_selectedPeriod(amount, condtion, "variable").then(function () { })
    },

    ChooseNofixedBilling: function () {
        var locate = this.Locators;
        locate.FixedBillingTab.click()
        browser.sleep(1000)
        return locate.NO_FixedBill.click()
    },

    fillVariableAmount_TsCs: function (variableAmount) {
        var locate = this.Locators;
        locate.VariableBillingTsCs.click()
        browser.sleep(1000)
        locate.AutoamticCalculationModeRdoBtn.click()
        locate.OpFactorAHdropdwon.click()
        locate.calculation3620YesRdoBtn.click()
        locate.decimal2.click()
        locate.oneRateAcrossEntireContractRdoBtn.click()
        locate.AHRateTextField.clear()
        locate.AHRateTextField.sendKeys(variableAmount)
        return locate.variableMonetisedNO.isDisplayed().then(function (status) {
            if (status == true)
                locate.variableMonetisedNO.click()
        })
    },

    addAmountFor_selectedPeriod: function (amount, condtion, billType) {
        var locate = this.Locators;
        if (billType == "fixed") {
            locate.fixedBillAddrowBtn.click()
            browser.sleep(1000)
            locate.fixBill_popupTextField.clear()
            browser.sleep(1000)
            locate.fixBill_popupTextField.sendKeys(amount)
        } else {
            locate.variableBillAddrowBtn.click()
            browser.sleep(1000)
            locate.varBill_popupTextField.clear()
            browser.sleep(1000)
            locate.varBill_popupTextField.sendKeys(amount)
        }
        locate.fixBill_StartdateIcon.click()
        locate.fixBill_StartdateIcon.click()
        locate.swtitchToMonhtWhenDays.click()
        locate.swtitchToMonhtWhenMonths.click()
        if (condtion == "period1") {
            locate.year2019.click()
        } else { locate.year2020.click() }
        locate.JanMonthh.click()
        locate.Day1.click()
        locate.fixBill_enddateIcon.click()
        locate.fixBill_enddateIcon.click()
        locate.swtitchToMonhtWhenDays.click()
        locate.swtitchToMonhtWhenMonths.click()
        if (condtion == "period1") {
            locate.year2019.click()
        } else { locate.year2020.click() }
        locate.DecMonthh.click()
        locate.Day31.click()
        locate.FixBill_Addbutton.click()
        return util.waitForPageReadyState().then(function () { })
    },


    fillVariableAmountOnDiffrenetDateRanges: function (period1Amount, period2Amount) {
        var locate = this.Locators;
        locate.VariableBillingTsCs.click()
        browser.sleep(1000)
        locate.diffRatesAcross_DiffDateRanngesRdoBtn.click()
        browser.sleep(1000)
        this.addVariableAmountForselectedPeriod(period1Amount, "period1").then(function () { })
        this.addVariableAmountForselectedPeriod(period2Amount, "period2").then(function () { })
        return util.waitForPageReadyState().then(function () { })

    },

    fillVariableAmountOnDiffRanges: function (period1Amount, period2Amount) {
        var locate = this.Locators;
        locate.VariableBillingTsCs.click()
        browser.sleep(1000)
        locate.diffRatesAcross_DiffRangeOfOperationsRdoBtn.click()
        browser.sleep(1000)
        locate.variableBillAddrowBtn.click()
        browser.sleep(1000)
        locate.differentRangesAHTextField.clear()
        locate.differentRangesAHTextField.sendKeys(period1Amount)
        locate.startinRangeTextField.sendKeys(0)
        locate.endRangetextfield.sendKeys(500)
        locate.FixBill_Addbutton.click()
        util.waitForPageReadyState().then(function () { })
        browser.sleep(1000)
        locate.variableBillAddrowBtn.click()
        browser.sleep(1000)
        locate.differentRangesAHTextField.clear()
        locate.differentRangesAHTextField.sendKeys(period2Amount)
        locate.startinRangeTextField.sendKeys(501)
        locate.endRangetextfield.sendKeys(800)
        locate.FixBill_Addbutton.click()
        util.waitForPageReadyState().then(function () { })
        return util.waitForPageReadyState().then(function () { })
    },

    fillVarAmount_onDiffFueltypes_OpFactorAH_MonthlyRefresh_BasedOnOpdata: function (amount1, amount2) {
        return this.fillVarAmount_onDiffFueltypes_OpFactorAH_MonthlyRefresh(amount1, amount2, "withOPData")
    },

    fillVarAmount_onDiffFueltypes_OpFactorAH_MonthlyRefresh: function (amount1, amount2, conditon) {
        var locate = this.Locators;
        locate.VariableBillingTsCs.click()
        browser.sleep(1000)
        locate.diffRatesOn_DiffFuelTypesRdoBtn.click()
        browser.sleep(1000)
        locate.operatingFactorAHRdoBtn.click()
        locate.refreshFrequencyMonthly.click()
        if (conditon == "withOPData") {
            locate.Does_rate_based_on_ops_range_YesRdoBtn.click()
        }
        else {
            locate.Does_rate_based_on_ops_range_NoRdoBtn.click()
        }
        locate.variableBillAddrowBtn.click()
        browser.sleep(1000)
        locate.selectFuelTypeAsRefineryGas.click()
        locate.AHRateAcrossDiffFuelType.clear()
        locate.AHRateAcrossDiffFuelType.sendKeys(amount1)
        if (conditon == "withOPData") {
            locate.startinRangeTextField.sendKeys(0)
            locate.endRangetextfield.sendKeys(500)
        }
        locate.FixBill_Addbutton.click()
        util.waitForPageReadyState().then(function () { })
        locate.variableBillAddrowBtn.click()
        browser.sleep(1000)
        locate.selectFuelTypeAsNaturalGas.click()
        locate.AHRateAcrossDiffFuelType.clear()
        locate.AHRateAcrossDiffFuelType.sendKeys(amount2)
        if (conditon == "withOPData") {
            locate.startinRangeTextField.sendKeys(501)
            locate.endRangetextfield.sendKeys(1000)
        }
        locate.FixBill_Addbutton.click()
        util.waitForPageReadyState().then(function () { })
        return locate.variableMonetisedNO.isDisplayed().then(function (status) {
            if (status == true)
                locate.variableMonetisedNO.click()
        })
    },

    fillVarAmount_onDiffFueltypes_OpFactorAH_MonthlyRefresh_NO_opData: function (amount1, amount2) {
        return this.fillVarAmount_onDiffFueltypes_OpFactorAH_MonthlyRefresh(amount1, amount2, "withOutOPData")
    },

    fillVariableBillingWithQuartelryFrequencyBasedOnOpData: function () {
        return this.fillVariableBillingTsCs("quarterly", "withOPData").then(function () { })
    },

    fillVariableBillingWithQuartelryFrequency_No_OpData: function () {
        return this.fillVariableBillingTsCs("quarterly", "withOutOPData").then(function () { })
    },

    fillVariableBillingWithAnuallyFrequencyBasedOnOpData: function () {
        return this.fillVariableBillingTsCs("anually", "withOPData").then(function () { })
    },

    fillVariableBillingWithAnuallyFrequency_No_OpData: function () {
        return this.fillVariableBillingTsCs("anually", "withOutOPData").then(function () { })
    },

    fillVariableBillingTsCs: function (frequencyType, condtion) {
        var locate = this.Locators;
        locate.VariableBillingTsCs.click()
        browser.sleep(1000)
        locate.diffRatesOn_DiffFuelTypesRdoBtn.click()
        browser.sleep(1000)
        locate.operatingFactorAHRdoBtn.click()
        if (frequencyType == "quarterly") {
            locate.refreshFrequencyQuarterly.click()
        } else {
            locate.refreshFrequencyAnually.click()
            browser.sleep(1000)
            locate.refreshFrequencyAnualMOnth.click()
        }
        if (condtion == "withOPData") {
            locate.Does_rate_based_on_ops_range_YesRdoBtn.click()
        }
        else {
            locate.Does_rate_based_on_ops_range_NoRdoBtn.click()
        }
        return browser.sleep(1000)
    },


    fillMilestoneTsCsOnDateBased: function (amount) {
        var locate = this.Locators;
        locate.MilestoneBillingTab.click()
        browser.sleep(1000)
        locate.NOMilestone.click()
        locate.dateBasedMile.click()
        locate.MilestoneMOnetisedNORdoBtn.click()
        browser.sleep(3000)
        locate.MilestoneAddRowBtn.click()
        browser.sleep(1000)
        locate.MilestoneAmountTextField.clear()
        locate.MilestoneAmountTextField.sendKeys(amount)
        browser.sleep(1000)
        locate.fixBill_StartdateIcon.click()
        browser.sleep(1000)
        locate.fixBill_StartdateIcon.click()
        browser.sleep(1000)
        locate.swtitchToMonht.click()
        browser.sleep(1000)
        locate.currentMonthh.click()
        browser.sleep(1000)
        locate.todayDate.click()
        browser.sleep(1000)
        locate.MilestoneDescription.clear()
        locate.MilestoneDescription.sendKeys("Milestone description added to test")
        browser.sleep(1000)
        locate.FixBill_Addbutton.click()
        return util.waitForPageReadyState().then(function () { })
    },


    fillMileStoneTsCs_onOpsBased: function (cumulativeAH, InoviceAmount) {
        var locate = this.Locators;
        locate.MilestoneBillingTab.click()
        browser.sleep(1000)
        locate.NOMilestone.click()
        locate.OpearationsBasedMile.click()
        browser.sleep(2000)
        locate.OpsBasedMileAddrowbtn.click()
        browser.sleep(1000)
        locate.equipmentId.click()
        locate.OperatingFactrAH.click()
        locate.noOfHoursTextField.clear()
        locate.noOfHoursTextField.sendKeys(cumulativeAH)
        locate.OpsbasedCurrencyTextField.clear()
        locate.OpsbasedCurrencyTextField.sendKeys(InoviceAmount)
        locate.OpsBasedMIleDescription.clear()
        locate.OpsBasedMIleDescription.sendKeys("Testing Ops Based Milestone Invoice generation")
        locate.FixBill_Addbutton.click()
        return util.waitForPageReadyState().then(function () { })

    },

    FillGeneral_TsCs_For_Quarterly_Quarterly_generateSeparateInovices: function () {
        return this.fill_generalTsCs("Quarterlyfee_FixVar", "Quarterly_FixVar", "separate", "0").then(function () { })
    },

    enterEscalationForOneRate_separateByUnit: function (escalation) {
        return this.enterEscalation(escalation, "byUnit", "separate", "").then(function () { })
    },

    fill_Fixed_Var_Milestone_terms_Conditions_basedOn_Contracttype: function (fixAmount, varAmount, mileAmount) {
        this.fillFixedAmountDetails(fixAmount).then(function () { })
        this.fillVariableAmount_TsCs(varAmount).then(function () { })
        this.fillMilestoneTsCsOnDateBased(mileAmount).then(function () { })
        return browser.sleep(1000)
    },

    fill_Fixed_Var_terms_Conditions_basedOn_Contracttype: function (fixAmount, varAmount) {
        this.fillFixedAmountDetails(fixAmount).then(function () { })
        browser.sleep(2000)
         this.fillVariableAmount_TsCs(varAmount).then(function () { })
        return browser.sleep(3000)
    },

    fill_generalTsCs: function (appFreType, invFreType, groupType, deviate) {
        var locate = this.Locators;
        locate.generalContctTs_Cs_Tab.click()
        browser.sleep(1000)
        locate.Contract_level.click();
        this.handleMonetisationPopup().then(function () { });
        locate.are_Fix_Var_Billed_sameFreYesRdoBtn.click()
        if (appFreType == "Quarterlyfee_FixVar") {
            locate.Quarterlyfee_FixVar.click()
        }
        if (appFreType == "MonthlyFee_FixVar") {
            locate.MonthlyFee_FixVar.click()
        }
        if (invFreType == "Quarterly_FixVar") {
            locate.Quarterly_FixVar.click()
        }
        if (invFreType == "Monthly_FixVar") {
            locate.Monthly_FixVar.click()
        }
        if (deviate == "0")
            if (appFreType == "Quarterlyfee_FixVar" || invFreType == "Quarterly_FixVar") {
                locate.deviation_dropdown.click()
            }
        if (deviate == "-1")
            if (appFreType == "Quarterlyfee_FixVar" || invFreType == "Quarterly_FixVar") {
                locate.deviation_dropdownOnemonth.click()
            }
        locate.AfterRdoBtn_FixVar.click()
        locate.Invoice_BussinessDay_FixVar.click()
        locate.InvoiceDate_FixVar.click()
        if (appFreType == "MonthlyFee_FixVar" && invFreType == "Monthly_FixVar") {
            locate.invoicepostMonth_FixVar.click()
        } else {
            locate.invoice1stMonth_FixVar.click()
        }

        this.handleSpecifiedDayOfmonthCheckbox_FixVar().then(function () { })
        this.handleSpecifiedNumberOfDaysCheckbox_FixVar().then(function () { })
        locate.paymentActualDay_FixVar.click()
        locate.paymentDate_FixVar.click()
        if (appFreType == "MonthlyFee_FixVar" && invFreType == "Monthly_FixVar") {
            locate.paymentPostMonth_Fixvar.click()
        } else {
            locate.payment1stMonth_Fixvar.click()
        }
        locate.NumberOfDaysDropDown.click()
        locate.earlierOf_FixVar.click()
        locate.bonus_LD_NoRdo_FixVar.click()
        locate.Use_default_description.click()
        if (groupType == "separate") {
            locate.Generate_separate_invoices.click()
        }
        if (groupType == "combine") {
            locate.Combine_as_a_single_invoice.click()
        }
        return browser.sleep(1000)
    },


    fill_GeneralTsCs_Monthly_Quarter_combineIntoOneInv: function () {
        return this.fill_generalTsCs("MonthlyFee_FixVar", "Quarterly_FixVar", "combine", "0").then(function () { })
    },
    fill_GeneralTsCs_Monthly_Quarter_combineIntoOneInvWithDeviation: function () {
        return this.fill_generalTsCs("MonthlyFee_FixVar", "Quarterly_FixVar", "combine", "-1").then(function () { })
    },

    fill_GeneralTsCs_MonthlyFee_Monthly_combineIntoOneInv: function () {
        return this.fill_generalTsCs("MonthlyFee_FixVar", "Monthly_FixVar", "combine", "0").then(function () { })
    },

    enterEscalationForOneRate_separateByFixed_Var: function (escalation) {
        return this.enterEscalation(escalation, "byFixVarMile", "separate", "").then(function () { })
    },

    enterEscalationForOneRate_CombineAllEscalationIntoSingleLine: function (escalation) {
        return this.enterEscalation(escalation, "combineEscalation", "separate", "").then(function () { })
    },

    enterEscalationForOneRate__round2: function (escalation) {
        return this.enterEscalation(escalation, "sdgs", "incude", "round2").then(function () { })
    },

    enterEscalationForOneRate__DontRound: function (escalation) {
        return this.enterEscalation(escalation, "sdgs", "incude", "noRoundDecimal").then(function () { })
    },


    enterDiffrentEScalation: function (fixEsc, varEsc, mileEsc) {
        return this.enterDiffrentEScalationOnSplitType(fixEsc, varEsc, mileEsc, "byUnit", "", "").then(function () { })
    },

    enterDiffrentEScalationOnSplitType: function (fixEsc, varEsc, mileEsc, splitType, escaDisplay, roundType) {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Different_ratesper_billingfeetypes.click()
        locate.fixBillEscaTextField.clear()
        locate.fixBillEscaTextField.sendKeys(fixEsc)
        locate.varBillEscaTextField.clear()
        locate.varBillEscaTextField.sendKeys(varEsc)
        locate.mileBillEscaTextField.clear()
        locate.mileBillEscaTextField.sendKeys(mileEsc)
        locate.AsaSeparateLine_RdoBtn.click()
        if (escaDisplay == "separate") {
            locate.AsaSeparateLine_RdoBtn.click()
        }
        if (escaDisplay == "incude") {
            locate.Include_Escalation_RdoBtn.click()
        }

        browser.sleep(1000)
        if (roundType == "round2") {
            return locate.roundDecimal2.click()
        }
        if (roundType == "noRoundDecimal") {
            return locate.dontRoundRdobtn.click()
        }
        if (splitType == "byUnit") {
            return locate.splitByUnit_RdoBtn.click()
        }
        if (splitType == "byFixVarMile") {
            return locate.Split_Fix_Var_Mile_fee_escalations_RdoBtn.click()
        }
        if (splitType == "combineEscalation") {
            return locate.Combine_all_escalation_into_oneline.click()
        }
    },

    enterDiffrentEScalationOnSplitByBillType: function (fixEsc, varEsc, mileEsc) {
        return this.enterDiffrentEScalationOnSplitType(fixEsc, varEsc, mileEsc, "byFixVarMile", "", "").then(function () { })
    },

    enterDiffrentEScalation_combineAll_EscalationIntoSingleLine: function (fixEsc, varEsc, mileEsc) {
        return this.enterDiffrentEScalationOnSplitType(fixEsc, varEsc, mileEsc, "combineEscalation", "", "").then(function () { })
    },

    enterDiffrentEScalation_RoundTwoDdecimal: function (fixEsc, varEsc, mileEsc) {
        return this.enterDiffrentEScalationOnSplitType(fixEsc, varEsc, mileEsc, "", "incude", "round2").then(function () { })
    },

    enterDiffrentEScalation_dontRoundAmountValue: function (fixEsc, varEsc, mileEsc) {
        return this.enterDiffrentEScalationOnSplitType(fixEsc, varEsc, mileEsc, "", "incude", "noRoundDecimal").then(function () { })
    },

    enterEscalation: function (escalation, splitType, escaDisplay, roundType) {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Onerateforallbillings.click()
        locate.Escalation_Rate_TextField.clear()
        browser.sleep(1000)
        locate.Escalation_Rate_TextField.sendKeys(parseFloat(escalation));
        browser.sleep(1000)
        locate.Variable_billings.click()
        locate.allbillingsChkBox.click()
        if (escaDisplay == "separate") {
            locate.AsaSeparateLine_RdoBtn.click()
        }
        if (escaDisplay == "incude") {
            locate.Include_Escalation_RdoBtn.click()
        }

        browser.sleep(1000)
        if (roundType == "round2") {
            return locate.roundDecimal2.click()
        }
        if (roundType == "noRoundDecimal") {
            return locate.dontRoundRdobtn.click()
        }
        if (splitType == "byUnit") {
            return locate.splitByUnit_RdoBtn.click()
        }
        if (splitType == "byFixVarMile") {
            return locate.Split_Fix_Var_Mile_fee_escalations_RdoBtn.click()
        }
        if (splitType == "combineEscalation") {
            return locate.Combine_all_escalation_into_oneline.click()
        }
    },

    enterDifferentEscaOnDiffPeriodsSplitByUnit: function (escalation1, escalation2) {
        var locate = this.Locators;
        this.enterDifferentEscaOnDiffPeriods(escalation1, escalation2)
        return locate.splitByUnit_RdoBtn.click()
    },

    enterDifferentEscaOnDiffPeriodsSplitByVar_Fixed: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Differentratesperperiod.click()
        browser.sleep(1000)
        return browser.sleep(1000)//locate.Split_Fix_Var_Mile_fee_escalations_RdoBtn.click()
    },

    enterDifferentEscaOnDiffPeriodsCombineEscalation: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Differentratesperperiod.click()
        browser.sleep(1000)
        return locate.Combine_all_escalation_into_oneline.click()
    },

    enterDifferentEscaOnDiffPeriodsTwoRound: function (escalation1, escalation2) {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Differentratesperperiod.click()
        browser.sleep(1000)
        this.fill_EscaltionForPeriod(escalation1, "1", "period1")
        this.fill_EscaltionForPeriod(escalation2, "2", "period2")
        locate.Include_Escalation_RdoBtn.click()
        browser.sleep(1000)
        return locate.roundDecimal2.click()
    },
    enterDifferentEscaOnDiffPeriodsDontRound: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Differentratesperperiod.click()
        browser.sleep(1000)
        locate.Include_Escalation_RdoBtn.click()
        browser.sleep(1000)
        return locate.dontRoundRdobtn.click()
    },

    enterDifferentEscaOnDiffPeriods: function (escalation1, escalation2) {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Differentratesperperiod.click()
        browser.sleep(1000)
        this.fill_EscaltionForPeriod(escalation1, "1", "add")
        this.fill_EscaltionForPeriod(escalation2, "2", "add")
        return locate.AsaSeparateLine_RdoBtn.click()
    },

    fill_EscaltionForPeriod: function (escalation, period, type) {
        var locate = this.Locators;
        locate.contractIDOnTsCs.getText().then(function (value) {
            if (type == "period1") {
                locate.escEditOneIcon.click()
                console.log("Clicked one ")
            }
            if (type == "period2") {
                locate.escEditTwoIcon.click()
                console.log("Clicked two ")
            }
            if (type == "add") {
                locate.escAddButton.click()
                console.log("Clicked add ")
            }
            browser.sleep(2000)
            locate.escOnDiffPerTextFiled.clear()
            locate.escOnDiffPerTextFiled.sendKeys(escalation)
            locate.escApplyFixBilling.click()
            var text = value.substring(0, 4)
            if (text == "AERO") {
                locate.escApplyAllBillingsAERO.click()
            } else { locate.escApplyAllBillings.click() }
        })
        if (type == "add") {
            locate.escStartDateIcon.click()
            locate.escStartDateIcon.click()
            locate.swtitchToMonhtWhenMonths.click()
            if (period == "1") {
                locate.year2019.click()
            }
            else { locate.year2020.click() }
            locate.JanMonthh.click()
            locate.escEndDateIcon.click()
            locate.swtitchToMonhtWhenMonths.click()
            if (period == "1") {
                locate.year2019.click()
            }
            else { locate.year2020.click() }
            locate.DecMonthh.click()
        }
        locate.FixBill_Addbutton.click()
        return util.waitForPageReadyState().then(function () { })
    },


    enterDiffEscaOnprojectIdOne: function (fixEsc, varEsc, mileEsc) {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Different_rates_perprojectID.click()
        browser.sleep(1000)
      this.enterDifferentEscalation(fixEsc, varEsc, mileEsc, "one").then(function () { })
        return browser.sleep(10000)
    },

    enterDiffEscaOnprojectIdTwo: function (fixEsc, varEsc, mileEsc) {
        var locate = this.Locators;
        this.enterDifferentEscalation(fixEsc, varEsc, mileEsc, "two").then(function () { })
        locate.AsaSeparateLine_RdoBtn.click()
         locate.splitByUnit_RdoBtn.click()
        return browser.sleep(10000)
    },

    enterDiffEscaOnprojectIdTwoWithSplitByFixVar: function (fixEsc, varEsc, mileEsc) {
        var locate = this.Locators;
        this.enterDifferentEscalation(fixEsc, varEsc, mileEsc, "two").then(function () { })
        locate.AsaSeparateLine_RdoBtn.click()
        return locate.Split_Fix_Var_Mile_fee_escalations_RdoBtn.click()
    },

    enterDiffEscaOnprojectIdTwoWithCombineAllEscIntoOneLine: function (fixEsc, varEsc, mileEsc) {
        var locate = this.Locators;
        this.enterDifferentEscalation(fixEsc, varEsc, mileEsc, "two").then(function () { })
        locate.AsaSeparateLine_RdoBtn.click()
        return locate.Combine_all_escalation_into_oneline.click()
    },

    enterDiffEscaOnprojectIdTwoWithCombineAllEscIntoOneLineRoundTwoDecimals: function (fixEsc, varEsc, mileEsc) {
        var locate = this.Locators;
        this.enterDifferentEscalation(fixEsc, varEsc, mileEsc, "two").then(function () { })
        locate.Include_Escalation_RdoBtn.click()
        return locate.roundDecimal2.click()
    },

    enterDiffEscaOnprojectIdTwoWithCombineAllEscIntoOneLineDontRoundDecimals: function (fixEsc, varEsc, mileEsc) {
        var locate = this.Locators;
        this.enterDifferentEscalation(fixEsc, varEsc, mileEsc, "two").then(function () { })
        locate.Include_Escalation_RdoBtn.click()
        return locate.dontRoundRdobtn.click()
    },
    enterDifferentEscalation: function (fixEsc, varEsc, mileEsc, type) {
        var locate = this.Locators;
        if (type == "one")
            locate.diffEscOnDiff_editIconOne.click()
        if (type == "two")
            locate.diffEscOnDiff_editIconTwo.click()
        browser.sleep(1000)
        locate.fixedEscalation.clear()
        locate.fixedEscalation.sendKeys(fixEsc)
        locate.variableEscalation.clear()
        locate.variableEscalation.sendKeys(varEsc)
        locate.milestoneEscalation.clear()
        locate.milestoneEscalation.sendKeys(mileEsc)
        locate.updateEscaltion.click()
        return util.waitForPageReadyState().then(function () { })
    },

    escalationPerEquipment: function (fixEsc, varEsc, mileEsc, bonus, lD) {
        var locate = this.Locators;
        locate.perUnitFixed.clear()
        locate.perUnitFixed.sendKeys(fixEsc)
        locate.perUnitVariable.clear()
        locate.perUnitVariable.sendKeys(varEsc)
        locate.perUnitMilestone.clear()
        locate.perUnitMilestone.sendKeys(mileEsc)
        locate.perUnitBonus.clear()
        locate.perUnitBonus.sendKeys(bonus)
        locate.perUnitLDs.clear()
        locate.perUnitLDs.sendKeys(lD)
        locate.updateEscaltion.click()
        return util.waitForPageReadyState().then(function () { })
    },

    escalationOnUnitOne: function (fixEsc, varEsc, mileEsc, bonus, lD) {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Differentratesperequipment.click()
        browser.sleep(1000)
        locate.escAddButton.click()
        browser.sleep(1000)
        locate.perUnitEScIDOne.click()
        return this.escalationPerEquipment(fixEsc, varEsc, mileEsc, bonus, lD)
    },

    escalationOnUnitOneEdit: function (fixEsc, varEsc, mileEsc, bonus, lD) {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Differentratesperequipment.click()
        browser.sleep(1000)
        locate.escEditOneIcon.click()
        browser.sleep(1000)
        //locate.perUnitEScIDOneEdit.click()
        return this.updateEscalation(fixEsc, varEsc, mileEsc, bonus, lD)
    },

    updateEscalation: function (fixEsc, varEsc, mileEsc, bonus, lD) {
        var locate = this.Locators;
        locate.perUnitFixed.clear()
        locate.perUnitFixed.sendKeys(fixEsc)
        locate.perUnitVariable.clear()
        locate.perUnitVariable.sendKeys(varEsc)
        locate.perUnitMilestone.clear()
        locate.perUnitMilestone.sendKeys(mileEsc)
        locate.perUnitBonus.clear()
        locate.perUnitBonus.sendKeys(bonus)
        locate.perUnitLDs.clear()
        locate.perUnitLDs.sendKeys(lD)
        locate.updateEscaltion.click()
        return util.waitForPageReadyState().then(function () { })
    },
    escalationOnUnitTwoSplitByUnit: function (fixEsc, varEsc, mileEsc, bonus, lD) {
        var locate = this.Locators;
        locate.escAddButton.click()
        browser.sleep(2000)
        locate.perUnitEScIDTwo.click()
        this.escalationPerEquipment(fixEsc, varEsc, mileEsc, bonus, lD)
        locate.AsaSeparateLine_RdoBtn.click()
        return locate.splitByUnit_RdoBtn.click()
    },
    escalationOnUnitTwoSplitFix_Var_Mile: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.AsaSeparateLine_RdoBtn.click()
        return locate.Split_Fix_Var_Mile_fee_escalations_RdoBtn.click()
    },

    escalationOnUnitTwoCombineAllEScalation: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.AsaSeparateLine_RdoBtn.click()
        return locate.Combine_all_escalation_into_oneline.click()
    },

    escalationOnUnitTwoRoundTwo: function (fixEsc, varEsc, mileEsc, bonus, lD) {
        var locate = this.Locators;
        locate.escEditTwoIcon.click()
        browser.sleep(1000)
        this.updateEscalation(fixEsc, varEsc, mileEsc, bonus, lD)
        locate.Include_Escalation_RdoBtn.click()
        return locate.roundDecimal2.click()
    },

    escalationOnUnitTwoDontRound: function () {
        var locate = this.Locators;
        locate.escalationTab.click()
        browser.sleep(1000)
        locate.Include_Escalation_RdoBtn.click()
        return locate.dontRoundRdobtn.click()

    },

    fillMilestoneTsCsOnDateBasedInBilling: function (amount) {
        var locate = this.Locators;
        locate.MilestoneBillingTab.click()
        browser.sleep(1000)
        locate.NOMilestone.click()
        locate.dateBasedMile.click()
        locate.MilestoneMOnetisedNORdoBtn.click()
        browser.sleep(3000)
        locate.MilestoneAddRowBtnp.click()
        browser.sleep(1000)
        locate.MilestoneAmountTextField.clear()
        locate.MilestoneAmountTextField.sendKeys(amount)
        locate.fixBill_StartdateIcon.click()
        locate.fixBill_StartdateIcon.click()
        locate.swtitchToMonht.click()
        locate.currentMonthh.click()
        locate.todayDate.click()
        locate.MilestoneDescription.clear()
        locate.MilestoneDescription.sendKeys("Milestone description added to test")
        locate.FixBill_Addbutton.click()
        return util.waitForPageReadyState().then(function () { })
        
    },




};// last line