
var index;
module.exports = {

    

    Locators:
    {
    pageReady : element(by.xpath("//div[@id='menuOverlayDivId'][@style='display: none;']")),

    },
    
    waitForPageReadyState: function () {
        var locate = this.Locators;
        var EC = protractor.ExpectedConditions;
        return browser.wait(EC.presenceOf(locate.pageReady), 180000);
    },

    waitUntilElementDisplayed: function (elemnt) {
        var EC = protractor.ExpectedConditions;
        browser.wait(EC.visibilityOf(elemnt), 60000);
        return browser.driver.sleep(1000);
    },

    DateIn_yyyy_mm_dd_format: function(index){
        var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var today = new Date();
                //var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                //var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
                var modyear = today.getFullYear().toString();             
                var text = modyear.substring(2)

                var date = this.todayDate() + '-' + monthNames[today.getMonth()+parseInt(index)] + '-' +  text;
                if(date == "31-Feb-20"){
                    return "29-Feb-20"
                }else {
                    return date;
                }
    },
    todayDate: function(){
        var today = new Date();
        var date = today.getDate();
        if(date == "1" || "2" || "3" || "4" || "5" || "6" || "7" || "8" || "9"){
            var formattedNumber = ("0" + date).slice(-2);
            return formattedNumber;
        }
        else{
            return date;
        }
    },

    todayDateIn_yyyy_mm_dd_format: function(){
       return this.DateIn_yyyy_mm_dd_format(0);
    },

    secondMonthDateIn_yyyy_mm_dd_format: function(){
        return this.DateIn_yyyy_mm_dd_format(1);
    },

    thirdMonthDateIn_yyyy_mm_dd_format: function(){
        return this.DateIn_yyyy_mm_dd_format(2);
    },

todayDateIn_dd_format: function(){
    var today = new Date();
    return today.getDate();
},
    
currentMonth: function(){
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var today = new Date();
    return monthNames[today.getMonth()];
},

janMonth: function(){
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var today = new Date();
    return monthNames[0];
},

thirdMonth: function(){
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var today = new Date();
    return monthNames[today.getMonth()+2];
},

aprlMonth: function(){
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var today = new Date();
    return monthNames[3];
},

currentMonthIn_dd_MMM_yy_format: function(){
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var today = new Date();
    var modyear = today.getFullYear().toString();             
    var text = modyear.substring(2)
    return today.getDate()+"-"+monthNames[today.getMonth()]+"-"+text;
},

};