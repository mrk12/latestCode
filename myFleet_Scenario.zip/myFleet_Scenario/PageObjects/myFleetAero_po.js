(function() {
    'use strict';

    var currentPage = 'myFleetPage';


    var myFleetAero = function() {

        return {
            get: function () {
                return browser.driver.get(browser.params.login.baseUrl);
                browser.waitForAngular();
            },
            setName: function (username) {
                return cem.findElement(currentPage,'username').sendKeys(username);
            },
            setPassword: function (password) {
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'password').sendKeys(password);
            },
            clickLogin: function () {
                return cem.findElement(currentPage,'password').sendKeys(protractor.Key.ENTER);
            },
            getLogin: function (url) {
                browser.driver.get(browser.params.login.baseUrl);
                return browser.driver.isElementPresent(by.xpath(browser.params.login.btn));
            },

			waitForAssetsTab: function() {
				 browser.waitForAngular();
                 browser.driver.sleep(11000);
			 return TestHelper.isElementPresent(currentPage,'assetsTab');
            },          

            assetsTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'assetsTab').click();
            },
            setName1: function (username) {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'loginUsername').sendKeys(username);
            },
            clickLogin1: function () {
                browser.driver.sleep(4000);
                return cem.findElement(currentPage,'loginUsername').sendKeys(protractor.Key.ENTER);
            },

            adjustmentTemplate: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'adjustmentTemp').click();
            }, 

            forecastSummary: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                 cem.findElement(currentPage,'forecastTable').count().then(function(count){
                     console.log("No of entries" +count);
                     for(var i=1;i<=count;i++){
                        element(by.xpath("//*[@id='forecastSummary']/tbody/tr["+i+"]/td[6])")).getText().then(function(type){
                            console.log("Type is: " +type);
                            if(type=="VARIABLE,MEMBERSHIP FEE,FIXED"||type=="FIXED"){
                                element(by.xpath("//*[@id='forecastSummary']/tbody/tr["+i+"]/td[10]")).getText().then(function(status){
                                    console.log("Status is: " +status);
                                    if(status=="Forecast"){
                                       return element(by.xpath("//*[@id='forecastSummary']/tbody/tr["+i+"]/td[11]/a")).click(); 
                                    }
                                }); 
                            }
            
                        }); 
                        console.log("loop" +i);
                        break;
                     }
                    return console.log("no required entries found");
                 });
            },  

            period: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage,'periodDate').getText().then(function(value){
                    console.log("Period is" +value);
                    backButton();
                    cem.findElement(currentPage,'forecastTable').count().then(function(count){
                        console.log("No of entries" +count);
                        for(var i=1;i<=count;i++){
                            element(by.xpath("//*[@id='forecastSummary']/tbody/tr["+i+"]/td[7]")).getText().then(function(period){
                            console.log("Obtained Period is: " +period);
                            if(period==value){
                             element(by.xpath("//*[@id='forecastSummary']/tbody/tr["+i+"]/td[10]")).getText().then(function(status){
                                console.log("changed status is: " +status);
                              return  element(by.xpath("//*[@id='forecastSummary']/tbody/tr["+i+"]/td[11]/a")).click();
                            });
                            }
                            });
                            console.log("Entered loop" +i);
                            break;
                        }
                        console.log("No Action Done");
                    });    
                });
            },

            addAdjustmentPresence: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                cem.findElement(currentPage, 'addAdj').isPresent().then(function(value){
                return console.log("Add Adjustment button is disabled" +value);
                });
            },
            
            lockForecast: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                 cem.findElement(currentPage,'lockForeButton').click();
               var txt=  cem.findElement(currentPage, 'locksuccess').getText();
               console.log(txt);
               var succtext= element(by.xpath("//*[@id='alertmodel']/p/span")).getText();
               console.log(succtext);
              return cem.findElement(currentPage, 'lockForeButtonconf').click();
            },

            unlockForecast: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
                 cem.findElement(currentPage,'unlock').isPresent().then(function(value){
                     console.log("Lock Forecast changed to Unlock Forecast" + value);
                 });
            },
            
            topMsgForLocked: function () {
                browser.waitForAngular();
                browser.driver.sleep(4000);
               return cem.findElement(currentPage,'topMsg').getText();
            },

            CheckBillingPeriodTableNonLeased: function (callback) {
                browser.waitForAngular();
                browser.driver.sleep(90000);
                console.log("In Method");
                browser.driver.sleep(3000);
                browser.waitForAngular();
                browser.driver.sleep(5000);
                element.all(by.xpath("//*[@id='invoiceBillingGrid']/div[2]/div[1]/div[2]/div/div")).count().then(function(levelOneCount){
                console.log("Total number of Elements: "+ JSON.stringify(levelOneCount));
                browser.sleep(3000);
                for (var i=1; i<=levelOneCount; i++){
                     browser.waitForAngular();
                     browser.driver.sleep(3000);
                     console.log("Entered into for loop " +i);
                     var temp="//*[@id='invoiceBillingGrid']/div[2]/div[1]/div[2]/div/div["+i+"]/div/div[3]/div";
                     try{
                        element(by.xpath(temp)).getText().then(function(value){
                        console.log("Records details: "+i+" " + value);
                           if(value=="FIXED"){
                               element(by.xpath("//*[@id='invoiceBillingGrid']/div[2]/div[1]/div[2]/div/div["+i+"]/div/div[7]/div")).getText().then(function(price2){
                               console.log("Fixed fee : "+price2);
                              });
                             }  
                            });
                        }
                        catch(err){
                            console.log("some exception occured");
                        }
                       }
                    });            
                   },
            
                   VerifyBillingCalculationDetailsNonLeased: function (callback) {
                    browser.waitForAngular();
                    browser.sleep(90000); 
                    //VerifyElementNotPresentInAero:
                    //Billing cals details
                         browser.sleep(3000);                         
                         element(by.xpath("//*[@id='invoiceDetailViewHeader']/h1")).isPresent().then(function (value) {
                         console.log("Billing header is present " +value);
                });
                    //VerifyElementNotPresentInAero: 
                   //Customer
                          browser.sleep(1000); 
                          element(by.xpath("//*[@id='calculatorSummary']/div[27]/div/section/table[2]/tbody/tr/td/table/tbody/tr[1]/td[2]")).isPresent().then(function (value) {
                          console.log(value);
                    });
                   //Contract
                           browser.sleep(1000); 
                           element(by.xpath("//*[@id='calculatorSummary']/div[27]/div/section/table[2]/tbody/tr/td/table/tbody/tr[3]/td[2]")).isPresent().then(function (value) {
                           console.log(value);
                    });
                   //Invoice date
                           browser.sleep(1000); 
                           element(by.xpath("//*[@id='userInvoiceDate']")).isPresent().then(function (value) {
                           console.log(value);
                    });
                   //Site Name
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='calculatorSummary']/div[27]/div/section/table[2]/tbody/tr/td/table/tbody/tr[2]/td[2]")).isPresent().then(function (value) {
                            console.log(value);
                    });
                  //Project id
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='calculatorSummary']/div[27]/div/section/table[2]/tbody/tr/td/table/tbody/tr[5]/td[2]")).isPresent().then(function (value) {
                            console.log(value);
                            console.log("Project ID is present");
                    });
                  //Billing
                  //PO line
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='operationBilling']")).isPresent().then(function (value) {
                            console.log(value);
                            console.log("Billing PO is present");
                });
                  //Unit
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='invoiceBillingGrid']//span[contains(text(),'UNIT SN')]")).isPresent().then(function (value) {
                            console.log(value);
                });
                  //Period
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='invoiceBillingGrid']//span[contains(text(),'PERIOD/DATE')]")).isPresent().then(function (value) {
                            console.log(value);
                });
                  //Type
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='invoiceBillingGrid']//span[contains(text(),'TYPE')]")).isPresent().then(function (value) {
                            console.log(value);
                });
                  //Description
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='invoiceBillingGrid']//span[contains(text(),'DESCRIPTION')]")).isPresent().then(function (value) {
                            console.log(value);
                });
                  //Operating Factor
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='invoiceBillingGrid']//span[contains(text(),'OPERATING FACTOR')]")).isPresent().then(function (value) {
                            console.log(value);
                });
                  //Qty
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='invoiceBillingGrid']//span[contains(text(),'QTY')]")).isPresent().then(function (value) {
                            console.log(value);
                });
                  //Unit Price
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='invoiceBillingGrid']//span[contains(text(),'UNIT PRICE')]")).isPresent().then(function (value) {
                            console.log(value);
                });
                  //Amount : 
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='invoiceBillingGrid']//span[contains(text(),'AMOUNT (USD)')]")).isPresent().then(function (value) {
                            console.log(value);
                            console.log("Billing Amount is present");
                    });
                    var present =false;
                        try {
                            cem.findElement(currentPage,'customerPO');
                            console.log("Customer PO Present");
                             present=true;
                        } catch (exp) {
                            console.log("Customer PO not Present");
                           present=false;
                        }
                
                        try {
                            cem.findElement(currentPage,'invoiceHeader');
                            console.log("invoiceHeader Present");
                             present=true;
                        } catch (exp) {
                            console.log("invoiceHeader not Present");
                           present=false;
                        }
                
                        try {
                            cem.findElement(currentPage,'invoiceFooter');
                            console.log("invoiceFooter Present");
                             present=true;
                        } catch (exp) {
                            console.log("invoiceFooter not Present");
                           present=false;
                        }
                
                        try {
                            cem.findElement(currentPage,'invoicePODate');
                            console.log("invoicePODate Present");
                             present=true;
                        } catch (exp) {
                            console.log("invoicePODate not Present");
                           present=false;
                        }
                
                        try {
                            cem.findElement(currentPage,'poLine');
                            console.log("poLine Present");
                             present=true;
                        } catch (exp) {
                            console.log("poLine not Present");
                           present=false;
                        }
                
                        assert.equal(present,false,"Not Present")
                 //Adjustment
                 //PO line
                        browser.sleep(1000); 
                        element(by.xpath("//*[@id='otherAdjustment']")).isPresent().then(function (value) {
                        console.log(value);
                        console.log("Adjustment PO is present");
                });
                 //Unit
                        browser.sleep(1000); 
                        element(by.xpath("//*[@id='otherAdjustGrid']//span[contains(text(),'UNIT SN')]")).isPresent().then(function (value) {
                        console.log(value);
                });
                 //Period
                         browser.sleep(1000); 
                         element(by.xpath("//*[@id='otherAdjustGrid']//span[contains(text(),'PERIOD/ DATE')]")).isPresent().then(function (value) {
                         console.log(value);
                });
                 //Type
                         browser.sleep(1000); 
                         element(by.xpath("//*[@id='otherAdjustGrid']//span[contains(text(),'TYPE')]")).isPresent().then(function (value) {
                         console.log(value);
                });
                 //Description
                          browser.sleep(1000); 
                          element(by.xpath("//*[@id='otherAdjustGrid']//span[contains(text(),'DESCRIPTION')]")).isPresent().then(function (value) {
                          console.log(value);
                });
                 //Operating Factor
                 //Qty
                           browser.sleep(1000); 
                           element(by.xpath("//*[@id='otherAdjustGrid']//span[contains(text(),'QTY')]")).isPresent().then(function (value) {
                           console.log(value);
                });
                 //Unit Price
                           browser.sleep(1000); 
                           element(by.xpath("//*[@id='otherAdjustGrid']//span[contains(text(),'UNIT PRICE')]")).isPresent().then(function (value) {
                           console.log(value);
                });
                 //Amount : 
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='otherAdjustGrid']//span[contains(text(),'AMOUNT')]")).isPresent().then(function (value) {
                            console.log(value);
                            console.log("Adjst amount is present");
                    });
                 //Export
                            browser.sleep(1000); 
                            element(by.xpath("//*[@id='save-print']/div/button[2]")).isPresent().then(function (value) {
                            console.log(value);
                            element(by.xpath("//*[@id='save-print']/div/button[2]")).click();
                            console.log("Export is present");
                    });
                 //Csv
                             browser.sleep(1000); 
                             element(by.xpath("//*[@id='exportInvoiceCSV']")).isPresent().then(function (value) {
                             console.log(value);
                    });
                 //Excel
                                browser.sleep(1000); 
                                element(by.xpath("//*[@id='exportInvoiceExcel']")).isPresent().then(function (value) {
                                console.log(value);
                    });
                 //Pdf
                                browser.sleep(1000); 
                                element(by.xpath("//*[@id='exportInvoiceCSV']")).isPresent().then(function (value) {
                                console.log(value);
                    });
                 //Back
                                browser.sleep(1000); 
                                element(by.xpath("//*[@id='backCalculator']")).isPresent().then(function (value) {
                                console.log(value);
                    });
                 //Recalculate
                                browser.sleep(1000); 
                                element(by.xpath("//*[@id='generateCalculator']")).isPresent().then(function (value) {
                                console.log(value);
                    });
                 //Approve
                                browser.sleep(1000); 
                                element(by.xpath("//*[@id='approveCalculator']")).isPresent().then(function (value) {
                                console.log(value);
                                console.log("Approve is present");
                    });
                //Total Billable
                                browser.sleep(1000); 
                                element(by.xpath("//*[@id='totalFixedBilling']")).isPresent().then(function (value) {
                                console.log(value);
                                console.log("Total Bill is present");
                    });
                 //Foxtrot
                                browser.sleep(3000); 
                                element(by.xpath("//*[@id='sendToFoxtrot']")).isPresent().then(function (value) {
                                console.log("Foxtrot present : "+ value);
                    });
                },

                checkBillingCalculation: function (callback) {
                   
                    cem.findElement(currentPage,'billingScheduleFromDateCalenarYr').click();
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage,'billingScheduleFromDateCalenarYrBackBtn').click();
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage,'billingScheduleFromDateCalenarMonth').click();
                    browser.driver.sleep(4000);
                    cem.findElement(currentPage,'billingScheduleFromDateCalenarDate').click();
                    browser.driver.sleep(5000);
                taskMgmtPage.billingScheduleToDateCalenarIcon();
                browser.driver.sleep(5000);
                cem.findElement(currentPage,'billingSearch').sendKeys('AERO100061'); 
                element.all(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr/td[12]")).count().then(function(count){
                console.log("Total number of Elements: "+ JSON.stringify(count));
                browser.sleep(3000);
                for (var i=1; i<=count; i++){
                    browser.waitForAngular();
                    browser.driver.sleep(3000);
                    console.log("Entered into for loop " +i);
                     element(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr["+i+"]/td[11]")).getText().then(function(value){   
                     console.log("Status is " +value); 
                     element(by.xpath("//*[@id='myInvoiceCustomerTable']/tbody/tr["+i+"]/td[12]/a")).click();
                     console.log("clicked");
                    });
                     try{ 
                     taskMgmtPage.billingScheduleCalculateOkBtn();
                     element(by.xpath("//*[@id='opsDataApprovalModal']/div/div/div[3]/a")).isPresent().then(function(value){   
                        console.log("OK button present " +value); 
                        if(value)
                      return  element(by.xpath("//*[@id='opsDataApprovalModal']/div/div/div[3]/a")).click();
                });
                     }catch( Exception){
                        return console.log("clicked on either view or review");
                     }
                     break;
                }
                callback();
                });
                },
                
            
                ValidateQuestion: function () {
                
                   return cem.findElement(currentPage,'verifyProbationApply').getText();
                },
                waitUntilElementDisplayed: function(elemnt){
                    var EC = protractor.ExpectedConditions;                    
                browser.wait(EC.visibilityOf(elemnt), 60000);
                    return browser.driver.sleep(1000);
                },

                waitForPageReadyState: function () {
                    browser.driver.sleep(2000);
                    var EC = protractor.ExpectedConditions;
                    return browser.wait(EC.presenceOf(element(by.xpath("//div[@id='menuOverlayDivId'][@style='display: none;']"))), 180000);
                },
                
             validateSeparateFixedMembershipFeeYes:function (callback) {
                browser.waitForAngular();
               this.waitForPageReadyState().then(function(){});
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log("value"+ value);
                    if(value == true || value == "true"){
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                           
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                          
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                           
                            element(by.xpath("//*[@id='135-91-RADIO']")).click();
                           
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();                          
                            browser.sleep(5000);
                            //Selecting Monthly from 2.2 section
                             element(by.xpath("//input[@type='radio'][@value='Monthly fee']")).click();
                          
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//input[@type='radio'][@value='Monthly']")).click();
                          
                            element(by.xpath("//input[@id='5-19-RADIO']")).click();
                                                 
                             element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            // browser.sleep(4000);                           
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                           
                            element(by.xpath("//input[@id='14-232-chkbox']")).isSelected().then(function(status){
                                if(status == false){
                                    element(by.xpath("//input[@id='14-232-chkbox']")).click();
                                }
                            });
                            
                             //element(by.xpath("//*[@id='16-SELECT']/option[@value='Month post billing period close']")).click();
                           
                            element(by.xpath("//*[@id='16-SELECT']/option[@value='2nd Month post billing period close']")).click();
                            
                            element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                           
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.css("input[value='Use default description']")).click();
                            element(by.css("input[value='Generate separate invoices']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                          
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                           
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                          
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='leasedUnitBillingWidget']/div[1]/h3")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='137-91-RADIO']")).click();
                           
                            element(by.xpath("//*[@id='137']/p")).getText().then(function(value){
                                console.log(value);
                            assert.equal('7.1.Does a separate Fixed Membership fee apply? – Check “yes” if not included in other fee.', value);   
                           
                            TestHelper.isElementPresent(currentPage,'leasedFixedMembershipFee71Yesbtn').then(function (flag1) {
                                assert.equal(flag1,true);
                            element(by.xpath("//*[@id='commit']")).click();                         
                            console.log("Please confirm to Commit");
                            browser.sleep(2000);
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            callback();
                                           });
                                       });
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(1000);
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='135-91-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();                          
                            browser.sleep(5000);
                            //Selecting Monthly from 2.2 section
                             element(by.xpath("//input[@type='radio'][@value='Monthly fee']")).click();
                            browser.sleep(1000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//input[@type='radio'][@value='Monthly']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//input[@id='5-19-RADIO']")).click();
                            browser.sleep(1000);                            
                             element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                                                  
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='2nd Month post billing period close']")).click();
                            browser.sleep(2000);    
                            element(by.xpath("//input[@id='14-232-chkbox']")).isSelected().then(function(status){
                                if(status == false){
                                    element(by.xpath("//input[@id='14-232-chkbox']")).click();
                                }
                            });
                           // element(by.xpath("//input[@id='14-232-chkbox']")).click();
                             //element(by.xpath("//*[@id='16-SELECT']/option[@value='Month post billing period close']")).click();
                           
                            element(by.xpath("//*[@id='16-SELECT']/option[@value='2nd Month post billing period close']")).click();
                          
                            element(by.xpath("//*[@id='15-SELECT']/option[@value='5th']")).click();
                          
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            
                            element(by.css("input[value='Use default description']")).click();
                            element(by.css("input[value='Generate separate invoices']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                           
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                          
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                         
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='leasedUnitBillingWidget']/div[1]/h3")).click();
                            browser.sleep(1000);
                            element(by.xpath("//*[@id='137-91-RADIO']")).click();
                          
                            element(by.xpath("//*[@id='137']/p")).getText().then(function(value){
                                
                            assert.equal('7.1.Does a separate Fixed Membership fee apply? – Check “yes” if not included in other fee.', value);   
                          
                            TestHelper.isElementPresent(currentPage,'leasedFixedMembershipFee71Yesbtn').then(function (flag1) {
                                assert.equal(flag1,true);
                            element(by.xpath("//*[@id='commit']")).click();
                        console.log("Please confirm to Commit");
                        browser.sleep(2000);
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {                       
                        callback();
                                    });
                                });
                            });
                        });
                    }
                });
            },

            validateOptionsChangedAccordingtoOptionsSelected:function (callback) {
                browser.waitForAngular();
                browser.sleep(12000);
                element(by.xpath("//*[@id='commit']")).getAttribute('disabled').then(function(value){
                    console.log(value);
                    if(value == true || value == "true"){
                        browser.sleep(5000); 
                        element(by.xpath("//*[@id='createnewversion']")).isPresent();
                        //console.log("test123");
                        element(by.xpath("//*[@id='createnewversion']")).click().then(function () {
                            browser.sleep(5000);
                            element(by.xpath("//*[@id='createVersionDesc']")).sendKeys('Test');                            
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='confirmid1']")).click().then(function () {
                            browser.sleep(10000);
                            element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='135-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(2000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(4000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(4000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(4000);                            
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='20-92-RADIO']")).click();
                            browser.sleep(4000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='leasedUnitBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='137-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='137']/p")).getText().then(function(value){
                                console.log(value);
                            assert.equal('7.1.Does a separate Fixed Membership fee apply? – Check “yes” if not included in other fee.', value);   
                            browser.sleep(3000);
                            TestHelper.isElementPresent(currentPage,'leasedFixedMembershipFee71Yesbtn').then(function (flag1) {
                            assert.equal(flag1,true);
                            element(by.xpath("//*[@id='139-SELECT']/option[text()='Included with reoccurring invoice and show as separate line item']")).click();
                            browser.sleep(2000);
                            element(by.xpath("//*[@id='139-SELECT']/option[text()='Create a separate invoice for membership fee']")).click();
                            browser.sleep(2000);
                            element(by.xpath("//*[@id='138-428-RADIO']")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='158-SELECT']/option")).getText().then(function (value) {
                            console.log("Annually as a separate invoice- Monthly data" + value);     
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='138-455-RADIO']")).click();
                            browser.sleep(3000);
                            element(by.xpath("//*[@id='158-SELECT']/option")).getText().then(function (value) {
                            console.log("Annually as a separate invoice- Monthly data" + value);     
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(4000);
                            console.log("Please confirm to Commit");
                            element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                            browser.sleep(9000);
                            callback(); 
                                                    });
                                                });
                                            });
                                       });
                                    });
                                });
                            });
                         });
                    }else{
                        browser.sleep(5000);
                        element(by.xpath("//*[@id='commit']")).isPresent();
                        element(by.xpath("//*[@id='generalContractWidget']/div[1]/h3")).click().then(function () {
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='135-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).click();
                            browser.sleep(2000);
                            element(by.xpath("//*[@id='1-1-RADIO']")).isSelected();
                            browser.sleep(4000);
                            //Selecting Monthly from 2.2 section
                            element(by.xpath("//*[@id='2-4-RADIO']")).click();
                            browser.sleep(4000);
                            //Selecting Monthly from 2.3 section
                            element(by.xpath("//*[@id='3-8-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='5-19-RADIO']")).click();
                            browser.sleep(4000);                            
                            element(by.xpath("//*[@id='13-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='16-SELECT']/option[text()='Month post billing period close']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='19-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='20-92-RADIO']")).click();
                            browser.sleep(4000);
                            /*element(by.xpath("//*[@id='102-1-chkbox']")).getAttribute('checked').then(function(value){
                                console.log(value);
                                    if(value==true ){
                                    browser.sleep(4000);
                                    element(by.xpath("//*[@id='102-1-chkbox']")).click();
                                    }else{
                                        console.log("Not associated with Other Contract");
                                    }                                                        
                            browser.sleep(4000);*/
                            element(by.xpath("//*[@id='fixedBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='26-104-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.chord(protractor.Key.CONTROL, 'a'));
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys(protractor.Key.DELETE);
                            browser.sleep(4000);
                            element(by.xpath("(//*[@name='27-Currency'])[1]")).sendKeys('400');
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='99-92-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='variableBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='33-129-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='milestoneBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='84-188-chkbox']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='leasedUnitBillingWidget']/div[1]/h3")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='137-91-RADIO']")).click();
                            browser.sleep(4000);
                            element(by.xpath("//*[@id='137']/p")).getText().then(function(value){
                                console.log(value);
                            assert.equal('7.1.Does a separate Fixed Membership fee apply? – Check “yes” if not included in other fee.', value);   
                            browser.sleep(3000);
                            TestHelper.isElementPresent(currentPage,'leasedFixedMembershipFee71Yesbtn').then(function (flag1) {
                            assert.equal(flag1,true);
                            element(by.xpath("//*[@id='139-SELECT']/option[text()='Included with reoccurring invoice and show as separate line item']")).click();
                                browser.sleep(2000);
                                element(by.xpath("//*[@id='139-SELECT']/option[text()='Create a separate invoice for membership fee']")).click();
                                browser.sleep(2000);
                                element(by.xpath("//*[@id='138-428-RADIO']")).click();
                                browser.sleep(3000);
                                element.all(by.xpath("//*[@id='158-SELECT']/option")).getText().then(function (value) {
                                console.log("Annually as a separate invoice- Monthly data" + value);     
                                browser.sleep(3000);
                                element(by.xpath("//*[@id='138-455-RADIO']")).click();
                                browser.sleep(3000);
                                element.all(by.xpath("//*[@id='158-SELECT']/option")).getText().then(function (value) {
                                console.log("Annually as a separate invoice- Monthly data" + value);
                            element(by.xpath("//*[@id='commit']")).click();
                            browser.sleep(4000);
                        console.log("Please confirm to Commit");
                        element(by.xpath("//*[@id='confirmid3']")).click().then(function () {
                        browser.sleep(9000);
                        callback();
                    });
                                      });
                                   });
                                });
                            });
                        });
                    }
                });
            },



  
        };

	};

    module.exports = new myFleetAero();

}());