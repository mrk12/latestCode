

module.exports= {

    Locator:{
        billingSearchField: element(by.xpath("")),
    },

sample: function(){

    var locate = this.Locator;

    locate.billingSearchField.click();


}






}