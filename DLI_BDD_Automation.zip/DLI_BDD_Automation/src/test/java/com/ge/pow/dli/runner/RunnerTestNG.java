package com.ge.pow.dli.runner;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="src\\test\\resources\\Features\\PlanningScopeAvailability.feature",glue={"com.ge.pow.dli.steps", "src/test/resources/Features"},
plugin = { "pretty", "json:target/cucumber-reports/Cucumber.json",
		 "junit:target/cucumber-reports/Cucumber.xml",
		 "html:target/cucumber-reports", "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"},
dryRun = false,
monochrome = true)	

@Test
public class RunnerTestNG extends AbstractTestNGCucumberTests{

}