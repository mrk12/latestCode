package com.ge.pow.dli.objrepo;

import org.openqa.selenium.By;

public interface PlanningScopeAvailabilityKpiProperties {
	
	By scopeTechnicalRisk =By.xpath("//span[contains(text(),'Scope & Technical Risk')]/../../../div/button");
	By scopeAvailability=By.xpath("//span[contains(text(),'Scope Availability')] "); 
	By scopeExport=By.xpath("//span[contains(text(),'Export')]");	
	By expandFirstOutage = By.xpath("(//button[@title='View line items for this outage'])[1]");
	By linestatus = By.xpath("//p/../table/tbody/tr/td[2]/button/span[1]");
	By viewOutagebutton = By.xpath("(//*[@title='View Outage'])[1]");
	By ODpageheader = By.xpath("//h3[text()='Outage Details']");
}
