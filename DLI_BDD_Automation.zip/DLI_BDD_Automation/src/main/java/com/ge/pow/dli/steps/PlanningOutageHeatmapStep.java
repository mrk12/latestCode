package com.ge.pow.dli.steps;

import java.io.IOException;
import java.sql.SQLException;

import com.ge.pow.dli.pages.PlanningOutageHeatmapPage;
import com.ge.pow.dli.util.TestBase;
import com.ge.pow.dli.util.DbConnection;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PlanningOutageHeatmapStep{
		
	@Then("^User is able to verify the outage heatmap$")
	public void verifyHeatmap() throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.heatmap();	
	}
	
	@When("^I click on export button$")
	public void export() throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.exportfunctionality();				
	}
	
	@When("^I able to setup dbconnection$")
	public void dbconnection() throws InterruptedException, ClassNotFoundException, IOException, SQLException {
		DbConnection.connection();				
	}
	
	@Then("^I can get total number of outages from backend$")
	public void executequery() throws InterruptedException, IOException, SQLException {
		DbConnection.executequery();
	}
	
	@Then("^I can get number of outages from front end$")
	public void count() throws InterruptedException, IOException, SQLException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.outagecountfromUI();
	}
	
	@Then("^I can validate the number from both sides$")
	public void compare() throws InterruptedException, IOException, SQLException {
		DbConnection.compare_outages();
	}
	
	@Then("^I am able to check the region selected and change it if needed (.*)$")
	public void checkRegion(String region) throws InterruptedException, IOException, SQLException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.checkingRegion(region);
	}
	
	
	@When("^I click on ShortCycled checkbox$")
	public void shortcycledexport() throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.shortcyclecheckbox();				
	}
	
	@Then("^I can able to reset filter$")
	public void reset() throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.resetButton();			
	}
	
	@When("^I click on High risk for critical KPI checkbox$")
	public void CriticalKPIexport() throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.criticalKPIcheckbox();				
	}
	
	@Then("^I can validate excel is downloaded or not$")
	public void ValidateExcel() throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.getLatestFilefromDir();				
	}
	
	@Then("^I can validate column names from modal window$")
	public void Validatecolumns() throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.modalColumnNames();				
	}
	
	@Then("^I can get number of rows of subregion from downloaded excel$")
	public void Excelrows() throws InterruptedException, IOException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.getting_rows_fromExcel();				
	}

	@When("^I click on all \"([^\"]*)\" outage cells I can see score% is between (\\d+) to (\\d+)$")
	public void clickoutagecellandverifypopup(String risk, int lowlimit, int highlimit) throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.clickoutagecell_navigateModalWindow(risk,lowlimit,highlimit);			
	}
	
	@When("^I click on \"([^\"]*)\" filter$")
	public void riskbutton(String risk) throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.riskbutton(risk);			
	}

	@When("^I click on all \"([^\"]*)\" outage cells and vaildate score from outage details page$")
	public void clickoutagecell_navigateoutagedetails(String risk) throws InterruptedException {
		TestBase.outageheatmap();
		PlanningOutageHeatmapPage.clickoutagecell_navigateoutagedetails(risk);			
	}
	
	@Then("^User is able to close the browser$")
	public void close() throws InterruptedException {
		TestBase.closebrowser();				
	}
}
