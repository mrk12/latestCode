package com.ge.pow.dli.pages;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.ge.pow.dli.objrepo.PlanningScopeAvailabilityKpiProperties;
import com.ge.pow.dli.util.WebDriverUtils;

public class PlanningScopeAvailabilityKpiPage extends WebDriverUtils implements PlanningScopeAvailabilityKpiProperties{

	static WebDriver driver; // Instance

	public PlanningScopeAvailabilityKpiPage(WebDriver driver) {
		super(driver);
		PlanningScopeAvailabilityKpiPage.driver = driver;
	}
	
	public static void scopeTechincalRisk() {
		if(isElementPresent(scopeTechnicalRisk)){
		click(scopeTechnicalRisk);
		Reporter.addStepLog("scope and technical risk kpi is expanded");	
		}
	}
	
	public static void expandOutage() {
		if(isElementPresent(expandFirstOutage)){
		click(expandFirstOutage);
		Reporter.addStepLog("first outage is expanded");	
		}
	}
	
	public static void clickViewOutage() {
		isElementPresent(viewOutagebutton);
		click(viewOutagebutton);
		if(isElementPresent(ODpageheader)){
		Reporter.addStepLog("outage details page is displayed");	
		}
	}
	
	public static String lineStatusSD() {
		String statusSD ="";
		if(isElementPresent(linestatus)){
		statusSD = getText(linestatus);
		//Reporter.addStepLog("Status of line item " +statusSD);
		}
		return statusSD;
	}
	
	public static void lineStatusOD() {		
		String statusSD = lineStatusSD();
		String statusOD = getText(linestatus);
		if(statusSD.equals(statusOD)) {
		Reporter.addStepLog("Status of line item " +statusOD);	
		}
		else{
			Assert.fail();
		}
	}

	public static void scopeAvailablity() {
		if(isElementPresent(scopeAvailability)){
		click(scopeAvailability);
		checkPageIsReady();
		Reporter.addStepLog("scope availability service director view displayed");	
		}
	}
	
	public static void validateHeadings(String header) {
		WebElement heading = driver.findElement(By.xpath("//span/b[contains(text(),'"+header+"')]"));
		if(heading.isDisplayed()){
		Reporter.addStepLog(header +" is present");	
		}
	}
	
	
	public static void exportLineItems() {
		if(isElementPresent(scopeExport)){
			staticWait(2);
			clickUsingJavaScript(scopeExport);
		  	staticWait(10);
		}
		}

	
	@SuppressWarnings("resource")
	public static void validateLogicFromExcel() throws IOException {
		Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
		String filename = PlanningOutageHeatmapPage.getLatestFilefromDir();
		String FilePath = path + "\\" + filename;
		FileInputStream fs = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fs);
	    XSSFSheet sheet = workbook.getSheetAt(0);
		int totalNoOfRows = sheet.getLastRowNum();
		Reporter.addStepLog("total outages "+totalNoOfRows);	
		for(int i=5;i<=totalNoOfRows;i++) {
			double outageID = sheet.getRow(i).getCell(7).getNumericCellValue();
			String riskValue= sheet.getRow(i).getCell(4).getStringCellValue();
			String ActivityStatus = sheet.getRow(i).getCell(15).getStringCellValue();
			if(ActivityStatus.equals("Not Available") || ActivityStatus.equals("Not Applicable")
					|| ActivityStatus.equals("Completed") || ActivityStatus.equals("Completed Late")) {
				riskValue.equals("Low/No Risk");
				Reporter.addStepLog("Outage " +outageID+ " "+riskValue);
			}
			else if(ActivityStatus.equals("Overdue")) {
				riskValue.equals("High Risk");
				Reporter.addStepLog("Outage " +outageID+ " "+riskValue);
			}
			else if(ActivityStatus.equals("Not Due")) {
				riskValue.equals("Not Due");
				Reporter.addStepLog("Outage " +outageID+ " "+riskValue);
			}
			else {
				Reporter.addStepLog("failed");
				
			}
		}
	}
}
	