package com.ge.pow.dli.objrepo;

import org.openqa.selenium.By;

public interface LoginPageProperties {
	
	By SIGNIN_USERNAME=By.name("username");
	By SIGNIN_PASSWORD=By.name("password"); 
	By SIGNIN_SUBMITBUTTON=By.name("submitFrm");	
	
}
