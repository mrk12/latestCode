package com.ge.pow.dli.util;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.Calendar;
import java.util.Date;

public class GetQueries {

	 static String FilePath = System.getProperty("user.dir") + "/src/test/resources/Queries_sheet/query.xlsx";
	 static FileInputStream fi = null;
public static String[] getcredentials() throws IOException {
		 fi = new FileInputStream(FilePath);
		 XSSFWorkbook WB =  new XSSFWorkbook(fi);
	     XSSFSheet Sheet= WB.getSheet("credentials");
	     String user = Sheet.getRow(1).getCell(0).getStringCellValue();
	     String pswd = Sheet.getRow(1).getCell(1).getStringCellValue();
	     return new String[] {user,pswd};
}

public static String[] Query() throws IOException {
		fi = new FileInputStream(FilePath);
		 XSSFWorkbook WB =  new XSSFWorkbook(fi);
	     XSSFSheet Sheet= WB.getSheet("Queries");
	     String Region = Sheet.getRow(1).getCell(0).getStringCellValue();
	     String query = Sheet.getRow(1).getCell(1).getStringCellValue();
	     return new String[] {Region,query};
}

public static Date getCurrentDate() {
	Date date = new Date();
	return date;
}

public static Date futureDate() {
	Calendar c = Calendar.getInstance();
	c.add(Calendar.DATE, 1096);
	Date currentDatePlusOne = c.getTime();
	return currentDatePlusOne;
	}
}
