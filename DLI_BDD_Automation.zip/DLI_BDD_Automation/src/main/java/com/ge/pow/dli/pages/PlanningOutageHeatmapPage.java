package com.ge.pow.dli.pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.cucumber.listener.Reporter;
import com.ge.pow.dli.objrepo.PlanningOutageHeatmapProperties;
import com.ge.pow.dli.util.WebDriverUtils;
import com.google.common.base.Verify;

public class PlanningOutageHeatmapPage extends WebDriverUtils implements PlanningOutageHeatmapProperties{

	static WebDriver driver; // Instance

	public PlanningOutageHeatmapPage(WebDriver driver) {
		super(driver);
		PlanningOutageHeatmapPage.driver = driver;
	}

	public static void heatmap() {
		isElementPresent(heatmapcontainer);
		Reporter.addStepLog("Outage heatmap is present with month period");		
	}	

	public static void checkingRegion(String region) {
		String reg = driver.findElement(selectedRegion).getAttribute("value");
		if(!reg.equals(region)) {
			enterText(regionFilter,region);
			Actions action = new Actions(driver); 
			action.sendKeys(Keys.ENTER).build().perform();
			click(region_yes);
			checkPageIsReady();
			staticWait(5);
			Reporter.addStepLog("region is changed accordingly");
		}
		Reporter.addStepLog("region is selected");		
	}
	
	public static int outagecountfromUI() {
		isElementPresent(totaloutages_heatmap);
		String[] Outages = getText(totaloutages_heatmap).split(":");
		String count = Outages[1].trim();
		int uicount = Integer.parseInt(count);
		Reporter.addStepLog("outages " +uicount);
		return uicount;
	}	
	
	public static void riskbutton(String risk) {
		if(isElementPresent(totaloutages_heatmap)){
		WebElement riskbutton = driver.findElement(By.xpath("//button[@title='"+risk+"']"));
		riskbutton.click();
		Reporter.addStepLog("risk button is clicked");	
		}
	}
	
	public static void resetButton() {
		if(isElementPresent(reset_button)){
		click(reset_button);
		Reporter.addStepLog("reset button is clicked");	
		}
	}
	
	public static void modalColumnNames(){
		for(int j=2;j<=19;j++) {			
			  WebElement outagecell = driver.findElement(By.xpath("(//table/tbody/tr[1]/td["+j+"]/button)[1]"));
			  if(outagecell.isEnabled()) {					  	
				  	outagecell.click();
				  	verifyoutagepopup();
				  	break;
			  }
		}
		  ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
		  list.add("Actions / Comments");    
		  list.add("Risk Status");    
		  list.add("Score");    
		  list.add("FSP Outage ID");  
		  list.add("Customer");
		  list.add("Site");
		  list.add("Outage Type");
		  list.add("Outage Probability");
		  list.add("IBAT Contract Type");
		  list.add("Planned Start date");
		  list.add("Planned End date");
		  list.add("Event Owner(CPM/CSL)");
		  list.add("Service Director");
		  list.add("Event Description");
		  list.add("Equipment Serial Number(ESN)");
		  list.add("Equipment ID");
		  list.add("FSP Event ID");
		  list.add("FSP Project ID");
		  list.add("OFS Outage # / SFDC UE / Ferman #");
		  list.add("ERP #");
		  list.add("Business");
		  list.add("OTR Involvement");
		  list.add("FC Service Manager");
		  list.add("Outage Creation Date");
		  list.add("Sub Region");
		  list.add("Country");
		  int successcount = 0;
		  for(int i=1;i<list.size();i++)  {
			  String columnName = driver.findElement(By.xpath("(//div[@role='document']//table/thead/tr[1]/th/div/div/div/span/span)["+i+"]")).getText().trim();
			  String columnList = list.get(i-1);
			  if(columnList.equalsIgnoreCase(columnName)){
				  successcount++;
			  }
			  if(successcount==list.size()){
				  Reporter.addStepLog("all column names are validated");
			  }
		  }	 
		  closepopup();
	}
	
	public static void clickoutagecell_navigateModalWindow(String risk, int lowlimit, int highlimit) {
		List<WebElement> sregion = driver.findElements(subregion_rows);
		int numberOfSubregion= sregion.size();
		for(int i=1;i<=numberOfSubregion;i++) {
			WebElement region = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[1]/div/div[2]/p/span[2]"));
			String subregion = region.getAttribute("title");
			Reporter.addStepLog(subregion);
			  for(int j=2;j<=26;j++) {			
				  WebElement outagecell = driver.findElement(By.xpath("(//table/tbody/tr["+i+"]/td["+j+"]/button)[1]"));
				  if(outagecell.isEnabled()) {					  	
					  	outagecell.click();
					  	verifyoutagepopup();
					  	outagescorefromModalwindow(risk,lowlimit,highlimit);
					  	closepopup();
				  }	
					if(j==19) {
						if(isEnabled(forwardarrow)) {
							  click(forwardarrow);
								j=7;
						}
					}				  			 			  
				  	if(j==26) {
				  		backarrow();					
					  }
			  }
		}
	}

	public static void outagescorefromModalwindow(String risk,int lowlimit,int highlimit) {
		 int outage_number = driver.findElements(modalwindow).size();
		 for(int k=1;k<=outage_number;k++) {
			  String outagescore[] = driver.findElement(By.xpath("//div[@role='document']//table/tbody/tr["+k+"]/td[3]/p")).getText().split("%");					  
			  int score = Integer.parseInt(outagescore[0]);
			  String outageid = driver.findElement(By.xpath("//div[@role='document']//table/tbody/tr["+k+"]/td[4]")).getText();
			  if(risk.equalsIgnoreCase("Filter by High")) 							  
				  if(score>=lowlimit && score<highlimit) {
					  Reporter.addStepLog("Outage id " +outageid+ " score is " +score+"");
				  }
				  else {
					  Reporter.addStepLog("Outage id " +outageid+ " is showing error");
					  Verify.verify(true, "Outage id " +outageid);
				  }
			  else if(risk.equalsIgnoreCase("Filter by Medium")) 
				  if(score>=lowlimit && score<highlimit) {
					  Reporter.addStepLog("Outage id " +outageid+ " score is " +score+"");
				  }
				  else {
					  Reporter.addStepLog("Outage id " +outageid+ " is showing error");
					  Verify.verify(true, "Outage id " +outageid);
				  }
			  else if(risk.equalsIgnoreCase("Filter by Low/No")) 
				  if(score>=lowlimit && score<=highlimit) {
					  Reporter.addStepLog("Outage id " +outageid+ " score is " +score+"");
				  }
				  else {
					  Reporter.addStepLog("Outage id " +outageid+ " is showing error");
					  Verify.verify(true, "Outage id " +outageid);
				  }
			  }		 	
			isElementPresent(nextpagearrow);
		  	if(isEnabled(nextpagearrow)) {
				  click(nextpagearrow);
				  outagescorefromModalwindow(risk,lowlimit,highlimit);
		  	}
	}
	
	public static void clickoutagecell_navigateoutagedetails(String risk) {		
		for(int i=1;i<=3;i++) {
			WebElement region = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td[1]/div/div[2]/p/span[2]"));
			String subregion = region.getAttribute("title");
			Reporter.addStepLog(subregion);
			  for(int j=2;j<=26;j++) {			
				  WebElement outagecell = driver.findElement(By.xpath("(//table/tbody/tr["+i+"]/td["+j+"]/button)[1]"));
				  if(outagecell.isEnabled()) {
					  	outagecell.click();
					  	verifyoutagepopup();
					  	outagescore_Outagedetailspage(risk);
				  }	
					if(j==19) {
						if(isEnabled(forwardarrow)) {
							  click(forwardarrow);
								j=7;
						}
					}				  			 			  
				  	if(j==26) {
				  		backarrow();					
					  }
			  }
		}
	}

	public static void outagescore_Outagedetailspage(String risk) {
		 int outage_number = driver.findElements(modalwindow).size();
		 for(int k=1;k<=outage_number;k++) {
			  String outagescore_from_modalwindow = driver.findElement(By.xpath("//div[@role='document']//table/tbody/tr["+k+"]/td[3]/p")).getText();					  
			  String outageid = driver.findElement(By.xpath("//div[@role='document']//table/tbody/tr["+k+"]/td[4]")).getText();
			  driver.findElement(By.xpath("//div[@role='document']//table/tbody/tr["+k+"]/td[4]")).click();
			  String outagedetails_score =score_From_outagedetails();
			  
			  if(risk.equalsIgnoreCase("Filter by High")) 							  
				  if(outagescore_from_modalwindow.equals(outagedetails_score)) {
					  Reporter.addStepLog("for Outage id " +outageid+ " both score in modal window and outage details page is equal");					  
				  }
				  else {
					  Reporter.addStepLog("Outage id " +outageid+ " is not match with outage details");
				  }
			 
			  }
		 	staticWait(2);
			isElementPresent(nextpagearrow);
		  	if(isEnabled(nextpagearrow)) {
				  click(nextpagearrow);
				  staticWait(2);
				  outagescore_Outagedetailspage(risk);
		  	}
		  	backbutton_inglobalfilter();
			staticWait(3);
	}
	
	public static void verifyoutagepopup() {
				isElementPresent(modalwindow);								
				}
						 
	public static void closepopup() {
		isElementPresent(popup_close);
	  	click(popup_close);								
		}
	
	public static void backarrow() {
		if(isEnabled(backarrow))
			  click(backarrow);								
		}

	

	public static void backbutton_inglobalfilter() {
		if(isElementPresent(back_button))
			  click(back_button);								
		}
	
	public static String score_From_outagedetails() {
		String score_outagedetailspage="";
		if(isElementPresent(score_from_outagedetails)) {
			score_outagedetailspage=getlabelText(score_from_outagedetails);		
		}
		return score_outagedetailspage;
	}
		
	public static void exportfunctionality() {
		isElementPresent(heatmapExport);
	  	click(heatmapExport);
	  	staticWait(10);
		}

	public static void shortcyclecheckbox() {
		if(isElementPresent(heatmapExport)) {
		clickUsingJavaScript(shortCycle_checkbox);
	  	staticWait(3);		
		}
	}
	
	public static void criticalKPIcheckbox() {
		if(isElementPresent(heatmapExport)) {
		clickUsingJavaScript(criticalkpi_checkbox);
	  	staticWait(3);
		}
		}
	
	public static String getLatestFilefromDir(){
		String fileName = "";
		Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
		String dirPath= path.toString();
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	        return null;
	    }
	
	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	           fileName = lastModifiedFile.getName();
	   			Reporter.addStepLog("Downloaded file is " +fileName+ "");
	       }
	    }
		return fileName;
	  
	}
	
	@SuppressWarnings("resource")
	public static void getting_rows_fromExcel() throws IOException {
		Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
		String filename = getLatestFilefromDir();
		String FilePath = path + "\\" + filename;
		FileInputStream fs = new FileInputStream(FilePath);
		XSSFWorkbook workbook = new XSSFWorkbook(fs);
		int sheets = workbook.getNumberOfSheets();
		for(int i=0;i<sheets;i++) {
		String sheetname = workbook.getSheetName(i);
	    XSSFSheet sheet = workbook.getSheetAt(i);
		int totalNoOfRows = sheet.getLastRowNum()-4;
		 Reporter.addStepLog("subregion "+sheetname+" has total rows "+totalNoOfRows);
		}
	}
}
	