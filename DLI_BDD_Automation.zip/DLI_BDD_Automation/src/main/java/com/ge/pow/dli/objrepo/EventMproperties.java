package com.ge.pow.dli.objrepo;

import org.openqa.selenium.By;

public interface EventMproperties {
	
	By OFS_PGS = By.xpath("//div/h4[contains(text(),'OFS (PGS)')]/../../div[2]/h2");
	By fsp_eventNotAccepted = By.xpath("//div/h4[contains(text(),'FSP')]/../../div[2]/h2");
	By fsp_pastDue= By.xpath("((//span[contains(text(),'Outages Missing')][1]/../../h2)[1]");
	By fsp_missingEndDate = By.xpath("(//span[contains(text(),'Outages Missing')][1]/../../h2)[2]");
	By outagesMissingERP = By.xpath("//span[contains(text(),'Outages missing')][1]/../../h2");
	By outagesInactive = By.xpath("//div/h4[contains(text(),'FV')]/../../div[2]/h2");
	By eventMContainer = By.id("event-management-defects-container");
}
