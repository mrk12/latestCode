package com.ge.pow.dli.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.cucumber.listener.Reporter;
import com.ge.pow.dli.objrepo.EventMproperties;
import com.ge.pow.dli.util.WebDriverUtils;

public class EventMPage extends WebDriverUtils implements EventMproperties {

static WebDriver driver; // Instance

 public EventMPage(WebDriver driver) {
	 super(driver);
	 EventMPage.driver = driver;
}

 public static void allEvent(String strArg1) {
	 By loc = By.xpath(strArg1);
	 isElementPresent(loc);

	  Reporter.addStepLog("OFS Events is available");

	 }
 
 public static void eventM() {
	 isElementPresent(eventMContainer);
	 Reporter.addStepLog("Event Management is present with all 6 sections"); 
}

}