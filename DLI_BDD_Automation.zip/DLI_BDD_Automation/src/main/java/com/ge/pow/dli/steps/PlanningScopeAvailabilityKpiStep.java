package com.ge.pow.dli.steps;

import java.io.IOException;

import com.ge.pow.dli.pages.PlanningOutageHeatmapPage;
import com.ge.pow.dli.pages.PlanningScopeAvailabilityKpiPage;
import com.ge.pow.dli.util.TestBase;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PlanningScopeAvailabilityKpiStep{
	
	@Then("^I can able to expand scope and technical risk$")
	public void expandButton() {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.scopeTechincalRisk();
	}
	
	@Then("^I can able to click on scope availbility kpi$")
	public void clickScopeAvailbility() {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.scopeAvailablity();
	}
	
	@When("^I click on export line items of scope availability$")
	public void exportlineitems() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.exportLineItems();
	}
	
	@Then("^I can validate risk status of all outages$")
	public void validateStatus() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.validateLogicFromExcel();
	}
	
	@Then("^I can validate \"([^\"]*)\" heading in SD page$")
	public void headings(String heading) throws InterruptedException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.validateHeadings(heading);		
	}
	
	@Then("^I expand first outage and validate the status in SD page$")
	public void expandFirstOutage() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.expandOutage();
		PlanningScopeAvailabilityKpiPage.lineStatusSD();
	}

	@When("^I can able to click on view outage button$")
	public void clickViewOutage() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.clickViewOutage();
	}

	@Then("^I can able to check the status from OD page$")
	public void lineStatusODpage() throws IOException {
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.lineStatusOD();
	}
	
	@When("^I can able to click on comments button near outage$")
	public void commentsbutton() throws IOException {		
		TestBase.scopeavailbility();
		PlanningScopeAvailabilityKpiPage.exportLineItems();
	}
	
}
