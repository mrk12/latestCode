package com.ge.pow.dli.steps;

import com.ge.pow.dli.pages.EventMPage;
import com.ge.pow.dli.util.TestBase;

import cucumber.api.java.en.Then;

public class EventMStep {

 

//   @Then("^I should be able to see OFS PGS$")
//
//    public void i_should_be_able_to_see_ofs_pgs() throws InterruptedException {
//
//     TestBase.eventM();
//
//     EventMPage.ofsEvent();
//
//    }
   
   @Then("^I should be able to see \"([^\"]*)\" Outages$")

   public void i_should_be_able_to_see(String arg1) throws Throwable {

     TestBase.eventM();
     EventMPage.allEvent(arg1);

   }
}