package com.ge.pow.dli.steps;

import java.io.IOException;
import com.cucumber.listener.Reporter;
import com.ge.pow.dli.pages.LoginPage;
import com.ge.pow.dli.util.Setup;
import com.ge.pow.dli.util.TestBase;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginPageStep{
	
	@Given("^User launch browser$")
	public void user_launch_browser() {
		TestBase.initilizeDriver(Setup.AUTOMATION_URL);
	}
	
	@Then("^User able to enter valid Credentials$")
	public void enter_SSO() throws IOException {		
		TestBase.loginpage();
		LoginPage.ssoUserName(Setup.username);
		LoginPage.ssoPwd(Setup.pwd);
		LoginPage.loginSubmitBtn();
		Reporter.addScreenCaptureFromPath("absolute screenshot path");
	}
}
